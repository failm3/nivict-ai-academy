# AWE GROUP — CAREER-01 Technical Audit Evidence Bundle v4

**STATUS: REVIEWED CANDIDATE, NOT FULL RAW SNAPSHOT.**

This bundle combines the 2026-11-09 WSL frozen export (v3) with all seven modified
first-party source files absent from v3, snapshot Git metadata, source redaction
provenance, and two genuinely existing user-supplied conversation screenshots
cropped to remove the window tabs and computer hostname.

**Important limitations:**

- All 818 modified tracked files from the supplied Git status are represented.
- 20 of 142 untracked entries are absent. See COVERAGE.json for exact paths.
- Some source or log files were redacted or excluded in earlier packaging passes.
- Three HTTP probe logs had HTTP `Set-Cookie` header values removed by this pass.
- The underlying git object database, PostgreSQL databases, unfiltered raw research
  caches, sensitive files and unreviewed browser responses are NOT included.
- Several experiment-generated Python files are known to be syntactically invalid;
  they document failed agent attempts rather than demonstrating a current core bug.
- Screenshots in AUDIT-METADATA/SCREENSHOTS/ came from conversation attachments
  and must not be represented as filesystem screenshots of this frozen snapshot.
- This is suitable for evidence-based **partial** technical review, not a certificate
  that the original live AWE is complete or production-ready.

**Integrity:** AUDIT-METADATA/SHA256SUMS.txt lists files with SHA-256. Original
source and sanitized hash provenance is in PROVENANCE.json. Reconstruct missing
inputs before claiming exhaustive independent audit.

**Owner requirements and full index:**
https://github.com/failm3/nivict-ai-academy/tree/main/03%20-%20%D0%9F%D1%80%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B0/05%20-%20AWE%20GROUP/AWE-CAREER-01-AUDIT-PACK-2026-11-09
