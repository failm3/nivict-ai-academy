require('./test-guard.cjs');
