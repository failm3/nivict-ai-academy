import {canonicalize, digest, exact, immutable, need, utc} from '../contracts/index.mjs';
import {sqlJson} from './psql-session.mjs';

export const CODING_RUN_SCHEMA = 'awe.e1.coding-run-binding/1';
export const CODING_RUN_PHASES = Object.freeze(['NEW', 'HEAD_PENDING', 'HEAD_CONFIRMED', 'PLAN_READY', 'CODE_PENDING', 'CANDIDATE_READY', 'TESTED', 'QA_PENDING', 'REPAIR_READY', 'PRODUCT_PENDING', 'RESULT_READY', 'HOLD', 'BLOCKED', 'STOPPED']);
const TERMINAL = new Set(['RESULT_READY', 'HOLD', 'BLOCKED', 'STOPPED']);
const GRAPH = Object.freeze({NEW: ['HEAD_PENDING'], HEAD_PENDING: ['HEAD_CONFIRMED'], HEAD_CONFIRMED: ['PLAN_READY'], PLAN_READY: ['CODE_PENDING'], CODE_PENDING: ['CANDIDATE_READY'], CANDIDATE_READY: ['TESTED'], TESTED: ['QA_PENDING', 'REPAIR_READY'], QA_PENDING: ['REPAIR_READY', 'PRODUCT_PENDING'], REPAIR_READY: ['PLAN_READY'], PRODUCT_PENDING: ['RESULT_READY']});
const id = x => typeof x === 'string' && /^[a-z][a-z0-9_.:-]{0,79}$/.test(x);
const hash = x => typeof x === 'string' && /^sha256:[a-f0-9]{64}$/.test(x);
const sha = x => typeof x === 'string' && /^[a-f0-9]{40}$/.test(x);
const scalarRefKeys = Object.freeze(['plan_digest', 'task_id', 'attempt_id', 'logical_request_id', 'worker_id', 'fence', 'candidate_base_sha', 'candidate_head_sha', 'candidate_tree_sha', 'previous_candidate_head_sha', 'proposal_digest', 'model_receipt_digest', 'model_receipt_ref', 'git_journal_ref', 'test_receipt_digest', 'qa_result_hash', 'qa_verdict', 'decision_ref', 'cursor', 'tests_passed', 'product_pass', 'artifact_digest', 'resume_phase', 'head_output_digest', 'failure_ref', 'stop_reason', 'code_task_id', 'code_result_hash', 'product_result_hash']);

/** Immutable bounded scope, not an executable grant and not a second ledger. */
export function validateCodingRunBinding(value) {
  exact(value, ['schema', 'run_id', 'project_id', 'mission_id', 'root_grant_digest', 'brief_digest', 'oracle_digest', 'source_digest', 'original_base_sha', 'deadline', 'head_task_id', 'code_task_ids', 'head_capability_id', 'code_capability_id', 'limits', 'prior_attempt_refs', 'product_task_id', 'product_capability_id', 'product_output_schema_digest']);
  need(value.schema === CODING_RUN_SCHEMA && ['run_id', 'project_id', 'mission_id', 'head_task_id', 'head_capability_id', 'code_capability_id', 'product_task_id', 'product_capability_id'].every(k => id(value[k])), 'CODING_RUN_BINDING');
  need(['root_grant_digest', 'brief_digest', 'oracle_digest', 'source_digest', 'product_output_schema_digest'].every(k => hash(value[k])) && sha(value.original_base_sha), 'CODING_RUN_BINDING_PINS');
  need(Array.isArray(value.code_task_ids) && value.code_task_ids.length === 3 && value.code_task_ids.every(id) && new Set([...value.code_task_ids, value.head_task_id]).size === 4 && value.head_capability_id !== value.code_capability_id, 'CODING_RUN_MODEL_TASKS');
  need(![value.head_task_id, ...value.code_task_ids].includes(value.product_task_id) && ![value.head_capability_id, value.code_capability_id].includes(value.product_capability_id), 'CODING_RUN_PRODUCT_TASK');
  exact(value.limits, ['head', 'code', 'total']);
  need(value.limits.head === 1 && value.limits.code === 3 && value.limits.total === 4, 'CODING_RUN_LIMITS');
  need(Array.isArray(value.prior_attempt_refs) && value.prior_attempt_refs.length <= 1, 'CODING_RUN_PRIOR_SCOPE');
  for (const ref of value.prior_attempt_refs) {
    exact(ref, ['project_id', 'mission_id', 'task_id', 'attempt_id', 'logical_request_id', 'worker_id', 'fence', 'plan_digest', 'result_hash', 'artifact_digest', 'head_sha', 'tree_sha', 'request_hash']);
    need(['project_id', 'mission_id', 'task_id', 'attempt_id', 'logical_request_id', 'worker_id'].every(k => id(ref[k])) && ref.project_id !== value.project_id && ref.mission_id !== value.mission_id && ref.task_id === value.code_task_ids[0] && Number.isSafeInteger(ref.fence) && ref.fence > 0 && ['plan_digest', 'result_hash', 'artifact_digest', 'request_hash'].every(k => hash(ref[k])) && sha(ref.head_sha) && sha(ref.tree_sha) && ref.head_sha === value.original_base_sha, 'CODING_RUN_PRIOR_SCOPE');
  }
  utc(value.deadline); return immutable(value);
}

/** Counts are derived from A2 rows, including FAILED/proven-no-send attempts.
 * Conservative finite attempts never reset when a plan, task or host changes. */
export function summarizeCodingAttempts(binding, attempts) {
  validateCodingRunBinding(binding); need(Array.isArray(attempts), 'CODING_RUN_ATTEMPT_ROWS');
  const rows = attempts.filter(a => a.project_id === binding.project_id || binding.prior_attempt_refs.some(p => p.project_id === a.project_id && p.mission_id === a.mission_id && p.attempt_id === a.attempt_id));
  need(binding.prior_attempt_refs.every(p => rows.some(a => a.project_id === p.project_id && a.mission_id === p.mission_id && a.attempt_id === p.attempt_id && a.task_id === p.task_id && a.logical_request_id === p.logical_request_id && a.worker_id === p.worker_id && String(a.fence) === String(p.fence) && a.request_hash === p.request_hash)), 'CODING_RUN_PRIOR_MISSING_OR_CHANGED');
  need(rows.every(a => id(a.task_id) && typeof a.attempt_id === 'string' && ['RESERVED', 'SENDING', 'CONFIRMED', 'OUTCOME_UNKNOWN', 'FAILED'].includes(a.state)) && new Set(rows.map(a => a.attempt_id)).size === rows.length, 'CODING_RUN_ATTEMPT_ROWS');
  const total = rows.length, head = rows.filter(a => a.task_id === binding.head_task_id).length, code = rows.filter(a => binding.code_task_ids.includes(a.task_id)).length;
  const unknown = rows.filter(a => ['SENDING', 'OUTCOME_UNKNOWN'].includes(a.state)).length;
  const unregistered = rows.filter(a => ![binding.head_task_id, ...binding.code_task_ids].includes(a.task_id) || a.route_id !== 'ollama.local.qwen3-4b-instruct' || a.project_id === binding.project_id && (a.mission_id !== binding.mission_id || binding.prior_attempt_refs.length && a.task_id === binding.code_task_ids[0])).length;
  return immutable({total, head, code, prior: binding.prior_attempt_refs.length, new_total: total - binding.prior_attempt_refs.length, unknown, unregistered, remaining_total: Math.max(0, binding.limits.total - total), remaining_head: Math.max(0, binding.limits.head - head), remaining_code: Math.max(0, binding.limits.code - code), limit_exceeded: total > 4 || head > 1 || code > 3, hold: unknown > 0 || unregistered > 0 || total > 4 || head > 1 || code > 3});
}

/** A confirmed response must be recovered from its durable artifact reference.
 * This helper never authorizes another invocation for an existing native row. */
export function codingModelStepDisposition(binding, attempts, {kind, task_id, attempt_id}) {
  const counts = summarizeCodingAttempts(binding, attempts);
  need(['HEAD', 'CODE'].includes(kind) && typeof attempt_id === 'string' && (kind === 'HEAD' ? task_id === binding.head_task_id : binding.code_task_ids.includes(task_id)), 'CODING_RUN_MODEL_STEP');
  const prior = attempts.find(a => a.project_id === binding.project_id && a.mission_id === binding.mission_id && a.attempt_id === attempt_id);
  if (counts.hold) return immutable({decision: 'HOLD', reason: 'NATIVE_UNKNOWN_OR_SCOPE', counts});
  if (prior) return immutable({decision: prior.state === 'CONFIRMED' ? 'RECOVER_CONFIRMED_ARTIFACT' : 'RECONCILE_EXISTING_ATTEMPT', reason: 'NO_SECOND_MODEL_INVOCATION', counts});
  need(counts.total < 4 && (kind === 'HEAD' ? counts.head < 1 : counts.code < 3), 'CODING_RUN_ATTEMPT_CAP');
  need(!attempts.some(a => a.project_id === binding.project_id && a.mission_id === binding.mission_id && a.task_id === task_id), 'CODING_RUN_TASK_ATTEMPT_REUSE');
  if (kind === 'CODE') need(task_id === binding.code_task_ids[counts.code], 'CODING_RUN_ROUND_SEQUENCE');
  return immutable({decision: 'NEW_NATIVE_ATTEMPT_ALLOWED', reason: 'REQUIRES_CURRENT_A2_CLAIM_AND_RESERVE', counts});
}

export function validateCodingRunTransition(currentPhase, value) {
  exact(value, ['phase', 'decision', 'refs']);
  need(CODING_RUN_PHASES.includes(currentPhase) && CODING_RUN_PHASES.includes(value.phase) && typeof value.decision === 'string' && /^[A-Z][A-Z0-9_]{0,79}$/.test(value.decision), 'CODING_RUN_TRANSITION');
  need(!TERMINAL.has(currentPhase) && (['HOLD', 'BLOCKED', 'STOPPED'].includes(value.phase) || GRAPH[currentPhase]?.includes(value.phase)), 'CODING_RUN_PHASE_ORDER');
  need(value.refs && Object.getPrototypeOf(value.refs) === Object.prototype && Object.keys(value.refs).every(k => scalarRefKeys.includes(k)), 'CODING_RUN_REFS');
  for (const [key, val] of Object.entries(value.refs)) {
    need(typeof val === 'boolean' || Number.isSafeInteger(val) && val >= 0 || typeof val === 'string' && val.length <= 1024 && /^[ -~]*$/.test(val), 'CODING_RUN_REF_VALUE');
    if (key.endsWith('_sha')) need(sha(val), 'CODING_RUN_REF_SHA');
    if (key.endsWith('_digest') || key.endsWith('_hash')) need(hash(val), 'CODING_RUN_REF_DIGEST');
  }
  need(Buffer.byteLength(canonicalize(value)) <= 8192, 'CODING_RUN_TRANSITION_BOUND');
  return immutable(value);
}

/** Host-owned view into the existing transaction domain. Worker processes never
 * receive this session. Native functions independently enforce the same scope. */
export function createCodingRunStore({db, project_id}) {
  need(db?.kind === 'NATIVE_POSTGRESQL_PSQL_SESSION' && typeof db.query === 'function' && ['admin', 'coordinator', 'qa'].includes(db.role) && id(project_id), 'CODING_RUN_NATIVE_HOST_REQUIRED');
  async function invoke(op, request) {
    const text = await db.query("SELECT awe_e1_runtime.coding_run_command('" + op + "'," + sqlJson({...request, project_id}) + ');');
    const lines = text.split(/\r?\n/).filter(Boolean); need(lines.length === 1, 'CODING_RUN_DB_FRAME');
    const result = JSON.parse(lines[0]); need(!result.error, result.error ?? 'CODING_RUN_DB_REJECT'); return immutable(result);
  }
  const write = () => need(['admin', 'coordinator'].includes(db.role), 'CODING_RUN_HOST_WRITE_REQUIRED');
  return Object.freeze({kind: 'AWE_E1_DURABLE_CODING_RUN', project_id,
    open(binding) { write(); validateCodingRunBinding(binding); need(binding.project_id === project_id, 'CODING_RUN_PROJECT_SCOPE'); return invoke('open', {binding, binding_digest: digest(binding)}); },
    read(run_id) { need(id(run_id), 'CODING_RUN_ID'); return invoke('read', {run_id}); },
    advance({run_id, expected_revision, operation_id, transition}) {
      write(); need(id(run_id) && Number.isSafeInteger(expected_revision) && expected_revision >= 0 && typeof operation_id === 'string' && /^[a-z][a-z0-9_.:-]{0,127}$/.test(operation_id), 'CODING_RUN_CAS');
      // SQL checks current phase and native evidence. JS validation here checks
      // the transition's shape; stale phase/CAS can only be resolved by read().
      const shapeFrom = Object.keys(GRAPH).find(p => GRAPH[p].includes(transition.phase)) ?? 'NEW';
      validateCodingRunTransition(shapeFrom, transition);
      const request = {project_id, run_id, expected_revision, operation_id, transition};
      return invoke('advance', {...request, request_hash: digest(request)});
    }
  });
}

/** Reviewed empty-only rollback. Never execute against an initialized run. */
export const EMPTY_CODING_RUN_ROLLBACK_SQL = `BEGIN;
DO $rollback$ BEGIN
 IF session_user<>'awe_e1_test' OR current_database()<>'awe_e1_test' OR current_setting('port')<>'5433' OR current_setting('data_directory')<>'/var/lib/awe-e1-test/awe_e1_a2a3_20261108/pgdata' THEN RAISE EXCEPTION 'CODING_RUN_ROLLBACK_RESOURCE'; END IF;
 IF EXISTS(SELECT 1 FROM awe_e1_runtime.schema_migration WHERE version>=8) THEN RAISE EXCEPTION 'CODING_RUN_ROLLBACK_UPGRADED'; END IF;
 IF EXISTS(SELECT 1 FROM awe_e1_runtime.coding_run) OR EXISTS(SELECT 1 FROM awe_e1_runtime.inbox_event WHERE source_id LIKE 'host.coding-run/1/%') THEN RAISE EXCEPTION 'CODING_RUN_ROLLBACK_NONEMPTY'; END IF;
END $rollback$;
DROP FUNCTION awe_e1_runtime.coding_run_command(text,jsonb);
DROP FUNCTION awe_e1_runtime.coding_run_snapshot(text,text);
DROP TABLE awe_e1_runtime.coding_run;
DELETE FROM awe_e1_runtime.schema_migration WHERE version=7;
COMMIT;`;
