-- Additive gate around our 0007 state store; applied migrations remain intact.
BEGIN;
DO $resource$ BEGIN
 IF session_user<>'awe_e1_test' OR current_database()<>'awe_e1_test' OR current_setting('port')<>'5433' OR current_setting('data_directory')<>'/var/lib/awe-e1-test/awe_e1_a2a3_20261108/pgdata' OR NOT EXISTS(SELECT 1 FROM awe_e1_runtime.schema_migration WHERE version=7) THEN RAISE EXCEPTION 'CODING_RUN_MIGRATION_RESOURCE';END IF;
 IF NOT EXISTS(SELECT 1 FROM awe_e1_runtime.schema_migration WHERE version=8) THEN ALTER FUNCTION awe_e1_runtime.coding_run_command(text,jsonb) RENAME TO coding_run_command_v7;END IF;
END $resource$;

-- Exact canonical order for this small registered Head schema. Unlike the
-- financial canonicalizer, legitimate Unicode rationale/focus stays supported.
CREATE OR REPLACE FUNCTION awe_e1_runtime.coding_head_output_digest(v jsonb) RETURNS text
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $head_digest$
BEGIN
 IF jsonb_typeof(v) IS DISTINCT FROM 'object' OR (SELECT count(*) FROM jsonb_object_keys(v))<>4 OR v-ARRAY['decision','reason','focus','max_code_attempts']<>'{}'::jsonb OR v->>'decision' NOT IN('REPAIR','BLOCK_SCOPE') OR jsonb_typeof(v->'decision') IS DISTINCT FROM 'string' OR jsonb_typeof(v->'reason') IS DISTINCT FROM 'string' OR length(v->>'reason') NOT BETWEEN 1 AND 512 OR jsonb_typeof(v->'focus') IS DISTINCT FROM 'string' OR length(v->>'focus') NOT BETWEEN 1 AND 1024 OR jsonb_typeof(v->'max_code_attempts') IS DISTINCT FROM 'number' OR v->>'max_code_attempts' NOT IN('1','2') THEN RAISE EXCEPTION 'CODING_RUN_HEAD_SCHEMA';END IF;
 RETURN 'sha256:'||encode(sha256(convert_to('{"decision":'||(v->'decision')::text||',"focus":'||(v->'focus')::text||',"max_code_attempts":'||(v->'max_code_attempts')::text||',"reason":'||(v->'reason')::text||'}','UTF8')),'hex');
END $head_digest$;

CREATE OR REPLACE FUNCTION awe_e1_runtime.coding_run_command(op text,p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,awe_e1_runtime AS $head_gate$
DECLARE rr awe_e1_runtime.coding_run%ROWTYPE;inboxrow awe_e1_runtime.inbox_event%ROWTYPE;phase text:=p#>>'{transition,phase}';headrefs jsonb;hdoc jsonb;prevdoc jsonb;max_code integer;used_code integer;prior_n integer;projectid text:=p->>'project_id';runid text:=p->>'run_id';
BEGIN
 IF session_user NOT IN('awe_e1_test','awe_e1_coord','awe_e1_qa') THEN RAISE EXCEPTION 'CODING_RUN_ROLE_DENIED';END IF;
 IF session_user='awe_e1_qa' AND op<>'read' THEN RAISE EXCEPTION 'CODING_RUN_QA_WRITE_DENIED';END IF;
 IF op<>'advance' THEN RETURN awe_e1_runtime.coding_run_command_v7(op,p);END IF;
 -- Identical historic operations are observations, not fresh authorization.
 SELECT * INTO inboxrow FROM awe_e1_runtime.inbox_event WHERE project_id=projectid AND source_id='host.coding-run/1/'||runid AND event_id=p->>'operation_id';
 IF FOUND AND inboxrow.payload_hash=p->>'request_hash' AND p->>'request_hash'=awe_e1_runtime.cloud_digest(p-'request_hash') THEN RETURN awe_e1_runtime.coding_run_command_v7(op,p);END IF;
 PERFORM 1 FROM awe_e1_runtime.project WHERE project_id=projectid FOR UPDATE;
 SELECT * INTO rr FROM awe_e1_runtime.coding_run WHERE project_id=projectid AND run_id=runid;
 IF NOT FOUND THEN RETURN awe_e1_runtime.coding_run_command_v7(op,p);END IF;
 PERFORM 1 FROM awe_e1_runtime.mission WHERE project_id=projectid AND mission_id=rr.mission_id FOR UPDATE;
 SELECT * INTO rr FROM awe_e1_runtime.coding_run WHERE project_id=projectid AND run_id=runid FOR UPDATE;
 IF rr.state#>'{refs,head_output_digest}' IS NOT NULL AND p#>'{transition,refs}' ? 'head_output_digest' AND p#>'{transition,refs,head_output_digest}' IS DISTINCT FROM rr.state#>'{refs,head_output_digest}' THEN RAISE EXCEPTION 'CODING_RUN_HEAD_PIN_IMMUTABLE';END IF;
 IF phase IN('PLAN_READY','CODE_PENDING') THEN
  SELECT e.body->'refs' INTO headrefs FROM awe_e1_runtime.event e WHERE e.project_id=projectid AND e.mission_id=rr.mission_id AND e.kind='CODING_RUN_HEAD_CONFIRMED' AND e.body->>'run_id'=runid ORDER BY e.sequence LIMIT 1;
  IF headrefs IS NULL OR headrefs->>'task_id' IS DISTINCT FROM rr.binding->>'head_task_id' OR headrefs->>'head_output_digest' IS DISTINCT FROM rr.state#>>'{refs,head_output_digest}' THEN RAISE EXCEPTION 'CODING_RUN_HEAD_NATIVE_PIN_REQUIRED';END IF;
  SELECT candidate.doc INTO hdoc FROM (
   SELECT to_jsonb(t) doc FROM awe_e1_runtime.task t WHERE t.project_id=projectid AND t.mission_id=rr.mission_id AND t.task_id=rr.binding->>'head_task_id'
   UNION ALL SELECT h.body FROM awe_e1_runtime.task_revision h WHERE h.mission_id=rr.mission_id AND h.task_id=rr.binding->>'head_task_id'
  ) candidate WHERE candidate.doc->>'state'='ACCEPTED' AND candidate.doc->>'capability_id'=rr.binding->>'head_capability_id' AND candidate.doc->>'producer_id'=headrefs->>'worker_id' AND candidate.doc->>'fence'=headrefs->>'fence' AND candidate.doc->>'plan_digest'=headrefs->>'plan_digest'
   AND EXISTS(SELECT 1 FROM awe_e1_runtime.qa_revision q WHERE q.mission_id=rr.mission_id AND q.task_id=rr.binding->>'head_task_id' AND q.plan_digest=candidate.doc->>'plan_digest' AND q.result_hash=candidate.doc->>'result_hash' AND q.verdict='PASS' AND q.evaluator_id<>candidate.doc->>'producer_id')
   AND EXISTS(SELECT 1 FROM awe_e1_runtime.model_attempt a WHERE a.project_id=projectid AND a.mission_id=rr.mission_id AND a.task_id=rr.binding->>'head_task_id' AND a.attempt_id=headrefs->>'attempt_id' AND a.logical_request_id=headrefs->>'logical_request_id' AND a.worker_id=headrefs->>'worker_id' AND a.fence::text=headrefs->>'fence' AND a.state='CONFIRMED' AND a.route_id='ollama.local.qwen3-4b-instruct' AND a.actual_cost=0)
  LIMIT 1;
  IF hdoc IS NULL OR hdoc#>>'{result,artifact_digest}' IS DISTINCT FROM headrefs->>'head_output_digest' OR awe_e1_runtime.coding_head_output_digest(hdoc#>'{result,output}') IS DISTINCT FROM headrefs->>'head_output_digest' OR hdoc#>>'{result,output_schema_digest}' IS DISTINCT FROM hdoc#>>'{document,capability,output_schema,digest}' THEN RAISE EXCEPTION 'CODING_RUN_ACCEPTED_HEAD_REQUIRED';END IF;
  IF hdoc#>>'{result,output,decision}'<>'REPAIR' THEN RAISE EXCEPTION 'CODING_RUN_HEAD_BLOCKED_SCOPE';END IF;
  max_code:=(hdoc#>>'{result,output,max_code_attempts}')::integer;
  prior_n:=jsonb_array_length(rr.binding->'prior_attempt_refs');
  SELECT count(*) INTO used_code FROM awe_e1_runtime.model_attempt a WHERE a.project_id=projectid AND rr.binding->'code_task_ids' ? a.task_id;
  IF phase='CODE_PENDING' AND used_code>=max_code THEN RAISE EXCEPTION 'CODING_RUN_HEAD_ATTEMPT_LIMIT';END IF;
  IF phase='CODE_PENDING' AND used_code>0 THEN
   SELECT to_jsonb(t) INTO prevdoc FROM awe_e1_runtime.task t WHERE t.project_id=projectid AND t.mission_id=rr.mission_id AND t.task_id=rr.binding->'code_task_ids'->>(used_code+prior_n-1);
   IF prevdoc IS NULL OR NOT(prevdoc->>'state'='FAILED' OR prevdoc->>'state'='ACCEPTED' AND prevdoc#>>'{result,evidence,product_status}'='PRODUCER_TEST_FAILED') OR NOT EXISTS(SELECT 1 FROM awe_e1_runtime.qa_revision q WHERE q.mission_id=rr.mission_id AND q.task_id=prevdoc->>'task_id' AND q.plan_digest=prevdoc->>'plan_digest' AND q.result_hash=prevdoc->>'result_hash' AND q.evaluator_id<>prevdoc->>'producer_id' AND (q.verdict='FAIL' OR q.verdict='PASS' AND prevdoc#>>'{result,evidence,product_status}'='PRODUCER_TEST_FAILED')) THEN RAISE EXCEPTION 'CODING_RUN_PRIOR_ROUND_FAILURE_REQUIRED';END IF;
  END IF;
 END IF;
 RETURN awe_e1_runtime.coding_run_command_v7(op,p);
EXCEPTION WHEN OTHERS THEN RETURN jsonb_build_object('error',CASE WHEN SQLERRM ~ '^CODING_RUN_[A-Z_]+$' THEN SQLERRM ELSE 'CODING_RUN_HEAD_GATE_REJECT' END);
END $head_gate$;
REVOKE ALL ON FUNCTION awe_e1_runtime.coding_run_command_v7(text,jsonb),awe_e1_runtime.coding_head_output_digest(jsonb),awe_e1_runtime.coding_run_command(text,jsonb) FROM PUBLIC,awe_e1_coord,awe_e1_worker,awe_e1_qa;
GRANT EXECUTE ON FUNCTION awe_e1_runtime.coding_run_command(text,jsonb) TO awe_e1_coord,awe_e1_qa;
INSERT INTO awe_e1_runtime.schema_migration VALUES(8,clock_timestamp()) ON CONFLICT DO NOTHING;
COMMIT;
