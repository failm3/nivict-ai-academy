-- Additive host decisions only. A2 continues to own tasks, attempts and money.
BEGIN;
DO $resource$ BEGIN
 IF session_user<>'awe_e1_test' OR current_database()<>'awe_e1_test' OR current_setting('port')<>'5433' OR current_setting('data_directory')<>'/var/lib/awe-e1-test/awe_e1_a2a3_20261108/pgdata' OR current_setting('unix_socket_directories')<>'/var/lib/awe-e1-test/awe_e1_a2a3_20261108/socket' THEN RAISE EXCEPTION 'CODING_RUN_MIGRATION_RESOURCE'; END IF;
 IF NOT EXISTS(SELECT 1 FROM awe_e1_runtime.schema_migration WHERE version=6) OR NOT EXISTS(SELECT 1 FROM awe_e1_resource.identity WHERE resource_id='awe_e1_a2a3_20261108' AND database_name='awe_e1_test' AND port=5433 AND scope='LOCAL_TEST_ONLY') THEN RAISE EXCEPTION 'CODING_RUN_MIGRATION_RESOURCE'; END IF;
END $resource$;

CREATE TABLE IF NOT EXISTS awe_e1_runtime.coding_run(
 project_id text NOT NULL REFERENCES awe_e1_runtime.project, run_id text NOT NULL,
 mission_id text NOT NULL UNIQUE REFERENCES awe_e1_runtime.mission,
 binding jsonb NOT NULL, binding_digest text NOT NULL,
 revision bigint NOT NULL DEFAULT 0 CHECK(revision>=0),
 phase text NOT NULL DEFAULT 'NEW' CHECK(phase IN('NEW','HEAD_PENDING','HEAD_CONFIRMED','PLAN_READY','CODE_PENDING','CANDIDATE_READY','TESTED','QA_PENDING','REPAIR_READY','PRODUCT_PENDING','RESULT_READY','HOLD','BLOCKED','STOPPED')),
 state jsonb NOT NULL DEFAULT '{"refs":{},"decision":"INITIALIZED"}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(project_id,run_id));
-- A failed G1 lineage can fund only one bounded follow-up. A new project/run ID
-- cannot re-adopt the same old attempt to multiply the aggregate allowance.
CREATE UNIQUE INDEX IF NOT EXISTS coding_run_prior_once ON awe_e1_runtime.coding_run((binding#>>'{prior_attempt_refs,0,attempt_id}')) WHERE jsonb_array_length(binding->'prior_attempt_refs')=1;
CREATE UNIQUE INDEX IF NOT EXISTS coding_run_project_once ON awe_e1_runtime.coding_run(project_id);

CREATE OR REPLACE FUNCTION awe_e1_runtime.coding_run_snapshot(projectid text,runid text) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,awe_e1_runtime AS $snapshot$
 SELECT to_jsonb(r)||jsonb_build_object('stored_phase',r.phase,'phase',CASE WHEN a.unknown_n>0 OR a.unregistered_n>0 OR a.total_n>4 OR a.head_n>1 OR a.code_n>3 THEN 'HOLD' ELSE r.phase END,
  'counters',jsonb_build_object('total',a.total_n,'head',a.head_n,'code',a.code_n,'prior',jsonb_array_length(r.binding->'prior_attempt_refs'),'new_total',a.total_n-jsonb_array_length(r.binding->'prior_attempt_refs'),'unknown',a.unknown_n,'unregistered',a.unregistered_n,'remaining_total',greatest(0,4-a.total_n),'remaining_head',greatest(0,1-a.head_n),'remaining_code',greatest(0,3-a.code_n),'limit_exceeded',a.total_n>4 OR a.head_n>1 OR a.code_n>3,'hold',a.unknown_n>0 OR a.unregistered_n>0 OR a.total_n>4 OR a.head_n>1 OR a.code_n>3),
  'attempts',a.rows)
 FROM awe_e1_runtime.coding_run r CROSS JOIN LATERAL (
  SELECT count(*) total_n,count(*) FILTER(WHERE m.task_id=r.binding->>'head_task_id') head_n,
   count(*) FILTER(WHERE r.binding->'code_task_ids' ? m.task_id) code_n,
   count(*) FILTER(WHERE m.state IN('SENDING','OUTCOME_UNKNOWN')) unknown_n,
   count(*) FILTER(WHERE (m.task_id<>r.binding->>'head_task_id' AND NOT(r.binding->'code_task_ids' ? m.task_id)) OR m.route_id<>'ollama.local.qwen3-4b-instruct' OR (m.project_id=r.project_id AND (m.mission_id<>r.mission_id OR jsonb_array_length(r.binding->'prior_attempt_refs')=1 AND m.task_id=r.binding#>>'{code_task_ids,0}'))) unregistered_n,
   COALESCE(jsonb_agg(to_jsonb(m) ORDER BY m.attempt_id),'[]'::jsonb) rows
  FROM awe_e1_runtime.model_attempt m WHERE m.project_id=r.project_id OR EXISTS(SELECT 1 FROM jsonb_array_elements(r.binding->'prior_attempt_refs') p WHERE m.project_id=p->>'project_id' AND m.mission_id=p->>'mission_id' AND m.attempt_id=p->>'attempt_id')
 ) a WHERE r.project_id=projectid AND r.run_id=runid
$snapshot$;

CREATE OR REPLACE FUNCTION awe_e1_runtime.coding_run_command(op text,p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,awe_e1_runtime AS $command$
<<coding_state>>
DECLARE projectid text:=p->>'project_id';runid text:=p->>'run_id';b jsonb:=p->'binding';prior jsonb;
 pp awe_e1_runtime.project%ROWTYPE;mm awe_e1_runtime.mission%ROWTYPE;gg awe_e1_runtime.mission_grant%ROWTYPE;
 rr awe_e1_runtime.coding_run%ROWTYPE;tt awe_e1_runtime.task%ROWTYPE;pt awe_e1_runtime.task%ROWTYPE;aa awe_e1_runtime.model_attempt%ROWTYPE;
 oldtask awe_e1_runtime.task%ROWTYPE;oldproject awe_e1_runtime.project%ROWTYPE;
 q awe_e1_runtime.qa_revision%ROWTYPE;pq awe_e1_runtime.qa_revision%ROWTYPE;prior_inbox awe_e1_runtime.inbox_event%ROWTYPE;
 tr jsonb:=p->'transition';refs jsonb;oldrefs jsonb;phase text;summary jsonb;response jsonb;requesthash text;sourceid text;seq bigint;key text;val jsonb;
 total_n bigint;head_n bigint;code_n bigint;prior_n integer;taskid text;attemptid text;scope_project text;
 allowed_refs text[]:=ARRAY['plan_digest','task_id','attempt_id','logical_request_id','worker_id','fence','candidate_base_sha','candidate_head_sha','candidate_tree_sha','previous_candidate_head_sha','proposal_digest','model_receipt_digest','model_receipt_ref','git_journal_ref','test_receipt_digest','qa_result_hash','qa_verdict','decision_ref','cursor','tests_passed','product_pass','artifact_digest','resume_phase','head_output_digest','failure_ref','stop_reason','code_task_id','code_result_hash','product_result_hash'];
BEGIN
 IF session_user NOT IN('awe_e1_test','awe_e1_coord','awe_e1_qa') THEN RAISE EXCEPTION 'CODING_RUN_ROLE_DENIED'; END IF;
 IF session_user='awe_e1_qa' AND op<>'read' THEN RAISE EXCEPTION 'CODING_RUN_QA_WRITE_DENIED'; END IF;
 IF current_database()<>'awe_e1_test' OR current_setting('port')<>'5433' OR current_setting('data_directory')<>'/var/lib/awe-e1-test/awe_e1_a2a3_20261108/pgdata' THEN RAISE EXCEPTION 'CODING_RUN_RESOURCE_DENIED'; END IF;
 IF projectid IS NULL OR projectid !~ '^[a-z][a-z0-9_.:-]{0,79}$' THEN RAISE EXCEPTION 'CODING_RUN_PROJECT_SCOPE'; END IF;
 IF op='open' THEN runid:=b->>'run_id'; END IF;
 IF runid IS NULL OR runid !~ '^[a-z][a-z0-9_.:-]{0,79}$' THEN RAISE EXCEPTION 'CODING_RUN_ID'; END IF;
 sourceid:='host.coding-run/1/'||runid;
 IF op='read' THEN
  IF p-ARRAY['project_id','run_id']<>'{}'::jsonb THEN RAISE EXCEPTION 'CODING_RUN_REQUEST_SHAPE'; END IF;
  response:=awe_e1_runtime.coding_run_snapshot(projectid,runid);IF response IS NULL THEN RAISE EXCEPTION 'CODING_RUN_NOT_FOUND';END IF;RETURN response;
 END IF;
 IF op NOT IN('open','advance') THEN RAISE EXCEPTION 'CODING_RUN_OPERATION'; END IF;
 IF op='open' THEN
  IF p-ARRAY['project_id','binding','binding_digest']<>'{}'::jsonb OR jsonb_typeof(b) IS DISTINCT FROM 'object' OR b-ARRAY['schema','run_id','project_id','mission_id','root_grant_digest','brief_digest','oracle_digest','source_digest','original_base_sha','deadline','head_task_id','code_task_ids','head_capability_id','code_capability_id','limits','prior_attempt_refs','product_task_id','product_capability_id','product_output_schema_digest']<>'{}'::jsonb OR (SELECT count(*) FROM jsonb_object_keys(b))<>19 OR b->>'schema' IS DISTINCT FROM 'awe.e1.coding-run-binding/1' OR b->>'project_id' IS DISTINCT FROM projectid OR p->>'binding_digest' IS DISTINCT FROM awe_e1_runtime.cloud_digest(b) THEN RAISE EXCEPTION 'CODING_RUN_BINDING'; END IF;
  FOREACH key IN ARRAY ARRAY['run_id','project_id','mission_id','head_task_id','head_capability_id','code_capability_id','product_task_id','product_capability_id'] LOOP IF NOT COALESCE(b->>key ~ '^[a-z][a-z0-9_.:-]{0,79}$',false) THEN RAISE EXCEPTION 'CODING_RUN_BINDING'; END IF; END LOOP;
  FOREACH key IN ARRAY ARRAY['root_grant_digest','brief_digest','oracle_digest','source_digest','product_output_schema_digest'] LOOP IF NOT COALESCE(b->>key ~ '^sha256:[a-f0-9]{64}$',false) THEN RAISE EXCEPTION 'CODING_RUN_BINDING_PINS'; END IF; END LOOP;
  IF NOT COALESCE(b->>'original_base_sha' ~ '^[a-f0-9]{40}$',false) OR b->'limits' IS DISTINCT FROM '{"head":1,"code":3,"total":4}'::jsonb OR b->>'head_capability_id'=b->>'code_capability_id' OR jsonb_typeof(b->'code_task_ids') IS DISTINCT FROM 'array' OR jsonb_array_length(b->'code_task_ids')<>3 OR (SELECT count(DISTINCT x) FROM jsonb_array_elements_text(b->'code_task_ids') x)<>3 OR EXISTS(SELECT 1 FROM jsonb_array_elements_text(b->'code_task_ids') x WHERE x !~ '^[a-z][a-z0-9_.:-]{0,79}$' OR x=b->>'head_task_id') OR jsonb_typeof(b->'prior_attempt_refs') IS DISTINCT FROM 'array' OR jsonb_array_length(b->'prior_attempt_refs') NOT BETWEEN 0 AND 1 THEN RAISE EXCEPTION 'CODING_RUN_LIMITS'; END IF;
  IF b->>'product_task_id'=b->>'head_task_id' OR b->'code_task_ids' ? (b->>'product_task_id') OR b->>'product_capability_id' IN(b->>'head_capability_id',b->>'code_capability_id') THEN RAISE EXCEPTION 'CODING_RUN_PRODUCT_TASK';END IF;
  -- Lock all authorized project scopes in a stable order, never model supplied.
  FOR scope_project IN SELECT DISTINCT x FROM (SELECT projectid x UNION ALL SELECT e->>'project_id' FROM jsonb_array_elements(b->'prior_attempt_refs') e) scopes ORDER BY x LOOP
   PERFORM 1 FROM awe_e1_runtime.project WHERE project_id=scope_project FOR UPDATE;IF NOT FOUND THEN RAISE EXCEPTION 'CODING_RUN_PROJECT_SCOPE';END IF;
  END LOOP;
 ELSE
  IF p-ARRAY['project_id','run_id','expected_revision','operation_id','transition','request_hash']<>'{}'::jsonb OR p->>'operation_id' IS NULL OR p->>'operation_id' !~ '^[a-z][a-z0-9_.:-]{0,127}$' OR NOT COALESCE(p->>'expected_revision' ~ '^(0|[1-9][0-9]{0,15})$',false) THEN RAISE EXCEPTION 'CODING_RUN_CAS'; END IF;
  PERFORM 1 FROM awe_e1_runtime.project WHERE project_id=projectid FOR UPDATE;IF NOT FOUND THEN RAISE EXCEPTION 'CODING_RUN_PROJECT_SCOPE';END IF;
 END IF;
 SELECT * INTO pp FROM awe_e1_runtime.project WHERE project_id=projectid;
 IF op='open' THEN
  SELECT * INTO mm FROM awe_e1_runtime.mission WHERE project_id=projectid AND mission_id=b->>'mission_id' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'CODING_RUN_MISSION_SCOPE'; END IF;
 ELSE
  SELECT * INTO rr FROM awe_e1_runtime.coding_run WHERE project_id=projectid AND run_id=runid;
  IF NOT FOUND THEN RAISE EXCEPTION 'CODING_RUN_NOT_FOUND'; END IF;
  SELECT * INTO mm FROM awe_e1_runtime.mission WHERE project_id=projectid AND mission_id=rr.mission_id FOR UPDATE;
 END IF;
 SELECT * INTO gg FROM awe_e1_runtime.mission_grant WHERE mission_id=mm.mission_id FOR SHARE;
 SELECT * INTO rr FROM awe_e1_runtime.coding_run WHERE project_id=projectid AND run_id=runid FOR UPDATE;
 IF op='open' THEN
  IF FOUND THEN IF rr.binding IS DISTINCT FROM b OR rr.binding_digest IS DISTINCT FROM p->>'binding_digest' THEN RAISE EXCEPTION 'CODING_RUN_OPEN_CONFLICT'; END IF;RETURN awe_e1_runtime.coding_run_snapshot(projectid,runid)||jsonb_build_object('repeated',true); END IF;
  IF EXISTS(SELECT 1 FROM awe_e1_runtime.inbox_event WHERE project_id=projectid AND source_id=sourceid) THEN RAISE EXCEPTION 'CODING_RUN_NAMESPACE_CONFLICT'; END IF;
  prior_n:=jsonb_array_length(b->'prior_attempt_refs');
  IF mm.grant_digest IS DISTINCT FROM b->>'root_grant_digest' OR gg.digest IS DISTINCT FROM b->>'root_grant_digest' OR mm.owner_id<>pp.owner_id OR mm.state<>'ACTIVE' OR gg.revoked_at IS NOT NULL OR clock_timestamp()<gg.issued_at OR clock_timestamp()>=gg.expires_at OR (b->>'deadline')::timestamptz>gg.expires_at OR (b->>'deadline')::timestamptz>mm.deadline OR (b->>'deadline')::timestamptz<=clock_timestamp() OR pp.budget_cap<>0 OR pp.spent<>0 OR pp.reserved<>0 OR pp.quota_cap<>4-prior_n OR pp.quota_used<>0 OR EXISTS(SELECT 1 FROM awe_e1_runtime.model_attempt WHERE project_id=projectid) THEN RAISE EXCEPTION 'CODING_RUN_PARENT_OR_CAP'; END IF;
  IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(gg.document->'allowed_capabilities') c WHERE c->>'capability_id'=b->>'head_capability_id') OR NOT EXISTS(SELECT 1 FROM jsonb_array_elements(gg.document->'allowed_capabilities') c WHERE c->>'capability_id'=b->>'code_capability_id') OR NOT EXISTS(SELECT 1 FROM jsonb_array_elements(gg.document->'allowed_capabilities') c WHERE c->>'capability_id'=b->>'product_capability_id' AND c#>>'{output_schema,digest}'=b->>'product_output_schema_digest') THEN RAISE EXCEPTION 'CODING_RUN_PARENT_CAPABILITY'; END IF;
  FOR prior IN SELECT * FROM jsonb_array_elements(b->'prior_attempt_refs') LOOP
   IF prior-ARRAY['project_id','mission_id','task_id','attempt_id','logical_request_id','worker_id','fence','plan_digest','result_hash','artifact_digest','head_sha','tree_sha','request_hash']<>'{}'::jsonb OR (SELECT count(*) FROM jsonb_object_keys(prior))<>13 OR prior->>'project_id'=projectid OR prior->>'mission_id'=mm.mission_id OR prior->>'task_id' IS DISTINCT FROM b#>>'{code_task_ids,0}' OR prior->>'head_sha' IS DISTINCT FROM b->>'original_base_sha' THEN RAISE EXCEPTION 'CODING_RUN_PRIOR_SCOPE'; END IF;
   SELECT * INTO oldproject FROM awe_e1_runtime.project WHERE project_id=prior->>'project_id';
   SELECT * INTO oldtask FROM awe_e1_runtime.task WHERE project_id=prior->>'project_id' AND mission_id=prior->>'mission_id' AND task_id=prior->>'task_id' FOR SHARE;
   SELECT * INTO aa FROM awe_e1_runtime.model_attempt WHERE project_id=prior->>'project_id' AND mission_id=prior->>'mission_id' AND task_id=prior->>'task_id' AND attempt_id=prior->>'attempt_id' FOR SHARE;
   IF aa.attempt_id IS NULL OR oldtask.task_id IS NULL OR oldproject.owner_id<>pp.owner_id OR oldproject.quota_cap<>1 OR oldproject.quota_used<>1 OR oldproject.budget_cap<>0 OR oldproject.spent<>0 OR oldproject.reserved<>0 OR (SELECT count(*) FROM awe_e1_runtime.model_attempt WHERE project_id=oldproject.project_id)<>1 OR aa.state<>'CONFIRMED' OR aa.actual_cost<>0 OR aa.route_id<>'ollama.local.qwen3-4b-instruct' OR aa.logical_request_id IS DISTINCT FROM prior->>'logical_request_id' OR aa.request_hash IS DISTINCT FROM prior->>'request_hash' OR aa.worker_id IS DISTINCT FROM prior->>'worker_id' OR aa.fence::text IS DISTINCT FROM prior->>'fence' OR NOT oldtask.is_current OR oldtask.state<>'FAILED' OR oldtask.plan_digest IS DISTINCT FROM prior->>'plan_digest' OR oldtask.result_hash IS DISTINCT FROM prior->>'result_hash' OR oldtask.producer_id IS DISTINCT FROM aa.worker_id OR oldtask.fence<>aa.fence OR EXISTS(SELECT 1 FROM awe_e1_runtime.lease WHERE mission_id=oldtask.mission_id) OR EXISTS(SELECT 1 FROM awe_e1_runtime.task_reservation WHERE mission_id=oldtask.mission_id) THEN RAISE EXCEPTION 'CODING_RUN_PRIOR_NATIVE_BINDING'; END IF;
   IF oldtask.result#>>'{evidence,coding_artifact,artifact_digest}' IS DISTINCT FROM prior->>'artifact_digest' OR oldtask.result#>>'{evidence,coding_artifact,head_sha}' IS DISTINCT FROM prior->>'head_sha' OR oldtask.result#>>'{evidence,coding_artifact,tree_sha}' IS DISTINCT FROM prior->>'tree_sha' OR oldtask.result#>>'{evidence,coding_artifact,issue_digest}' IS DISTINCT FROM b->>'brief_digest' OR NOT EXISTS(SELECT 1 FROM awe_e1_runtime.qa_revision qa WHERE qa.mission_id=oldtask.mission_id AND qa.task_id=oldtask.task_id AND qa.plan_digest=oldtask.plan_digest AND qa.result_hash=oldtask.result_hash AND qa.verdict='FAIL' AND qa.evaluator_id<>oldtask.producer_id) OR NOT EXISTS(SELECT 1 FROM jsonb_array_elements(mm.spec->'facts_refs') f WHERE f->>'digest'=prior->>'result_hash') THEN RAISE EXCEPTION 'CODING_RUN_PRIOR_ARTIFACT_OR_AUTHORITY'; END IF;
  END LOOP;
  INSERT INTO awe_e1_runtime.coding_run(project_id,run_id,mission_id,binding,binding_digest) VALUES(projectid,runid,mm.mission_id,b,p->>'binding_digest');
  INSERT INTO awe_e1_runtime.event(project_id,mission_id,kind,body) VALUES(projectid,mm.mission_id,'CODING_RUN_OPENED',jsonb_build_object('run_id',runid,'binding_digest',p->>'binding_digest','prior_attempt_count',prior_n));
  RETURN awe_e1_runtime.coding_run_snapshot(projectid,runid)||jsonb_build_object('repeated',false);
 END IF;

 requesthash:=awe_e1_runtime.cloud_digest(p-'request_hash');
 IF p->>'request_hash' IS DISTINCT FROM requesthash THEN RAISE EXCEPTION 'CODING_RUN_OPERATION_DIGEST'; END IF;
 SELECT * INTO prior_inbox FROM awe_e1_runtime.inbox_event WHERE project_id=projectid AND source_id=sourceid AND event_id=p->>'operation_id';
 IF FOUND THEN IF prior_inbox.payload_hash<>requesthash THEN RAISE EXCEPTION 'CODING_RUN_OPERATION_CONFLICT';END IF;RETURN prior_inbox.body||jsonb_build_object('repeated',true);END IF;
 IF rr.revision<>(p->>'expected_revision')::bigint THEN RAISE EXCEPTION 'CODING_RUN_STALE_REVISION'; END IF;
 IF jsonb_typeof(tr) IS DISTINCT FROM 'object' OR tr-ARRAY['phase','decision','refs']<>'{}'::jsonb OR (SELECT count(*) FROM jsonb_object_keys(tr))<>3 OR NOT COALESCE(tr->>'decision' ~ '^[A-Z][A-Z0-9_]{0,79}$',false) OR jsonb_typeof(tr->'refs') IS DISTINCT FROM 'object' OR octet_length(tr::text)>8192 THEN RAISE EXCEPTION 'CODING_RUN_TRANSITION'; END IF;
 phase:=tr->>'phase';oldrefs:=rr.state->'refs';refs:=oldrefs||(tr->'refs');
 IF EXISTS(SELECT 1 FROM jsonb_object_keys(tr->'refs') k WHERE NOT(k=ANY(allowed_refs))) THEN RAISE EXCEPTION 'CODING_RUN_REFS'; END IF;
 FOR key,val IN SELECT * FROM jsonb_each(tr->'refs') LOOP
  IF jsonb_typeof(val) NOT IN('string','number','boolean') OR (jsonb_typeof(val)='string' AND (length(val#>>'{}')>1024 OR val#>>'{}' !~ '^[ -~]*$')) OR (jsonb_typeof(val)='number' AND val::text !~ '^(0|[1-9][0-9]{0,15})$') OR (key LIKE '%\_sha' ESCAPE '\' AND NOT COALESCE(val#>>'{}' ~ '^[a-f0-9]{40}$',false)) OR ((key LIKE '%\_digest' ESCAPE '\' OR key LIKE '%\_hash' ESCAPE '\') AND NOT COALESCE(val#>>'{}' ~ '^sha256:[a-f0-9]{64}$',false)) THEN RAISE EXCEPTION 'CODING_RUN_REF_VALUE'; END IF;
 END LOOP;
 IF rr.phase IN('RESULT_READY','HOLD','BLOCKED','STOPPED') OR NOT(phase IN('HOLD','BLOCKED','STOPPED') OR rr.phase='NEW' AND phase='HEAD_PENDING' OR rr.phase='HEAD_PENDING' AND phase='HEAD_CONFIRMED' OR rr.phase='HEAD_CONFIRMED' AND phase='PLAN_READY' OR rr.phase='PLAN_READY' AND phase='CODE_PENDING' OR rr.phase='CODE_PENDING' AND phase='CANDIDATE_READY' OR rr.phase='CANDIDATE_READY' AND phase='TESTED' OR rr.phase='TESTED' AND phase IN('QA_PENDING','REPAIR_READY') OR rr.phase='QA_PENDING' AND phase IN('REPAIR_READY','PRODUCT_PENDING') OR rr.phase='REPAIR_READY' AND phase='PLAN_READY' OR rr.phase='PRODUCT_PENDING' AND phase='RESULT_READY') THEN RAISE EXCEPTION 'CODING_RUN_PHASE_ORDER'; END IF;
 summary:=awe_e1_runtime.coding_run_snapshot(projectid,runid);
 total_n:=(summary#>>'{counters,total}')::bigint;head_n:=(summary#>>'{counters,head}')::bigint;code_n:=(summary#>>'{counters,code}')::bigint;
 IF phase NOT IN('HOLD','BLOCKED','STOPPED') THEN
  IF (summary#>>'{counters,hold}')::boolean THEN RAISE EXCEPTION 'CODING_RUN_NATIVE_HOLD'; END IF;
  IF mm.grant_digest IS DISTINCT FROM rr.binding->>'root_grant_digest' OR gg.digest IS DISTINCT FROM rr.binding->>'root_grant_digest' OR gg.revoked_at IS NOT NULL OR mm.state NOT IN('ACTIVE','COMPLETE') OR clock_timestamp()>=gg.expires_at OR clock_timestamp()>=(rr.binding->>'deadline')::timestamptz THEN RAISE EXCEPTION 'CODING_RUN_PARENT_INACTIVE'; END IF;
 END IF;
 IF phase NOT IN('HEAD_PENDING','CODE_PENDING','HOLD','BLOCKED','STOPPED') THEN
  FOREACH key IN ARRAY ARRAY['task_id','attempt_id','logical_request_id','worker_id','fence'] LOOP IF oldrefs ? key AND refs->key IS DISTINCT FROM oldrefs->key THEN RAISE EXCEPTION 'CODING_RUN_STEP_SCOPE_CHANGED'; END IF;END LOOP;
 END IF;
 taskid:=refs->>'task_id';attemptid:=refs->>'attempt_id';
 IF phase IN('HEAD_PENDING','CODE_PENDING') THEN
  IF total_n>=4 OR phase='HEAD_PENDING' AND (head_n>=1 OR taskid IS DISTINCT FROM rr.binding->>'head_task_id') OR phase='CODE_PENDING' AND (code_n>=3 OR taskid IS DISTINCT FROM rr.binding->'code_task_ids'->>code_n::int) THEN RAISE EXCEPTION 'CODING_RUN_ATTEMPT_CAP'; END IF;
  IF attemptid IS NULL OR attemptid !~ '^[a-z][a-z0-9_.:-]{0,127}$' OR EXISTS(SELECT 1 FROM awe_e1_runtime.model_attempt WHERE attempt_id=attemptid OR mission_id=rr.mission_id AND task_id=taskid) THEN RAISE EXCEPTION 'CODING_RUN_NO_MODEL_REPLAY'; END IF;
  SELECT * INTO tt FROM awe_e1_runtime.task WHERE project_id=projectid AND mission_id=rr.mission_id AND task_id=taskid;
  IF NOT FOUND OR NOT tt.is_current OR tt.state<>'RUNNING' OR tt.executor_kind<>'llm' OR tt.capability_id IS DISTINCT FROM (CASE WHEN phase='HEAD_PENDING' THEN rr.binding->>'head_capability_id' ELSE rr.binding->>'code_capability_id' END) OR tt.plan_digest IS DISTINCT FROM refs->>'plan_digest' OR tt.producer_id IS DISTINCT FROM refs->>'worker_id' OR tt.fence::text IS DISTINCT FROM refs->>'fence' OR (tt.document#>>'{retry,max_attempts}')::int<>1 OR NOT EXISTS(SELECT 1 FROM awe_e1_runtime.lease l WHERE l.project_id=projectid AND l.mission_id=tt.mission_id AND l.task_id=tt.task_id AND l.worker_id=tt.producer_id AND l.fence=tt.fence AND l.expires_at>clock_timestamp()) THEN RAISE EXCEPTION 'CODING_RUN_CURRENT_NATIVE_CLAIM'; END IF;
  IF phase='CODE_PENDING' THEN
   IF refs->>'candidate_base_sha' IS DISTINCT FROM COALESCE(oldrefs->>'candidate_head_sha',rr.binding->>'original_base_sha') THEN RAISE EXCEPTION 'CODING_RUN_CANDIDATE_CHAIN';END IF;
   refs:=(refs-ARRAY['candidate_head_sha','candidate_tree_sha','test_receipt_digest','qa_result_hash','qa_verdict','tests_passed','product_pass'])||jsonb_build_object('previous_candidate_head_sha',COALESCE(oldrefs->>'candidate_head_sha',rr.binding->>'original_base_sha'));
  END IF;
 ELSIF phase IN('HEAD_CONFIRMED','CANDIDATE_READY') THEN
  SELECT * INTO aa FROM awe_e1_runtime.model_attempt WHERE project_id=projectid AND mission_id=rr.mission_id AND task_id=taskid AND attempt_id=attemptid;
  IF NOT FOUND OR aa.state<>'CONFIRMED' OR aa.route_id<>'ollama.local.qwen3-4b-instruct' OR aa.actual_cost<>0 OR aa.worker_id IS DISTINCT FROM refs->>'worker_id' OR aa.fence::text IS DISTINCT FROM refs->>'fence' OR aa.logical_request_id IS DISTINCT FROM refs->>'logical_request_id' THEN RAISE EXCEPTION 'CODING_RUN_CONFIRMED_NATIVE_REQUIRED'; END IF;
  IF phase='HEAD_CONFIRMED' AND NOT COALESCE(refs->>'head_output_digest' ~ '^sha256:[a-f0-9]{64}$',false) THEN RAISE EXCEPTION 'CODING_RUN_HEAD_ARTIFACT_REQUIRED';END IF;
  IF phase='CANDIDATE_READY' AND (NOT COALESCE(refs->>'candidate_head_sha' ~ '^[a-f0-9]{40}$',false) OR NOT COALESCE(refs->>'candidate_tree_sha' ~ '^[a-f0-9]{40}$',false) OR refs->>'candidate_head_sha'=refs->>'candidate_base_sha' OR refs->>'candidate_base_sha' IS DISTINCT FROM oldrefs->>'candidate_base_sha' OR NOT COALESCE(refs->>'proposal_digest' ~ '^sha256:[a-f0-9]{64}$',false) OR NOT COALESCE(refs->>'model_receipt_digest' ~ '^sha256:[a-f0-9]{64}$',false) OR NOT(refs ? 'git_journal_ref')) THEN RAISE EXCEPTION 'CODING_RUN_CANDIDATE_ARTIFACT_REQUIRED';END IF;
 ELSIF phase='PLAN_READY' THEN
  IF refs->>'plan_digest' IS DISTINCT FROM mm.plan_digest OR NOT EXISTS(SELECT 1 FROM awe_e1_runtime.plan_revision pr WHERE pr.mission_id=mm.mission_id AND pr.digest=mm.plan_digest) THEN RAISE EXCEPTION 'CODING_RUN_ADMITTED_PLAN_REQUIRED'; END IF;
  IF (SELECT count(*) FROM awe_e1_runtime.task t WHERE t.mission_id=rr.mission_id AND t.is_current AND t.task_id=rr.binding->>'product_task_id')<>1 OR EXISTS(SELECT 1 FROM awe_e1_runtime.task t WHERE t.mission_id=rr.mission_id AND t.is_current AND NOT(
   t.task_id=rr.binding->>'product_task_id' AND t.executor_kind='script' AND t.capability_id=rr.binding->>'product_capability_id' AND t.model_routes='[]'::jsonb AND t.document#>>'{effect,effect_class}'='NONE' AND t.document#>>'{capability,output_schema,digest}'=rr.binding->>'product_output_schema_digest'
   OR t.executor_kind='llm' AND (t.task_id=rr.binding->>'head_task_id' AND t.capability_id=rr.binding->>'head_capability_id' OR rr.binding->'code_task_ids' ? t.task_id AND t.capability_id=rr.binding->>'code_capability_id') AND NOT(jsonb_array_length(rr.binding->'prior_attempt_refs')=1 AND t.task_id=rr.binding#>>'{code_task_ids,0}')
  )) THEN RAISE EXCEPTION 'CODING_RUN_PLAN_SCOPE'; END IF;
 ELSIF phase='TESTED' THEN
  IF jsonb_typeof(refs->'tests_passed') IS DISTINCT FROM 'boolean' OR NOT COALESCE(refs->>'test_receipt_digest' ~ '^sha256:[a-f0-9]{64}$',false) OR refs->>'candidate_head_sha' IS DISTINCT FROM oldrefs->>'candidate_head_sha' OR refs->>'candidate_tree_sha' IS DISTINCT FROM oldrefs->>'candidate_tree_sha' THEN RAISE EXCEPTION 'CODING_RUN_TEST_BINDING';END IF;
 ELSIF phase IN('QA_PENDING','REPAIR_READY','PRODUCT_PENDING','RESULT_READY') THEN
  SELECT * INTO tt FROM awe_e1_runtime.task WHERE project_id=projectid AND mission_id=rr.mission_id AND task_id=taskid;
  IF NOT FOUND OR NOT tt.is_current OR tt.plan_digest IS DISTINCT FROM refs->>'plan_digest' OR tt.result_hash IS DISTINCT FROM refs->>'qa_result_hash' OR tt.result#>>'{evidence,coding_artifact,head_sha}' IS DISTINCT FROM refs->>'candidate_head_sha' OR tt.result#>>'{evidence,coding_artifact,tree_sha}' IS DISTINCT FROM refs->>'candidate_tree_sha' THEN RAISE EXCEPTION 'CODING_RUN_NATIVE_RESULT_BINDING'; END IF;
  IF phase='QA_PENDING' THEN IF tt.state<>'WAIT_QA' THEN RAISE EXCEPTION 'CODING_RUN_NATIVE_WAIT_QA_REQUIRED';END IF;
  ELSE
   SELECT * INTO q FROM awe_e1_runtime.qa_revision WHERE mission_id=tt.mission_id AND task_id=tt.task_id AND plan_digest=tt.plan_digest AND result_hash=tt.result_hash;
   IF NOT FOUND OR q.evaluator_id=tt.producer_id OR tt.state NOT IN('ACCEPTED','FAILED') THEN RAISE EXCEPTION 'CODING_RUN_INDEPENDENT_QA_REQUIRED';END IF;
   IF phase='REPAIR_READY' THEN
    IF NOT(q.verdict='FAIL' AND tt.state='FAILED' OR q.verdict='PASS' AND tt.state='ACCEPTED' AND tt.result#>>'{evidence,product_status}'='PRODUCER_TEST_FAILED') OR code_n>=3 OR total_n>=4 OR EXISTS(SELECT 1 FROM awe_e1_runtime.lease WHERE mission_id=tt.mission_id) OR EXISTS(SELECT 1 FROM awe_e1_runtime.task_reservation WHERE mission_id=tt.mission_id) THEN RAISE EXCEPTION 'CODING_RUN_REPAIR_NOT_ADMISSIBLE';END IF;
   ELSE
    IF tt.state<>'ACCEPTED' OR q.verdict<>'PASS' OR refs->'tests_passed' IS DISTINCT FROM 'true'::jsonb OR refs->>'code_task_id' IS DISTINCT FROM tt.task_id OR refs->>'code_result_hash' IS DISTINCT FROM tt.result_hash OR tt.result#>>'{evidence,product_status}'='PRODUCER_TEST_FAILED' OR tt.result#>>'{evidence,coding_artifact,contract_version}' IS DISTINCT FROM 'awe.e1.coding-artifact/2' OR jsonb_typeof(tt.result#>'{evidence,coding_artifact,tests}') IS DISTINCT FROM 'array' OR jsonb_array_length(tt.result#>'{evidence,coding_artifact,tests}')=0 OR EXISTS(SELECT 1 FROM jsonb_array_elements(tt.result#>'{evidence,coding_artifact,tests}') test WHERE test->>'exit_code' IS DISTINCT FROM '0') THEN RAISE EXCEPTION 'CODING_RUN_ACCEPTED_CODE_REQUIRED';END IF;
    SELECT * INTO pt FROM awe_e1_runtime.task WHERE project_id=projectid AND mission_id=rr.mission_id AND task_id=rr.binding->>'product_task_id';
    IF NOT FOUND OR NOT pt.is_current OR pt.executor_kind<>'script' OR pt.capability_id IS DISTINCT FROM rr.binding->>'product_capability_id' OR pt.model_routes<>'[]'::jsonb OR pt.document#>>'{effect,effect_class}' IS DISTINCT FROM 'NONE' OR pt.document#>>'{capability,output_schema,digest}' IS DISTINCT FROM rr.binding->>'product_output_schema_digest' OR NOT EXISTS(SELECT 1 FROM awe_e1_runtime.task_dependency d WHERE d.mission_id=pt.mission_id AND d.task_id=pt.task_id AND d.dependency_id=tt.task_id) THEN RAISE EXCEPTION 'CODING_RUN_PRODUCT_TASK_BINDING';END IF;
    IF phase='PRODUCT_PENDING' THEN
     IF pt.state NOT IN('READY','RUNNING','WAIT_QA','ACCEPTED') THEN RAISE EXCEPTION 'CODING_RUN_PRODUCT_NOT_PENDING';END IF;
    ELSE
     SELECT * INTO pq FROM awe_e1_runtime.qa_revision WHERE mission_id=pt.mission_id AND task_id=pt.task_id AND plan_digest=pt.plan_digest AND result_hash=pt.result_hash;
     IF NOT FOUND OR pt.state<>'ACCEPTED' OR pq.verdict<>'PASS' OR pq.evaluator_id=pt.producer_id OR pt.plan_digest<>tt.plan_digest OR refs->'product_pass' IS DISTINCT FROM 'true'::jsonb OR refs->>'product_result_hash' IS DISTINCT FROM pt.result_hash OR pt.result->>'output_schema_digest' IS DISTINCT FROM rr.binding->>'product_output_schema_digest' OR pt.result#>'{output,product_pass}' IS DISTINCT FROM 'true'::jsonb OR pt.result#>>'{output,head_sha}' IS DISTINCT FROM refs->>'candidate_head_sha' OR pt.result#>>'{output,tree_sha}' IS DISTINCT FROM refs->>'candidate_tree_sha' OR pt.result#>>'{output,code_result_hash}' IS DISTINCT FROM tt.result_hash OR pt.result#>>'{output,oracle_digest}' IS DISTINCT FROM rr.binding->>'oracle_digest' OR pt.result#>>'{output,prior_result_hash}' IS DISTINCT FROM COALESCE(rr.binding#>>'{prior_attempt_refs,0,result_hash}',awe_e1_runtime.cloud_digest('[]'::jsonb)) OR NOT EXISTS(SELECT 1 FROM jsonb_array_elements(pq.checks) checkrow WHERE checkrow->>'check_id'='product' AND checkrow->>'passed'='true' AND checkrow->>'oracle_digest'=rr.binding->>'oracle_digest' AND checkrow->>'head_sha'=refs->>'candidate_head_sha' AND checkrow->>'tree_sha'=refs->>'candidate_tree_sha') THEN RAISE EXCEPTION 'CODING_RUN_PRODUCT_GATE_REQUIRED';END IF;
    END IF;
   END IF;
  END IF;
 END IF;
 UPDATE awe_e1_runtime.coding_run SET phase=coding_state.phase,revision=revision+1,state=jsonb_build_object('refs',refs,'decision',tr->>'decision'),updated_at=clock_timestamp() WHERE project_id=projectid AND run_id=runid;
 response:=awe_e1_runtime.coding_run_snapshot(projectid,runid)||jsonb_build_object('repeated',false);
 INSERT INTO awe_e1_runtime.event(project_id,mission_id,task_id,kind,body) VALUES(projectid,rr.mission_id,taskid,'CODING_RUN_'||phase,jsonb_build_object('run_id',runid,'operation_id',p->>'operation_id','request_hash',requesthash,'revision',rr.revision+1,'decision',tr->>'decision','refs',refs)) RETURNING sequence INTO seq;
 INSERT INTO awe_e1_runtime.inbox_event(project_id,source_id,event_id,payload_hash,body,sequence) VALUES(projectid,sourceid,p->>'operation_id',requesthash,response,seq);
 RETURN response;
EXCEPTION WHEN OTHERS THEN RETURN jsonb_build_object('error',CASE WHEN SQLERRM ~ '^CODING_RUN_[A-Z_]+$' THEN SQLERRM WHEN SQLSTATE='23505' THEN 'CODING_RUN_LINEAGE_ALREADY_ADOPTED' ELSE 'CODING_RUN_DATABASE_REJECT' END);
END $command$;

REVOKE ALL ON TABLE awe_e1_runtime.coding_run FROM PUBLIC,awe_e1_coord,awe_e1_worker,awe_e1_qa;
REVOKE ALL ON FUNCTION awe_e1_runtime.coding_run_snapshot(text,text),awe_e1_runtime.coding_run_command(text,jsonb) FROM PUBLIC,awe_e1_coord,awe_e1_worker,awe_e1_qa;
GRANT EXECUTE ON FUNCTION awe_e1_runtime.coding_run_command(text,jsonb) TO awe_e1_coord,awe_e1_qa;
INSERT INTO awe_e1_runtime.schema_migration VALUES(7,clock_timestamp()) ON CONFLICT DO NOTHING;
COMMIT;
