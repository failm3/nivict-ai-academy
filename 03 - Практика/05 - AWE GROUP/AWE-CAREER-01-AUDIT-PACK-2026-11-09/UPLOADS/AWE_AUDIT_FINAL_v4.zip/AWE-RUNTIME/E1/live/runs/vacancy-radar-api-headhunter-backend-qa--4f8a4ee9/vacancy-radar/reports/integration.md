# t4 — интеграция и воспроизводимость

Дата выполнения: 2026-11-09 UTC (часы среды). Итог: локальная read-only интеграция работает; live HH импорт и браузерная проверка **не выполнены**. Полнота рынка не заявляется.

## Сделано

- Сверены docs/api-contract.md, server.py, native frontend client и существующие тесты. Обновлён устаревший статус контракта: GET реализованы, POST /imports закрыт. Контракт описывает целевой 202/idempotency, но фактический валидный HTTP POST получает 403 IMPORT_DISABLED. health.stage остаётся scaffold. Полный машинный conformance suite не создан.
- Один origin: Python обслуживает frontend и /api/v1. Добавлен отдельный CLI миграций; schema_version=2, повторная миграция успешна.
- Добавлены frontend/package-lock.json, requirements.lock (Python без сторонних зависимостей), Makefile, runtime check, README и recorder команд. Нативные команды работают без make/pip. dist собран без фикстур.
- Добавлены 4 process/HTTP E2E в tests/test_e2e.py. Временная SQLite внутри workspace; SYNTHETIC фикстуры, FakeOpener, без запросов в HH и без записи в рабочую БД. Серверные subprocess завершаются после тестов.
- Финальный прогон: **10 backend + 13 frontend + 4 E2E = 27 passed**, код 0. E2E empty проверяет native frontend createClient через Node fetch с настоящим HTTP backend. Остальные E2E проверяют HTTP API и persistence, не DOM браузера.

## Проверки и наблюдения

|Сценарий|Результат и граница|
|---|---|
|Пустая БД|Реальный server subprocess, GET HTML/JS, пустой список, null coverage; frontend client/render functions через Node — OK|
|Два импорта|Только синтетический adapter/repository path, НЕ POST: первый inserted=3, повтор inserted=0/unchanged=3|
|Поиск + комбинированные фильтры|q=synthetic + area_id=TEST + experience_id=noExperience + currency=RUR + gross=true, total=2|
|Пагинация|per_page=1, две разные записи, page=2 пустая|
|Детали|external_id совпадает со списком|
|Аналитика|Синтетическая выборка TEST: total=2, coverage=1.0000, mean=150.00|
|Перезапуск|Полная остановка/новый процесс с тем же SQLite: те же записи и 2 задания|
|Сетевая ошибка|Изолированная URLError, 3 попытки без реального ожидания, failed/HH_UNAVAILABLE, ноль вакансий|
|Недоступность API|Изолированный HTTP 503, 3 попытки, failed/HH_UNAVAILABLE, ноль вакансий|
|Сборка|check/build exit 0, dist/index.html + src/app.js + src/style.css|
|Миграции|Два отдельных запуска, schema_version=2, exit 0|

## Команды, время, вывод

Все нижеперечисленные журналы `reports/logs/` содержат точные argv/cwd, start/end UTC, duration, exit code и stdout/stderr; время не реконструировалось вручную.

- `t4-lock.log`: npm package-lock-only, exit 0.
- `t4-browser-probe.log`: версии и поиск браузеров/playwright, exit 0; браузеры не найдены, Python/Node playwright отсутствуют.
- `t4-install.log`: первоначальная установка через pip, exit 1, No module named pip. Python runtime не требует пакетов; инструкция исправлена.
- `t4-make-blocker.log`: make install не может стартовать, exit 127, make отсутствует. Сам recorder первоначально не обрабатывал OSError; исправлен. Первые незаписанные попытки make не выдаются за успешные.
- `t4-install-final.log`: runtime check + npm ci, exit 0. `t4-npm-ci.log`: отдельный npm ci, exit 0.
- `t4-build.log`: npm check/build, exit 0.
- `t4-migrate.log`, `t4-migrate-repeat.log`: отдельные миграции, exit 0.
- `t4-tests.log`: первый прогон, exit 1 (E2E ошибочно включил суффикс startup-строки в base URL).
- `t4-e2e-rerun.log`: exit 1 (при перезапуске тест прочитал старый порт из append-журнала). Исправлены парсинг и truncate временного журнала.
- `t4-tests-final.log`: полный финальный прогон, exit 0; HTTP access logs и test output сохранены. Процессы слушали случайные loopback-порты, например 35377 для empty/frontend.

## Точные блокеры и невыполненное

1. **Live импорт HH не запускался.** Документ docs/hh-compliance.md фиксирует неподтверждённый допуск приложения для локального аналитического назначения; server.IMPORTS_ENABLED=False намеренно не переключается env. Не предоставлены подтверждение допуска, зарегистрированная identity/contact и разрешённая конфигурация. Разрешение пользователя на небольшой импорт не заменяет эти условия. Gate не обходился. Повтор, поиск, детали, аналитика и restart проверены только на явно синтетических данных. Отсутствует доказательство live-дедупликации/доступности HH/качества реальных полей. Сетевой probe HH в t4 не проводился; наличие старых source-снимков не считается live-проверкой t4.
2. **Нет установленного браузера/Playwright.** Мобильная/desktop отрисовка, взаимодействия DOM, доступность фокуса и скриншоты не проверены/не сохранены. Node render/client tests этого не заменяют.
3. make и pip отсутствуют; воспроизводимые прямые команды README проверены. Полный Makefile сам не исполнен. Версии ОС/интерпретатора не закреплены контейнерным digest; lock-файлы покрывают только пустые dependency graphs.
4. Для завершения: подтвердить допустимость назначения/регистрацию, reviewed подключение HTTP импорта с лимитами и реальной identity, выполнить небольшой разрешённый live импорт дважды; установить браузер и выполнить desktop/mobile DOM E2E со снимками. Отдельный reverse-proxy deployment dist не проверен.
