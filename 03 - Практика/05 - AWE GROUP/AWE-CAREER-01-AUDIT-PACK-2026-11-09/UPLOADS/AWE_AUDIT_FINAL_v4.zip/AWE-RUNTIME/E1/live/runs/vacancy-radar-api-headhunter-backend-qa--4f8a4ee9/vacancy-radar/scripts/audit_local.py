"""Offline heuristic audit; prints paths/categories, never matching secret values."""
from pathlib import Path
import re
import sqlite3
root = Path(__file__).resolve().parents[1]
patterns = [re.compile(x) for x in (r'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----', r'gh[pousr]_[A-Za-z0-9]{30,}', r'AKIA[0-9A-Z]{16}')]
hits=[]
for p in root.rglob('*'):
    if not p.is_file() or any(x in p.parts for x in ('.git','__pycache__','node_modules')) or p.suffix in ('.sqlite3','.pyc') or p.name=='audit_local.py': continue
    try: text=p.read_text()
    except (UnicodeError,OSError): continue
    if any(rx.search(text) for rx in patterns): hits.append(str(p.relative_to(root)))
print('Heuristic private-key/GitHub/AWS matches:',hits)
for p in sorted((root/'data').glob('*.sqlite3')):
    with sqlite3.connect(f'file:{p}?mode=ro',uri=True) as c:
        print('Working DB:',p.relative_to(root),'integrity:',c.execute('pragma integrity_check').fetchone()[0])
        for table in ('vacancies','imports','import_items'):
            print(table,c.execute(f'SELECT count(*) FROM {table}').fetchone()[0])
print('Browser binaries:', __import__('shutil').which('chromium'), __import__('shutil').which('firefox'))
print('No external requests performed. Heuristic scan is not proof of absence of all secrets.')
raise SystemExit(bool(hits))
