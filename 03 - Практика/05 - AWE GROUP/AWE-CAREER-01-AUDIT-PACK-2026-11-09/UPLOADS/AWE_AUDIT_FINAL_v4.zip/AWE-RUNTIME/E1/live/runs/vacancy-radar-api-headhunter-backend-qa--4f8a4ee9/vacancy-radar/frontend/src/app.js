// No remote scripts, credentials, HTML descriptions or production fixtures.
export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const e = escapeHTML;
export function officialURL(raw) {
  try { const u = new URL(raw); return u.protocol === 'https:' && (u.hostname === 'hh.ru' || u.hostname.endsWith('.hh.ru')) && !u.username && !u.password && !u.port ? u.href : null; } catch { return null; }
}
const date = value => value && !Number.isNaN(Date.parse(value)) ? new Date(value).toLocaleString('ru-RU') : 'неизвестно';
const tax = value => value === true ? 'до налогов' : value === false ? 'на руки' : 'налоги неизвестны';
const statuses = {queued:'В очереди',running:'Выполняется',succeeded:'Завершён',partial:'Частично выполнен',failed:'Ошибка'};
const freshness = {current:'Актуальная',stale:'Устаревшая',unknown:'Свежесть неизвестна'};
const warnings = {LIMITED_SAMPLE:'Ограниченная, нерепрезентативная выборка HH.',PARTIAL_IMPORT:'Импорт выполнен не полностью.',STALE_DATA:'Есть устаревшие данные.',AUTH_DEPENDENT:'Доступность зависит от авторизации HH.'};
export function salary(s) {
  if (!s || (s.from == null && s.to == null)) return 'Зарплата не указана';
  return `${s.from != null ? `от ${s.from}` : ''} ${s.to != null ? `до ${s.to}` : ''} ${s.currency ?? 'валюта неизвестна'} · ${s.period ?? 'период неизвестен'} · ${tax(s.gross)}`.trim();
}
export function renderScope(s) {
  if (!s) return '<p>Метаданные выборки недоступны.</p>';
  return `<div class="scope"><strong>${s.kind === 'import_snapshot' ? 'Снимок импорта' : 'Локальная база'} · ${e(s.total_matched)} записей</strong><p>Источник: HH · срез на ${e(date(s.as_of))}${s.import_id ? ` · импорт ${e(s.import_id)}` : ''}</p><p>${e((s.warning_codes || []).map(c => warnings[c] || c).join(' '))}</p>${s.imports?.length ? `<details><summary>Импорты, сформировавшие выборку (${s.imports.length})</summary><ul>${s.imports.map(i => `<li>${e(i.id)} · ${e(statuses[i.status] || i.status)} · получено уникальных ${e(i.unique_seen)}, найдено HH ${e(i.found_reported ?? 'неизвестно')} · ${e(date(i.created_at))}${i.truncated ? ' · ограничен' : ''}</li>`).join('')}</ul></details>` : ''}</div>`;
}
export function renderList(data) {
  return `${renderScope(data.scope)}${data.items.length ? `<ul class="vacancies">${data.items.map(v => `<li><article><p class="eyebrow">HH · ${e(v.area?.name)} · ${e(freshness[v.freshness] || v.freshness)}</p><h3><button class="title-button" data-vacancy="${e(v.id)}">${e(v.title)}</button></h3><p>${e(v.employer?.name || 'Работодатель не указан')}</p><p class="salary">${e(salary(v.salary))}</p><p class="hint">Опубликовано: ${e(date(v.published_at))}<br>Обновлено в базе: ${e(date(v.last_seen_at))}</p></article></li>`).join('')}</ul>` : '<div class="empty"><h3>Вакансий не найдено</h3><p>Измените фильтры или проверьте состояние импорта ниже. Демонстрационные данные не подставляются.</p></div>'}<nav class="pagination" aria-label="Страницы вакансий"><button data-page="${data.page - 1}" ${data.page === 0 ? 'disabled' : ''}>Назад</button><span>Страница ${data.page + 1} из ${Math.max(1, Math.ceil(data.total / data.per_page))} · всего ${e(data.total)}</span><button data-page="${data.page + 1}" ${(data.page + 1) * data.per_page >= data.total ? 'disabled' : ''}>Далее</button></nav><p class="hint">При обновлении базы состав страниц может измениться.</p>`;
}
export function renderDetail(v) {
  const url = officialURL(v.alternate_url);
  return `<h3>${e(v.title)}</h3><p>${e(v.employer?.name || 'Работодатель не указан')} · ${e(v.area?.name)}</p><p class="salary">${e(salary(v.salary))}</p><dl><dt>Источник / внешний ID</dt><dd>HH / ${e(v.external_id)}</dd><dt>Опыт (ID)</dt><dd>${e(v.experience_ids?.join(', ') || 'Не указан')}</dd><dt>Опубликовано</dt><dd>${e(date(v.published_at))}</dd><dt>Впервые в базе</dt><dd>${e(date(v.first_seen_at))}</dd><dt>Последнее обновление</dt><dd>${e(date(v.last_seen_at))}</dd><dt>Проверено в источнике</dt><dd>${e(date(v.last_verified_at))}</dd><dt>Свежесть</dt><dd>${e(freshness[v.freshness] || v.freshness)}</dd></dl><p>${url ? `<a class="official" href="${e(url)}" target="_blank" rel="noopener noreferrer">Открыть официальную вакансию HH ↗</a>` : 'Безопасная официальная ссылка недоступна.'}</p><p class="hint">Полное описание читайте в источнике. API не передаёт описание; внешний HTML не исполняется и не вставляется.</p>`;
}
export function renderAnalytics(a) {
  return `${renderScope(a.scope)}<dl class="metrics"><div><dt>Всего</dt><dd>${e(a.total_matched)}</dd></div><div><dt>С зарплатой</dt><dd>${e(a.with_salary)}</dd></div><div><dt>Без зарплаты</dt><dd>${e(a.without_salary)}</dd></div><div><dt>Невалидные суммы</dt><dd>${e(a.invalid_salary)}</dd></div><div><dt>В группах</dt><dd>${e(a.included_in_groups)}</dd></div><div><dt>Доля с зарплатой (0–1)</dt><dd>${e(a.coverage ?? 'нет данных')}</dd></div></dl>${a.groups.length ? `<div class="table-scroll" tabindex="0" role="region" aria-label="Таблица зарплат, прокручивается"><table><caption>Статистика по отдельным группам</caption><thead><tr>${['Валюта / налоги / период','n','Закрытые / от / до','Среднее','Медиана','Минимум','Максимум'].map(h => `<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${a.groups.map(g => `<tr><th scope="row">${e(g.currency ?? 'Неизвестно')} / ${e(tax(g.gross))} / ${e(g.period ?? 'неизвестно')}</th><td>${e(g.n)}</td><td>${e(g.count_closed)} / ${e(g.count_from_only)} / ${e(g.count_to_only)}</td>${['mean','median','min','max'].map(k => `<td>${e(g[k] ?? '—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : '<p class="empty">Нет данных для зарплатной статистики.</p>'}<p class="hint">Для закрытой вилки используется её середина, для открытой — известная граница. Это суммы из публикаций, не фактические доходы. Нет пересчёта валют, периодов или налогов.</p>`;
}
export function renderImports(data) {
  return data.items.length ? `<ul class="jobs">${data.items.map(i => `<li><strong>${e(statuses[i.status] || i.status)}</strong> · HH · ${e(date(i.created_at))}<p>ID: ${e(i.id)}</p><p>Запрос: ${e(i.query?.text || 'без текста')} · бюджет ${e(i.max_pages)} стр.</p><p>Страниц: ${e(i.pages_fetched)}; получено: ${e(i.items_received)}; уникальных: ${e(i.unique_seen)}; найдено HH: ${e(i.found_reported ?? 'неизвестно')}; лимит: ${e(i.retrieval_cap)}</p><p>Добавлено ${e(i.inserted)}, обновлено ${e(i.updated)}, без изменений ${e(i.unchanged)}, невалидных ${e(i.invalid)}</p>${i.truncated ? '<p class="notice">Выборка ограничена или прервана.</p>' : ''}${i.error ? `<p class="error">${e(i.error.code)}: ${e(i.error.message)}</p>` : ''}</li>`).join('')}</ul><p>Показаны последние ${data.items.length} из ${e(data.total)} запусков. Успешный статус не означает полноту базы HH.</p>` : '<p class="empty">Импортов ещё нет. Поиск не запускает импорт автоматически.</p>';
}
export function filtersFrom(form) {
  const p = new URLSearchParams();
  for (const [key, raw] of new FormData(form)) {
    const value = raw.trim(); if (!value) continue;
    if (key === 'area_id' || key === 'experience_id') value.split(',').map(x => x.trim()).filter(Boolean).forEach(x => p.append(key, x));
    else if (key === 'published_from' || key === 'published_to') p.set(key, new Date(`${value}T${key.endsWith('from') ? '00:00:00.000' : '23:59:59.999'}Z`).toISOString());
    else p.set(key, value);
  }
  if ((p.has('salary_min') || p.has('salary_max') || p.get('sort')?.startsWith('salary_')) && (!p.has('currency') || !p.has('period'))) throw new Error('Для зарплатных фильтров и сортировки укажите валюту и период.');
  if (p.get('sort')?.startsWith('salary_') && !p.has('gross')) throw new Error('Для сортировки по зарплате выберите налоги, включая «Неизвестно».');
  if (p.has('salary_min') && p.has('salary_max') && Number(p.get('salary_min')) > Number(p.get('salary_max'))) throw new Error('Минимальная сумма не может превышать максимальную.');
  if (p.has('published_from') && p.has('published_to') && p.get('published_from') > p.get('published_to')) throw new Error('Дата начала должна быть не позже даты окончания.');
  return p;
}
export function createClient(fetcher = globalThis.fetch) {
  const requests = new Map();
  return { cancel(key) { requests.get(key)?.abort(); requests.delete(key); }, async get(key, path, options = {}) {
    requests.get(key)?.abort(); const controller = new AbortController(); requests.set(key, controller);
    try {
      const response = await fetcher(`/api/v1${path}`, {...options, signal:controller.signal, headers:{Accept:'application/json',...options.headers}});
      const body = await response.json();
      if (requests.get(key) !== controller) throw new DOMException('Устаревший запрос', 'AbortError');
      if (!response.ok) { const err = new Error(body.error?.message || `HTTP ${response.status}`); err.code = body.error?.code; err.requestId = body.error?.request_id; err.details = body.error?.details; throw err; }
      return body;
    } catch (err) { if (requests.get(key) !== controller || controller.signal.aborted) throw new DOMException('Запрос отменён', 'AbortError'); throw err; }
  }};
}
function mount() {
  const $ = id => document.getElementById(id), client = createClient();
  let params = new URLSearchParams('sort=published_at_desc&per_page=20&freshness=current'), page = 0, detailId, importEnabled = false, posting = false, pendingImport = null, timer;
  const loading = id => { $(id).setAttribute('aria-busy','true'); $(id).innerHTML = '<p role="status" class="loading">Загрузка…</p>'; };
  const show = (id, html) => { $(id).removeAttribute('aria-busy'); $(id).innerHTML = html; };
  const fail = (id, err, retry) => { if (err.name === 'AbortError') return; show(id, `<div class="error" role="alert"><h3>Не удалось получить данные</h3><p>${e(err.code || 'NETWORK_ERROR')}: ${e(err.message)}</p>${err.details?.length ? `<ul>${err.details.map(d => `<li>${e(d.field)}: ${e(d.reason)}</li>`).join('')}</ul>` : ''}${err.requestId ? `<p>ID запроса: ${e(err.requestId)}</p>` : ''}<button data-retry="${retry}" class="secondary">Повторить</button></div>`); };
  async function list() { loading('list'); const p = new URLSearchParams(params); p.set('page', page); try { show('list', renderList(await client.get('list', `/vacancies?${p}`))); } catch (err) { fail('list',err,'list'); } }
  async function analytics() { loading('analytics'); const p = new URLSearchParams(params); p.delete('sort'); p.delete('per_page'); try { show('analytics', renderAnalytics(await client.get('analytics', `/analytics/salaries?${p}`))); } catch (err) { fail('analytics',err,'analytics'); } }
  async function detail(id) { detailId = id; loading('detail-body'); if (!$('detail').open) $('detail').showModal(); const p = params.get('import_id'); try { show('detail-body',renderDetail(await client.get('detail', `/vacancies/${encodeURIComponent(id)}${p ? `?import_id=${encodeURIComponent(p)}` : ''}`))); } catch (err) { fail('detail-body',err,'detail'); } }
  async function health() { try { const h = await client.get('health','/health'); importEnabled = h.imports_enabled === true; $('health').textContent = `API: ${h.status} · база: ${h.database}`; $('import-gate').textContent = importEnabled ? 'Сервер разрешает импорт. Проверьте параметры и подтвердите запуск.' : 'Импорт отключён сервером. Доступно исследование уже сохранённых данных.'; } catch (err) { importEnabled = false; $('health').innerHTML = 'API недоступен. <button data-retry="health" class="secondary">Повторить проверку</button>'; $('import-gate').textContent = 'Разрешение не подтверждено; импорт недоступен.'; } $('import-submit').disabled = !importEnabled || posting; }
  async function imports() { clearTimeout(timer); loading('imports'); try { const data = await client.get('imports','/imports?per_page=20'); show('imports',renderImports(data)); if (data.items.some(i => ['queued','running'].includes(i.status))) timer = setTimeout(imports,5000); } catch (err) { fail('imports',err,'imports'); } }
  async function sendImport() { if (!pendingImport || posting || !importEnabled) return; posting = true; $('import-submit').disabled = true; loading('import-action'); try { const job = await client.get('post-import','/imports',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':pendingImport.key},body:pendingImport.body}); pendingImport = null; show('import-action',`<p>Задание ${e(job.id)}: ${e(statuses[job.status] || job.status)}. Обновите поиск после завершения.</p>`); imports(); } catch (err) { fail('import-action',err,'post-import'); } finally { posting = false; $('import-submit').disabled = !importEnabled; } }
  $('search').addEventListener('submit',event => { event.preventDefault(); try { const next = filtersFrom(event.currentTarget); params = next; page = 0; $('filter-error').textContent = ''; list(); analytics(); } catch (err) { $('filter-error').textContent = err.message; } });
  $('search').addEventListener('reset',() => setTimeout(() => $('search').requestSubmit(),0));
  $('close-detail').onclick = () => $('detail').close();
  $('detail').addEventListener('close',() => { client.cancel('detail'); $('detail-body').removeAttribute('aria-busy'); });
  $('refresh-imports').onclick = imports;
  $('import-form').addEventListener('submit',event => { event.preventDefault(); if (!importEnabled || posting) return; const f = new FormData(event.currentTarget), ids = key => [...new Set(f.get(key).split(',').map(x => x.trim()).filter(Boolean))]; const timestamp = (key,end) => f.get(key) ? `${f.get(key)}T${end ? '23:59:59.999' : '00:00:00.000'}Z` : null;
    const query = {text:f.get('text').trim(),area_ids:ids('area_ids'),experience_ids:ids('experience_ids'),only_with_salary:f.has('only_with_salary'),published_from:timestamp('published_from',false),published_to:timestamp('published_to',true)};
    if (query.published_from && query.published_to && query.published_from > query.published_to) { show('import-action','<p role="alert" class="error">Проверьте порядок дат импорта.</p>'); return; }
    const body = JSON.stringify({source:'hh',query,max_pages:Number(f.get('max_pages'))}); if (!pendingImport || pendingImport.body !== body) pendingImport = {body,key:crypto.randomUUID()}; sendImport();
  });
  document.addEventListener('click',event => { const b = event.target.closest('button'); if (!b || b.disabled) return; if (b.dataset.vacancy) detail(b.dataset.vacancy); if (b.dataset.page) { page = Number(b.dataset.page); list(); $('results').focus(); } const retry = b.dataset.retry; if (retry) ({list,analytics,imports,health,detail:() => detail(detailId),'post-import':sendImport})[retry]?.(); });
  document.addEventListener('visibilitychange',() => { if (document.hidden) clearTimeout(timer); else imports(); });
  health(); list(); analytics(); imports();
}
if (typeof document !== 'undefined') mount();
