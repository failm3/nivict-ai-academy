"""No Python package installation needed: requirements.lock is intentionally empty."""
import sqlite3
import sys
assert sys.version_info >= (3,12), 'Python >=3.12 required'
assert sqlite3.sqlite_version_info >= (3,35), 'SQLite >=3.35 required'
print('Python',sys.version.split()[0],'; SQLite',sqlite3.sqlite_version,'; third-party packages: none')
