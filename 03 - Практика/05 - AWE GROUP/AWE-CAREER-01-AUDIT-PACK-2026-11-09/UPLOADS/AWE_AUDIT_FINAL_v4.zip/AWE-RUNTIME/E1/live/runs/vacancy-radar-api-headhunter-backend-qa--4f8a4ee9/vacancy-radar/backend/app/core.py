"""Local repository, validation and analytics. No network or sample data at import time."""
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from pathlib import Path
from uuid import UUID, uuid4

ROOT = Path(__file__).resolve().parents[2]

def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')

def dump(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

class Error(Exception):
    def __init__(self, status=422, code='VALIDATION_ERROR', field='', reason='invalid value'):
        self.status, self.code = status, code
        self.detail = {'code': code, 'message': code, 'details': [{'field': field, 'reason': reason}] if field else [], 'request_id': str(uuid4())}
        super().__init__(code)

def require(test, field='', reason='invalid value'):
    if not test:
        raise Error(field=field, reason=reason)

def timestamp(value):
    require(isinstance(value, str), 'timestamp')
    try:
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        require(dt.tzinfo is not None, 'timestamp', 'timezone required')
        return dt.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')
    except ValueError:
        raise Error(field='timestamp') from None

def decimal(value):
    if isinstance(value, bool):
        raise ValueError('boolean money')
    try:
        d = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('invalid money') from None
    if not d.is_finite() or d < 0 or len(str(value)) > 64 or abs(d.as_tuple().exponent) > 12:
        raise ValueError('invalid money')
    return d

def salary(v):
    s = v['salary']
    try:
        a, b = (None if s[k] is None else decimal(s[k]) for k in ('from', 'to'))
        if a is not None and b is not None and a > b:
            return 'invalid', None, None, None
    except ValueError:
        return 'invalid', None, None, None
    if a is None and b is None:
        return 'missing', None, None, None
    with localcontext() as ctx:
        ctx.prec = 128
        return 'valid', a, b, (a+b)/2 if a is not None and b is not None else a if a is not None else b

class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as c:
            c.execute('PRAGMA journal_mode=WAL')
            version = c.execute('PRAGMA user_version').fetchone()[0]
            if version > 2:
                raise RuntimeError('Unsupported schema version')
            for n, filename in ((1, '001_initial.sql'), (2, '002_durable.sql')):
                if version < n:
                    sql = (ROOT / 'backend/migrations' / filename).read_text()
                    try:
                        c.executescript('BEGIN IMMEDIATE;\n' + sql + '\nCOMMIT;')
                    except Exception:
                        c.rollback()
                        raise

    @contextmanager
    def connection(self):
        c = sqlite3.connect(self.path, timeout=5)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON')
        c.execute('PRAGMA busy_timeout=5000')
        try:
            with c:
                yield c
        finally:
            c.close()

    def get_import(self, ident, c=None):
        if c is None:
            with self.connection() as db:
                return self.get_import(ident, db)
        row = c.execute('SELECT * FROM imports WHERE id=?', (ident,)).fetchone()
        if row is None:
            raise Error(404, 'NOT_FOUND')
        if row['dto_json']:
            return json.loads(row['dto_json'])
        return dict(id=row['id'], source=row['source'], query=json.loads(row['query_json']), status=row['status'], created_at=row['created_at'], legacy=True)

    def save_import(self, c, job):
        c.execute('UPDATE imports SET status=?,dto_json=? WHERE id=?', (job['status'], dump(job), job['id']))

    def create_import(self, body, key):
        body = validate_import(body)
        require(isinstance(key, str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', key), 'Idempotency-Key')
        canonical = dump(body)
        with self.connection() as c:
            c.execute('BEGIN IMMEDIATE')
            old = c.execute('SELECT * FROM idempotency_keys WHERE key=?', (key,)).fetchone()
            if old:
                if old['request_hash'] != canonical:
                    raise Error(409, 'IDEMPOTENCY_CONFLICT')
                return self.get_import(old['import_id'], c), False
            if c.execute("SELECT 1 FROM imports WHERE status IN ('queued','running')").fetchone():
                raise Error(409, 'IMPORT_IN_PROGRESS')
            j = dict(id=str(uuid4()), **body, status='queued', created_at=now(), started_at=None, finished_at=None, found_reported=None, pages_fetched=0, items_received=0, unique_seen=0, inserted=0, updated=0, unchanged=0, invalid=0, retrieval_cap=2000, truncated=False, error=None)
            c.execute('INSERT INTO imports(id,source,query_json,status,created_at,dto_json) VALUES(?,?,?,?,?,?)', (j['id'], 'hh', dump(j['query']), j['status'], j['created_at'], dump(j)))
            c.execute('INSERT INTO idempotency_keys VALUES(?,?,?,?)', (key, canonical, j['id'], j['created_at']))
            return j, True

    def recover(self):
        with self.connection() as c:
            for row in c.execute("SELECT id FROM imports WHERE status IN ('queued','running')").fetchall():
                j = self.get_import(row['id'], c)
                j.update(status='failed', finished_at=now(), truncated=True, error=Error(code='INTERRUPTED_BY_RESTART').detail)
                self.save_import(c, j)

    def page(self, ident, items, found):
        """One page transaction: upsert, immutable membership and counters together."""
        require(type(found) is int and found >= 0, 'found')
        with self.connection() as c:
            c.execute('BEGIN IMMEDIATE')
            j = self.get_import(ident, c)
            require(j['status'] in ('queued', 'running'), 'status')
            j['status'] = 'running'
            j['started_at'] = j['started_at'] or now()
            j['found_reported'] = found
            for item in items:
                j['items_received'] += 1
                try:
                    v = normalize(item)
                except (Error, ValueError, TypeError, KeyError):
                    j['invalid'] += 1
                    continue
                old = c.execute("SELECT * FROM vacancies WHERE source='hh' AND external_id=?", (v['external_id'],)).fetchone()
                seen = now()
                v.update(first_seen_at=old['first_seen_at'] if old else seen, last_seen_at=seen, last_verified_at=None, freshness='unknown')
                if old:
                    prev = json.loads(old['dto_json'])
                    stable = lambda x: {k: val for k, val in x.items() if k not in ('id','first_seen_at','last_seen_at','last_verified_at','freshness')}
                    kind = 'unchanged' if stable(prev) == stable(v) else 'updated'
                    v['id'] = old['id']
                    c.execute('UPDATE vacancies SET last_seen_at=?,dto_json=? WHERE id=?', (seen, dump(v), v['id']))
                else:
                    kind = 'inserted'
                    cur = c.execute('INSERT INTO vacancies(source,external_id,first_seen_at,last_seen_at,dto_json) VALUES(?,?,?,?,?)', ('hh',v['external_id'],seen,seen,'{}'))
                    v['id'] = cur.lastrowid
                    c.execute('UPDATE vacancies SET dto_json=? WHERE id=?', (dump(v),v['id']))
                exists = c.execute('SELECT 1 FROM import_items WHERE import_id=? AND vacancy_id=?', (ident,v['id'])).fetchone()
                if not exists:
                    c.execute('INSERT INTO import_items VALUES(?,?,?)', (ident,v['id'],dump(v)))
                    j['unique_seen'] += 1
                    j[kind] += 1
            j['pages_fetched'] += 1
            j['truncated'] = found > min(2000, j['max_pages']*100)
            self.save_import(c,j)
            return j

    def delete_archived(self, external_id):
        """Only call after explicit archive confirmation; FK deletes snapshots too."""
        with self.connection() as c:
            c.execute("DELETE FROM vacancies WHERE source='hh' AND external_id=?", (external_id,))

    def finish_import(self, ident, error=None):
        with self.connection() as c:
            j = self.get_import(ident,c)
            j.update(status=('partial' if j['pages_fetched'] else 'failed') if error else 'succeeded', finished_at=now(), error=error)
            if error:
                j['truncated'] = True
            self.save_import(c,j)
            return j

    def imports(self):
        with self.connection() as c:
            return [self.get_import(r[0],c) for r in c.execute('SELECT id FROM imports ORDER BY created_at DESC,id DESC').fetchall()]

    def select(self, filters):
        with self.connection() as c:
            if filters.get('import_id'):
                self.get_import(filters['import_id'], c)
                rows = c.execute('SELECT snapshot_json FROM import_items WHERE import_id=?', (filters['import_id'],)).fetchall()
            else:
                rows = c.execute('SELECT dto_json FROM vacancies').fetchall()
            result = [json.loads(r[0]) for r in rows]
            result = [v for v in result if matches(v, filters)]
            ids = {v['id'] for v in result}
            contributing = {r['import_id'] for r in c.execute('SELECT import_id,vacancy_id FROM import_items') if r['vacancy_id'] in ids}
            if filters.get('import_id'):
                contributing = {filters['import_id']}
            jobs = [self.get_import(i,c) for i in sorted(contributing)]
        warnings = ['LIMITED_SAMPLE', 'AUTH_DEPENDENT']
        if any(j['status'] in ('partial','failed') for j in jobs):
            warnings.append('PARTIAL_IMPORT')
        if any(v['freshness'] != 'current' for v in result):
            warnings.append('STALE_DATA')
        scope = dict(kind='import_snapshot' if filters.get('import_id') else 'local_current', import_id=filters.get('import_id'), total_matched=len(result), as_of=now(), imports=[{k:j.get(k) for k in ('id','status','found_reported','unique_seen','truncated','created_at')} for j in jobs], warning_codes=warnings)
        return result, scope


def validate_import(b):
    require(isinstance(b,dict) and set(b)=={'source','query','max_pages'}, 'body')
    require(b['source']=='hh', 'source')
    require(type(b['max_pages']) is int and 1 <= b['max_pages'] <= 20, 'max_pages')
    q=b['query']
    require(isinstance(q,dict) and set(q)=={'text','area_ids','experience_ids','only_with_salary','published_from','published_to'}, 'query')
    require(isinstance(q['text'],str) and len(q['text'])<=200, 'query.text')
    require(type(q['only_with_salary']) is bool, 'query.only_with_salary')
    q=dict(q)
    for k in ('area_ids','experience_ids'):
        require(isinstance(q[k],list) and len(q[k])<=20 and all(isinstance(s,str) and 0<len(s)<=64 for s in q[k]),k)
        q[k]=sorted(set(q[k]))
    for k in ('published_from','published_to'):
        if q[k] is not None:
            q[k]=timestamp(q[k])
    require(not(q['published_from'] and q['published_to']) or q['published_from']<=q['published_to'], 'published_from')
    return dict(source='hh',query=q,max_pages=b['max_pages'])


def normalize(item):
    require(isinstance(item,dict),'item')
    require(item.get('archived') is not True, 'archived')
    def text(x, field, limit=1000):
        require(isinstance(x,str) and 0<len(x)<=limit, field)
        return x
    external=text(item['id'],'id',64)
    require(external.isascii() and external.isdigit(),'id')
    from urllib.parse import urlsplit
    url=text(item['alternate_url'],'alternate_url',2048)
    u=urlsplit(url)
    require(u.scheme=='https' and u.hostname in ('hh.ru','www.hh.ru') and not u.username and not u.password and u.port in (None,443), 'alternate_url')
    a=item['area']; e=item.get('employer') or {}
    require(isinstance(a,dict) and isinstance(e,dict),'area')
    s=item.get('salary')
    require(s is None or isinstance(s,dict),'salary')
    original=None
    if s:
        original={k:s.get(k) for k in ('from','to','currency','gross')}
    # Legacy salary has no period: never infer month. New salary_range is not silently coerced.
    normalized={k:None for k in ('from','to','currency','gross','period')}
    if s:
        for k in ('from','to'):
            normalized[k]=None if s.get(k) is None else str(s[k])
        for k in ('currency','gross'):
            normalized[k]=s.get(k)
        require(normalized['currency'] is None or isinstance(normalized['currency'],str) and len(normalized['currency'])<=32,'currency')
        require(normalized['gross'] is None or type(normalized['gross']) is bool,'gross')
    exp=item.get('experience')
    require(exp is None or isinstance(exp,dict),'experience')
    for k in ('id','name'):
        require(e.get(k) is None or isinstance(e[k],str) and len(e[k])<=1000,'employer')
    return dict(source='hh',external_id=external,title=text(item['name'],'name'),alternate_url=url,employer={'id':e.get('id'),'name':e.get('name')}, area={'id':text(a['id'],'area.id',64),'name':text(a['name'],'area.name')}, experience_ids=[text(exp['id'],'experience.id',64)] if exp else [], published_at=timestamp(item['published_at']),salary=normalized,salary_original=original)

FILTERS={'q','area_id','experience_id','published_from','published_to','has_salary','currency','gross','period','salary_min','salary_max','import_id','freshness'}

def parse_filters(params, page=True):
    allowed=FILTERS | ({'page','per_page','sort'} if page else set())
    require(not(set(params)-allowed), 'query', 'unknown parameter')
    f={}
    for k, vals in params.items():
        require(len(vals)<=20 if k in ('area_id','experience_id') else len(vals)==1, k)
        require(all(isinstance(v,str) and len(v)<=200 for v in vals), k)
        f[k]=list(dict.fromkeys(vals)) if k in ('area_id','experience_id') else vals[0]
    for k in ('area_id','experience_id'):
        require(all(0<len(v)<=64 for v in f.get(k,[])), k)
    f['q']=f.get('q','').strip().casefold()
    for k in ('published_from','published_to'):
        if k in f: f[k]=timestamp(f[k])
    require(not(f.get('published_from') and f.get('published_to')) or datetime.fromisoformat(f['published_from'])<=datetime.fromisoformat(f['published_to']), 'published_from')
    for k in ('has_salary','gross'):
        if k in f:
            require(f[k] in (('true','false','unknown') if k=='gross' else ('true','false')),k)
    for k in ('salary_min','salary_max'):
        if k in f:
            require(bool(re.fullmatch(r'\d+(?:\.\d+)?',f[k])),k)
            try: f[k]=decimal(f[k])
            except ValueError: raise Error(field=k) from None
            require(bool(f.get('currency')) and bool(f.get('period')),k,'currency and period required')
    require('salary_min' not in f or 'salary_max' not in f or f['salary_min']<=f['salary_max'], 'salary_min')
    if 'import_id' in f:
        try: f['import_id']=str(UUID(f['import_id']))
        except ValueError: raise Error(field='import_id') from None
    f['freshness']=f.get('freshness','current')
    require(f['freshness'] in ('current','unknown','stale','all'),'freshness')
    if page:
        for k,default in (('page',0),('per_page',20)):
            val=f.get(k,str(default))
            require(bool(re.fullmatch(r'\d{1,9}',val)),k)
            f[k]=int(val)
        require(1<=f['per_page']<=100,'per_page')
        f['sort']=f.get('sort','published_at_desc')
        require(f['sort'] in ('published_at_desc','published_at_asc','salary_desc','salary_asc'),'sort')
        if f['sort'].startswith('salary'):
            require(all(f.get(k) for k in ('currency','period','gross')),'sort','currency, period and gross required')
    return f

def matches(v,f):
    if f['freshness']!='all' and v['freshness']!=f['freshness']: return False
    if f['q'] and not any(f['q'] in (s or '').casefold() for s in (v['title'],v['employer']['name'])): return False
    if f.get('area_id') and v['area']['id'] not in f['area_id']: return False
    if f.get('experience_id') and not set(v['experience_ids']).intersection(f['experience_id']): return False
    if f.get('published_from') and datetime.fromisoformat(v['published_at'])<datetime.fromisoformat(f['published_from']): return False
    if f.get('published_to') and datetime.fromisoformat(v['published_at'])>datetime.fromisoformat(f['published_to']): return False
    s=v['salary']; state,a,b,_=salary(v)
    if 'has_salary' in f and (state=='valid') != (f['has_salary']=='true'): return False
    for k in ('currency','period'):
        if k in f and s[k]!=f[k]: return False
    if 'gross' in f and s['gross']!={'true':True,'false':False,'unknown':None}[f['gross']]: return False
    if 'salary_min' in f or 'salary_max' in f:
        if state!='valid': return False
        if b is not None and 'salary_min' in f and b<f['salary_min']: return False
        if a is not None and 'salary_max' in f and a>f['salary_max']: return False
    return True

def ordered(vs,f):
    vs=sorted(vs,key=lambda v:v['id'])
    if f['sort'].startswith('published'):
        return sorted(vs,key=lambda v:v['published_at'],reverse=f['sort'].endswith('desc'))
    valid=[v for v in vs if salary(v)[0]=='valid']
    return sorted(valid,key=lambda v:salary(v)[3],reverse=f['sort'].endswith('desc'))+[v for v in vs if salary(v)[0]!='valid']

def analytics(vs,scope):
    with localcontext() as ctx:
        ctx.prec = 128
        return _analytics(vs,scope)

def _analytics(vs,scope):
    groups={}; invalid=missing=0
    for v in vs:
        state,a,b,rep=salary(v)
        if state=='invalid': invalid+=1; continue
        if state=='missing': missing+=1; continue
        s=v['salary']; key=(s['currency'],s['gross'],s['period'])
        groups.setdefault(key,[]).append((a,b,rep))
    fmt=lambda d: str(d.quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
    out=[]
    for (currency,gross,period),rows in sorted(groups.items(),key=lambda pair:tuple((x is not None,str(x)) for x in pair[0])):
        reps=sorted(r[2] for r in rows); n=len(rows)
        out.append(dict(currency=currency,gross=gross,period=period,n=n,count_closed=sum(a is not None and b is not None for a,b,_ in rows),count_from_only=sum(a is not None and b is None for a,b,_ in rows),count_to_only=sum(a is None and b is not None for a,b,_ in rows),mean=fmt(sum(reps)/n),median=fmt((reps[(n-1)//2]+reps[n//2])/2),min=fmt(min(a if a is not None else b for a,b,_ in rows)),max=fmt(max(b if b is not None else a for a,b,_ in rows))))
    total=len(vs); included=total-invalid-missing
    return dict(scope=scope,total_matched=total,with_salary=included,without_salary=missing,invalid_salary=invalid,included_in_groups=included,coverage=str((Decimal(included)/total).quantize(Decimal('.0001'),rounding=ROUND_HALF_UP)) if total else None,groups=out)
