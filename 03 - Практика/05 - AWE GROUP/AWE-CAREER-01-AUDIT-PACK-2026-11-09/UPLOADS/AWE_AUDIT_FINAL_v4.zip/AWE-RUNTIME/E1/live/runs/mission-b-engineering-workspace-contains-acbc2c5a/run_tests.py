"""Minimal pytest-style runner using only the Python standard library.

Collects functions named test_* from a module and runs each one. A test passes
when it returns without raising. Nothing here is installed; stdlib only.
"""
import importlib
import sys
import traceback


def main(module_name):
    module = importlib.import_module(module_name)
    names = sorted(n for n in dir(module) if n.startswith("test_"))
    failed = 0
    for name in names:
        try:
            getattr(module, name)()
        except Exception:
            failed += 1
            print(f"FAIL {name}")
            traceback.print_exc()
        else:
            print(f"PASS {name}")
    print(f"\n{len(names) - failed} passed, {failed} failed, {len(names)} total")
    return 1 if failed or not names else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "test_stats"))
