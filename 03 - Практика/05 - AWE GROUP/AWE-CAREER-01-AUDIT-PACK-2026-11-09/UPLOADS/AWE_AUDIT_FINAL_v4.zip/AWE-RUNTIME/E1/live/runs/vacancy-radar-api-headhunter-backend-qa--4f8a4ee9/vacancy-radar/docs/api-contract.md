# REST v1 — граница frontend/backend

Статус: **контракт с реализованными read-only маршрутами** (t2–t4). POST /imports остаётся закрыт: валидный запрос получает 403 IMPORT_DISABLED; 202/идемпотентное выполнение описывают целевой режим, а не доступный HTTP-импорт. Prefix `/api/v1`; JSON UTF-8; snake_case; timestamps ISO8601 UTC с Z, UUID строки, external_id строки, деньги decimal-строки (не binary float). Nullable поля всегда присутствуют. Массивы пустые `[]`. Неизвестные query/body поля — 422. Локальный API не копирует молчаливое игнорирование HH. Вакансии не создаются пользователем.

## Маршруты
|Метод/путь|Результат|
|---|---|
|GET /health|200 `{ "status":"ok", "stage":"scaffold", "database":"ok", "imports_enabled":false }`|
|POST /imports|202 Import; Location: /api/v1/imports/{id}|
|GET /imports|200 `{items:Import[],total:integer,page:integer,per_page:integer}`; page=0, per_page=20 (1..100), sort created_at DESC,id DESC|
|GET /imports/{uuid}|200 Import; 404 если нет|
|GET /vacancies|200 Page<Vacancy> + scope|
|GET /vacancies/{integer_id}|200 Vacancy; 404 если нет/удалена; необязательный import_id возвращает snapshot или 404|
|GET /analytics/salaries|200 Analytics + scope, общие фильтры списка, без сортировки/пагинации|

GET-маршруты реализованы; неизвестный путь — 404. Неподдерживаемый метод известного API-пути — 405 + Allow. health.stage пока сохраняет legacy-значение scaffold; imports_enabled=false.

### POST /imports
Тело:
```json
{"source":"hh","query":{"text":"","area_ids":[],"experience_ids":[],"only_with_salary":false,"published_from":null,"published_to":null},"max_pages":20}
```
Все поля обязательны, query.text до 200 символов; IDs непустые строки до 64 символов, не более 20 в каждом массиве, повторения нормализуются. published_from/to — nullable ISO8601 с timezone, from<=to. max_pages integer 1..20. Upstream per_page всегда 100, page 0..max_pages-1. Только эти upstream-фильтры поддержаны в MVP. only_with_salary передается HH, но не гарантирует валидность суммы. Сортировка upstream publication_time; фактические параметры записать в query. Не принимать URL, токены, контакты, HTML, currency/salary/schedule от клиента.

Заголовок `Idempotency-Key` обязателен, 1..128 ASCII букв/цифр/`-_.`. Ключ хранится локально без автоматического TTL: тот же ключ+каноническое тело возвращает исходный Import (200), другое тело — 409 IDEMPOTENCY_CONFLICT. Сначала проверить ключ, потом ограничение одного active job. Без допуска — 403 IMPORT_DISABLED; без настроенной идентификации — 503 CLIENT_NOT_CONFIGURED. Это не доказательство юридического соответствия.

Import DTO: id, source, query, max_pages, status (queued/running/succeeded/partial/failed), created_at, started_at nullable, finished_at nullable, found_reported nullable integer, pages_fetched, items_received, unique_seen, inserted, updated, unchanged, invalid, retrieval_cap=2000, truncated boolean, error nullable ErrorDetail. Counters относятся к этому запуску, не всей БД. inserted+updated+unchanged=unique_seen (по окончании, повторный ID учитывается один раз); items_received может быть больше. truncated=true если found_reported превышает доступную глубину/заданный бюджет страниц или выполнение прервано с недополученными страницами. succeeded не означает полную базу HH.

### Общие локальные фильтры
- q: строка 0..200, trim; буквальный case-insensitive substring по title/employer_name, без языка запросов HH. Unicode casefold в реализации; `%` и `_` — обычные символы.
- area_id, experience_id: повторяющиеся query-параметры, OR внутри набора и AND между наборами; до 20. experience_ids сохраняются в Vacancy.
- published_from, published_to: ISO8601 timezone, обе границы включены, UTC; from<=to.
- has_salary: true/false, по наличию хотя бы одной валидной границы; omitted — любые.
- currency: один код точным совпадением; gross: true/false/unknown; period: один код.
- salary_min, salary_max: неотрицательные decimal-строки, min<=max. Только с явными currency и period; сравнение пересечения вилки с диапазоном, отсутствующая граница — бесконечность, полностью пустая/невалидная вилка не проходит. Никакого пересчета валют/налогов.
- import_id: UUID; неизвестный импорт 404. freshness: current (default), stale, unknown, all.

GET vacancies: page integer >=0, per_page 1..100 default20; sort = published_at_desc (default), published_at_asc, salary_desc, salary_asc. Зарплатная сортировка требует currency, period и gross (включая unknown), используется representative; null всегда последние. Tie-breaker id ASC. Offset pagination: total после фильтров до LIMIT, пустая страница сверх конца — 200. Гарантия стабильности только при неизменной БД, не snapshot isolation между HTTP-запросами.

Vacancy DTO: id integer, source='hh', external_id string, title string, alternate_url string, employer `{id:string|null,name:string|null}`, area `{id:string,name:string}`, experience_ids:string[], published_at, first_seen_at, last_seen_at, last_verified_at nullable, freshness enum, salary `{from:string|null,to:string|null,currency:string|null,gross:boolean|null,period:string|null}`, salary_original object|null. Никогда не вставлять source text как HTML. Архивные удалены, не возвращаются.

Scope: `{kind:"local_current"|"import_snapshot",import_id:string|null,total_matched:integer,as_of:timestamp,imports:[{id,status,found_reported,unique_seen,truncated,created_at}],warning_codes:string[]}`. Для local_current список imports — contributing imports, не все существующие задания. warning_codes enum: LIMITED_SAMPLE, PARTIAL_IMPORT, STALE_DATA, AUTH_DEPENDENT. LIMITED_SAMPLE всегда для данных HH; это не репрезентативная оценка рынка.

Analytics: `{scope,total_matched,with_salary,without_salary,invalid_salary,included_in_groups,coverage:string|null,groups:[{currency:string|null,gross:boolean|null,period:string|null,n,count_closed,count_from_only,count_to_only,mean:string|null,median:string|null,min:string|null,max:string|null}]}`. coverage строка с 4 десятичными, HALF_UP; группы стабильны по currency, gross, period (null первым); определения строго в data-model-and-analytics.md. Пустой ответ — total=0, groups=[], coverage=null.

## Ошибки
Форма всех ошибок: `{"error":{"code":"VALIDATION_ERROR","message":"...","details":[{"field":"page","reason":"must be >= 0"}],"request_id":"..."}}`. ErrorDetail в Import — та же внутренняя структура code/message/details/request_id, без внешнего error. Текст человеку, логика UI только по code. Не возвращать секреты или сырые тела HH.

400 INVALID_JSON; 403 IMPORT_DISABLED / ORIGIN_DENIED; 404 NOT_FOUND; 405 METHOD_NOT_ALLOWED; 409 IMPORT_IN_PROGRESS / IDEMPOTENCY_CONFLICT; 413 PAYLOAD_TOO_LARGE; 415 UNSUPPORTED_MEDIA_TYPE; 422 VALIDATION_ERROR; 429 LOCAL_RATE_LIMIT; 500 INTERNAL_ERROR; 501 NOT_IMPLEMENTED; 503 CLIENT_NOT_CONFIGURED / DATABASE_BUSY. Для синхронных proxy-операций (не предусмотрены MVP) — 502 UPSTREAM_ERROR, 504 UPSTREAM_TIMEOUT. В асинхронном задании upstream ошибки записываются в Import.error: HH_AUTH_REQUIRED, HH_FORBIDDEN, HH_CAPTCHA_REQUIRED, HH_RATE_LIMIT, HH_UNAVAILABLE, HH_TIMEOUT, INVALID_UPSTREAM_DATA, INTERRUPTED_BY_RESTART. GET задания остается 200, даже если статус failed. Повторяемые временные ошибки только ограниченное число раз, статус/partial сохраняется.

Frontend можно реализовывать по этому документу с отдельными явно тестовыми fixtures; не подмешивать mock вакансии в рабочую БД. OpenAPI-машиночитаемая спецификация и conformance tests — следующий этап, не уже выполненная работа.
