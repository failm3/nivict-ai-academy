-- awe.e1.live/1 — durable state for the live mission runtime.
-- Applied exactly once; the runner records the filename in live.schema_migrations.

create schema if not exists live;

create table if not exists live.schema_migrations (
  filename text primary key,
  applied_at timestamptz not null default now()
);

create table if not exists live.missions (
  mission_id text primary key,
  title text not null,
  goal text not null,
  constraints_json jsonb not null default '[]'::jsonb,
  acceptance_json jsonb not null default '[]'::jsonb,
  artifacts_json jsonb not null default '[]'::jsonb,
  workspace text not null,
  budget_usd numeric(12, 6) not null,
  spent_usd numeric(12, 6) not null default 0,
  status text not null default 'NEW',
  stop_reason text,
  head_model text,
  reviewer_model text,
  plan_json jsonb,
  summary text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists live.tasks (
  mission_id text not null references live.missions(mission_id),
  task_id text not null,
  title text not null,
  role text not null,
  kind text not null default 'work',
  instruction text not null,
  depends_on jsonb not null default '[]'::jsonb,
  model text,
  status text not null default 'PENDING',
  attempts integer not null default 0,
  result text,
  verdict text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (mission_id, task_id)
);

create table if not exists live.events (
  id bigserial primary key,
  mission_id text not null,
  task_id text,
  at timestamptz not null default now(),
  kind text not null,
  data jsonb not null default '{}'::jsonb
);
create index if not exists events_mission_idx on live.events (mission_id, id);

create table if not exists live.model_calls (
  id bigserial primary key,
  mission_id text not null,
  task_id text,
  at timestamptz not null default now(),
  purpose text not null,
  model text not null,
  prompt_tokens integer not null default 0,
  completion_tokens integer not null default 0,
  cost_usd numeric(12, 6) not null default 0,
  ok boolean not null,
  error text
);

create table if not exists live.tool_calls (
  id bigserial primary key,
  mission_id text not null,
  task_id text,
  at timestamptz not null default now(),
  tool text not null,
  args jsonb not null default '{}'::jsonb,
  ok boolean not null,
  result_preview text,
  ms integer
);

create table if not exists live.artifacts (
  id bigserial primary key,
  mission_id text not null,
  task_id text,
  at timestamptz not null default now(),
  path text not null,
  bytes integer not null,
  sha256 text not null
);

create table if not exists live.checkpoints (
  mission_id text primary key references live.missions(mission_id),
  at timestamptz not null default now(),
  state jsonb not null
);
