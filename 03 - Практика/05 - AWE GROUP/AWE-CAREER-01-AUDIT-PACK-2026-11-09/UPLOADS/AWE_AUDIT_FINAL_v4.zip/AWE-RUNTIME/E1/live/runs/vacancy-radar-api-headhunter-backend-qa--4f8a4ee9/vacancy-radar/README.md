# Vacancy Radar

Локальное исследование **сохранённой ограниченной выборки**, не всего рынка вакансий. Python HTTP API + SQLite + frontend на нативных ES modules, один origin. Рабочая БД не заполняется тестовыми данными.

**Импорт HH сейчас закрыт**: `POST /api/v1/imports` после проверки запроса возвращает `403 IMPORT_DISABLED`. Адаптер и хранилище реализованы, но нет подтверждённого допуска приложения для данного назначения. Это не готовый публичный сервис поиска HH. См. [compliance](docs/hh-compliance.md), [проверки и блокеры](reports/integration.md).

## Требования и установка

Python >=3.12 со стандартным SQLite >=3.35, Node >=22, npm >=10. Проверено на Python 3.14.4 / SQLite 3.46.1 / Node 22.23.3 / npm 10.9.9. Python/npm runtime-зависимостей нет. `requirements.lock` фиксирует пустой набор Python-пакетов, `frontend/package-lock.json` — npm-граф без зависимостей. Это lock зависимостей, не закреплённый образ ОС.

Из каталога `vacancy-radar`:
```sh
python3 scripts/check_runtime.py
npm --prefix frontend ci --ignore-scripts --no-audit --no-fund
python3 -m backend.app.migrate
python3 -m backend.app
# http://127.0.0.1:8000 ; остановка Ctrl+C
```
Установка Python-пакетов не нужна, pip необязателен. Если нужен отдельный venv: `python3 -m venv .venv` и активировать его до команд. На этой среде pip и make отсутствуют; прямые команды выше проверены. Makefile даёт эквивалентные `make install migrate run build check test`, если установлен make.

## Конфигурация

`.env.example` — только документация, автоматически не читается. Экспортируйте переменные в shell:

|Переменная|Назначение|
|---|---|
|`VR_HOST`|Только `127.0.0.1`, другие значения отклоняются|
|`VR_PORT`|8000 по умолчанию; 0 — свободный порт для тестов|
|`VR_DB_PATH`|`data/vacancy-radar.sqlite3`; путь относительно проекта или абсолютный внутри него|
|`VR_IMPORTS_ENABLED`|Не включает импорт: gate в коде закрыт независимо от env|
|`HH_USER_AGENT`|Реальное имя зарегистрированного приложения и контакт для будущего разрешённого клиента; сейчас HTTP-путь не запускает адаптер|

Не хранить токены в git. Не выставлять сервер в интернет: это loopback-инструмент без production auth/TLS.

## Сборка, миграции, тесты

```sh
npm --prefix frontend run check
npm --prefix frontend run build
python3 -m backend.app.migrate
python3 -m unittest discover -s backend/tests -v
npm --prefix frontend test
python3 -m unittest discover -s tests -v
```
Миграции `backend/migrations/*.sql` применяются по `PRAGMA user_version` при запуске и отдельной командой, повторный запуск безопасен. Сделайте backup SQLite при остановленном сервере перед обновлением. `backend/schema.sql` — исторический bootstrap, не применять вместо миграций.

`frontend/dist` — проверенная статическая сборка без фикстур. Локальный Python-сервер обслуживает исходные `frontend/index.html` и `src/`; сборка не требует отдельного dev-сервера. При отдельной публикации dist необходим same-origin reverse proxy `/api/v1` к backend; такой deployment здесь не проверен. Не открывайте HTML через file://.

E2E запускают настоящий процесс, HTTP и SQLite в временных каталогах внутри tests, затем удаляют их. Проверяют также настоящий frontend client через Node fetch. Это **не браузерный DOM E2E**. Все импортируемые там вакансии синтетические, FakeOpener не обращается в сеть. Ошибки сети/503 — отдельные изолированные сценарии.

Для воспроизводимого журнала:
```sh
python3 scripts/record.py my-tests.log python3 -m unittest discover -s tests -v
```
Журнал в reports/logs содержит UTC-время, argv, cwd, длительность, вывод и exit code.

## Модель и API

SQLite: imports (задания, запросы, статусы/счётчики), vacancies (каноническая запись, уникальность source+external_id), import_items (принадлежность выборке и snapshot) (зарплата хранится в DTO/snapshot, отдельной таблицы наблюдений нет), idempotency_keys. Внешние ключи включены на соединениях; одна активная задача; перезапуск восстанавливает незавершённые задачи. Детали — [модель](docs/data-model-and-analytics.md), [контракт](docs/api-contract.md).

GET `/api/v1/health`, `/vacancies`, `/vacancies/{id}`, `/imports`, `/imports/{uuid}`, `/analytics/salaries`. Фильтры AND между измерениями, OR внутри повторяемых area_id/experience_id. q — буквальная casefold-подстрока названия/работодателя, не синтаксис HH. Пагинация с нуля, per_page 1..100. Неизвестные параметры — 422. Детали можно читать в snapshot по import_id. Денежные значения — decimal-строки; нет конвертации валют или смешивания gross/net/period. Пустая аналитика имеет null coverage, а не нулевую зарплату.

Будущий импорт ограничен 20 страницами по 100; found HH не означает число доступных/сохранённых вакансий. Срезы неполны, отсутствие в выдаче не доказывает закрытие вакансии, freshness и scope важны для интерпретации. Не заявляется полнота рынка.

## Диагностика

- `403 IMPORT_DISABLED`: ожидаемый gate, не исправляется env. Нужны проверка назначения, регистрация/допуск и reviewed изменение реализации.
- `403 ORIGIN_DENIED`: используйте localhost origin, без чужого Origin/Host.
- Пустой список: проверьте путь БД, freshness и фильтры; в штатной поставке реальных вакансий нет.
- `422`: проверьте типы/параметры по контракту; salary bounds требуют currency и period, сортировка зарплаты также gross.
- `DATABASE_BUSY`: остановите конкурирующий процесс, проверьте права/блокировки SQLite. Не удаляйте БД ради снятия блокировки.
- Порт занят: `VR_PORT=8001 python3 -m backend.app`.
- Нет pip/make: используйте прямые команды, runtime зависимостей Python нет.
- Нет браузера: модульные/HTTP-тесты не подтверждают адаптивную вёрстку, фокус или скриншоты; см. отчёт.
