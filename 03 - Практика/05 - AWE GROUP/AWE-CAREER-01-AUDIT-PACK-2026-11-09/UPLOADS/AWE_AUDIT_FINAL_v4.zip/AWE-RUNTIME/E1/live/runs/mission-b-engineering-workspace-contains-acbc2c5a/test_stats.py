import stats

def test_mean():
    assert stats.mean([1, 2, 3]) == 2

def test_median_odd():
    assert stats.median([3, 1, 2]) == 2

def test_median_even():
    assert stats.median([1, 2, 3, 4]) == 2.5

def test_clamp():
    assert stats.clamp(5, 0, 3) == 3
    assert stats.clamp(-1, 0, 3) == 0
