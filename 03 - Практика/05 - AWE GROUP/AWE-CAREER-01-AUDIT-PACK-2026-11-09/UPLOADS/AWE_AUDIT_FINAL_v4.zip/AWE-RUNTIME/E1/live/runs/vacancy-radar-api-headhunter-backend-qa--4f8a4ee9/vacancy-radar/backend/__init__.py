"""Vacancy Radar backend scaffold."""
