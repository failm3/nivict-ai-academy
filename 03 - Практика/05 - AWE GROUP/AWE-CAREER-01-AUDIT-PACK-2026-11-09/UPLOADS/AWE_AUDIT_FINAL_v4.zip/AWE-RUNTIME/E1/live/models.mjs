// Model registry + OpenAI-compatible Router.Cheap transport.
// Prices are USD per million tokens. They are operator estimates used for the
// local budget guard; the authoritative charge stays on the provider account.
export const PRICE_PER_MILLION = {
  'gpt-6.1-sol': {input: 1.5, output: 6},
  'gpt-6-astra': {input: 3, output: 12},
  'claude-opus-5-5': {input: 5, output: 25},
  'kimi-k3.1-pro': {input: 2, output: 8},
  'deepseek-v4-pro-0813': {input: 0.5, output: 2},
  'gemini-4-argon': {input: 1.25, output: 5},
  'qwen3.8-max': {input: 0.8, output: 3}
};
const DEFAULT_PRICE = {input: 3, output: 12};

// Role routing: head plans, workers do the tool loop, reviewer is a different
// family from the worker so QA is not self-graded.
export const ROLE_MODELS = {
  head: 'gpt-6-astra',
  worker: 'gpt-6.1-sol',
  reviewer: 'kimi-k3.1-pro',
  repair: 'deepseek-v4-pro-0813'
};

export function estimateCost(model, usage = {}) {
  const price = PRICE_PER_MILLION[model] || DEFAULT_PRICE;
  const prompt = usage.prompt_tokens || 0;
  const completion = usage.completion_tokens || 0;
  return (prompt * price.input + completion * price.output) / 1_000_000;
}

export function createRouterCheap({apiKey = process.env.AWE_ROUTERCHEAP_KEY, baseUrl = process.env.AWE_ROUTERCHEAP_BASE || 'https://router.cheap/v1', fetchImpl = globalThis.fetch, timeoutMs = 300000} = {}) {
  if (!apiKey) throw new Error('AWE_ROUTERCHEAP_KEY missing');
  async function complete({model, messages, tools, temperature = 0.2, maxTokens = 4096}) {
    const body = {model, messages, temperature, max_tokens: maxTokens};
    if (tools?.length) body.tools = tools;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let response;
    try {
      response = await fetchImpl(`${baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json'},
        body: JSON.stringify(body),
        signal: controller.signal
      });
    } finally {
      clearTimeout(timer);
    }
    const text = await response.text();
    if (!response.ok) throw new Error(`ROUTERCHEAP_HTTP_${response.status}: ${text.slice(0, 500)}`);
    const data = JSON.parse(text);
    const message = data.choices?.[0]?.message ?? {};
    return {
      model: data.model || model,
      content: message.content || '',
      toolCalls: (message.tool_calls || []).map(call => ({id: call.id, name: call.function?.name, arguments: call.function?.arguments || '{}'})),
      usage: data.usage || {},
      costUsd: estimateCost(model, data.usage || {})
    };
  }
  return {complete, estimateCost};
}
