# Fix report: even-length median

## Evidence and cause

Inspected `stats.py`, `original/stats.py`, `test_stats.py`, and `run_tests.py`. The current `stats.py` already contains the fix; no implementation or test files were edited for this report.

In `original/stats.py`, `median(xs)` sorts its input and correctly selects the middle element for odd lengths, but its even-length branch also returns `s[n // 2]`. For even lengths this selects the upper of the two middle elements rather than averaging them. From that captured source, the original implementation would return `3` for `[1, 2, 3, 4]`, whereas `test_median_even` requires `2.5`.

This is a source-based baseline finding, not an observed pre-fix test run. No captured pre-fix test output was available in the inspected files, and the original implementation was not executed for this report.

## Exact minimal implementation change

Only the even-length return expression at line 11 changes:

```python
# Before
return s[n // 2]
# After
return (s[n // 2 - 1] + s[n // 2]) / 2
```

This averages the two central sorted elements. The odd-length branch, `mean`, and `clamp` are unchanged. The existing module docstring still describes the old bug; it was not changed as part of this minimal fix.

## Observed post-fix verification

Reran exactly:

```sh
python3 run_tests.py test_stats
```

Actual output:

```text
PASS test_clamp
PASS test_mean
PASS test_median_even
PASS test_median_odd

4 passed, 0 failed, 4 total
```

Observed exit status: **0**.

The four existing tests cover mean, odd-length median, even-length median, and clamp. This result verifies those tests only; behavior outside their coverage remains unverified.

## Actual diff

Reran exactly:

```sh
diff -u original/stats.py stats.py
```

Actual output:

```diff
--- original/stats.py	2026-11-09 06:49:47.123560920 +0300
+++ stats.py	2026-11-09 06:52:17.216690571 +0300
@@ -8,7 +8,7 @@
     n = len(s)
     if n % 2 == 1:
         return s[n // 2]
-    return s[n // 2]
+    return (s[n // 2 - 1] + s[n // 2]) / 2
 
 def clamp(x, lo, hi):
     return max(lo, min(hi, x))
```

Observed exit status: **1**, the normal `diff` status indicating that the files differ.

Only `fix-report.md` was intentionally written for this task. No packages were installed.
