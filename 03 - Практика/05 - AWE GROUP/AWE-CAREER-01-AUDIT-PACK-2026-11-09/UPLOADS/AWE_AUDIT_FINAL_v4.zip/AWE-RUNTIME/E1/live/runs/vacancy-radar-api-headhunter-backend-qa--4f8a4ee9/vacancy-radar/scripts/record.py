"""Record exact argv, UTC times, exit status and combined unmodified output."""
import datetime, json, pathlib, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parents[1]
name,*cmd=sys.argv[1:]
if not name or pathlib.Path(name).name!=name or not cmd: raise SystemExit('record.py LOG_NAME COMMAND [ARGS...]')
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
try:
    p=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
except OSError as e:
    p=subprocess.CompletedProcess(cmd,127,(str(e)+'\n').encode())
with (root/'reports/logs'/name).open('wb') as f:
    f.write((f'start_utc={start}\nargv={json.dumps(cmd,ensure_ascii=False)}\ncwd={root}\n--- output ---\n').encode())
    f.write(p.stdout)
    f.write((f'\n--- end ---\nend_utc={datetime.datetime.now(datetime.timezone.utc).isoformat()}\nelapsed_seconds={time.monotonic()-clock:.3f}\nexit_code={p.returncode}\n').encode())
sys.stdout.buffer.write(p.stdout); raise SystemExit(p.returncode)
