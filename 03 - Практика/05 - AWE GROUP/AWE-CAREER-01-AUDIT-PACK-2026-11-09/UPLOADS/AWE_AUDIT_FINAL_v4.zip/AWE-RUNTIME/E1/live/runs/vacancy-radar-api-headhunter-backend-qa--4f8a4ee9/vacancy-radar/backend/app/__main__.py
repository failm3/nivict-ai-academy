"""Run from project root: python3 -m backend.app."""
import os
from pathlib import Path
from .core import ROOT, Store
from .server import make_server

def main():
    if os.environ.get('VR_HOST','127.0.0.1')!='127.0.0.1':
        raise SystemExit('May bind only to 127.0.0.1')
    path=Path(os.environ.get('VR_DB_PATH','data/vacancy-radar.sqlite3'))
    path=(ROOT/path).resolve() if not path.is_absolute() else path.resolve()
    if not path.is_relative_to(ROOT): raise SystemExit('Database must be inside vacancy-radar')
    store=Store(path)
    store.recover()
    server=make_server(store,int(os.environ.get('VR_PORT','8000')))
    print(f'Vacancy Radar: http://127.0.0.1:{server.server_port}; HH imports disabled (compliance gate)',flush=True)
    try: server.serve_forever()
    finally: server.server_close()

if __name__=='__main__': main()
