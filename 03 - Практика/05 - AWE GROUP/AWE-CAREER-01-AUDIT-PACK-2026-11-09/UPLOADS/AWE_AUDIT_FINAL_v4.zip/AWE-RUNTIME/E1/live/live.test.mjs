// Offline checks for the live runtime. Needs the local PG cluster on 5544;
// skips cleanly when it is not reachable. No network calls: the transport is fake.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdtempSync, rmSync, readFileSync, writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import test from 'node:test';
import {createLiveRuntime} from './runner.mjs';

const SOCKET = process.env.AWE_LIVE_SOCKET || '/home/nox/.awe-live-pg';
const PORT = String(process.env.AWE_LIVE_PORT || 5544);
const PSQL = process.env.AWE_LIVE_PSQL || '/usr/lib/postgresql/18/bin/psql';
const pg = spawnSync(PSQL, ['-h', SOCKET, '-p', PORT, '-U', 'awe_live', '-d', 'awe_live', '-X', '-q', '-c', 'select 1'], {encoding: 'utf8'});
const reachable = pg.status === 0;

function scripted(scripts) {
  const calls = [];
  return {
    calls,
    async complete({model, messages, tools}) {
      calls.push({model, messages, tools});
      const next = scripts.shift();
      if (!next) throw new Error(`script exhausted at call ${calls.length}`);
      const result = typeof next === 'function' ? next({model, messages, tools}) : next;
      return {model, content: '', toolCalls: [], usage: {prompt_tokens: 10, completion_tokens: 5}, costUsd: 0, ...result};
    }
  };
}

const finish = summary => ({toolCalls: [{id: 'f', name: 'finish', arguments: JSON.stringify({summary})}]});

test('retry cascades, artifacts are recorded, review verdict is stored', {skip: !reachable && 'local PG on 5544 not reachable'}, async () => {
  const root = mkdtempSync(path.join(tmpdir(), 'awe-live-'));
  const transport = scripted([
    {content: JSON.stringify({title: 't', goal: 'g', constraints: [], acceptance: [], artifacts: [], tasks: [
      {task_id: 't1', title: 'write', role: 'worker', kind: 'work', instruction: 'write out.txt', depends_on: []},
      {task_id: 't2', title: 'review', role: 'reviewer', kind: 'review', instruction: 'check out.txt', depends_on: ['t1']}
    ]})},
    {toolCalls: [{id: 'w', name: 'write_file', arguments: JSON.stringify({path: 'out.txt', content: 'hello'})}]},
    finish('wrote out.txt'),
    finish('verified: out.txt contains hello')
  ]);
  try {
    const rt = await createLiveRuntime({socketDir: SOCKET, port: Number(PORT), database: 'awe_live', workspaceRoot: root, transport});
    const id = rt.submit('offline fixture mission');
    const status = await rt.run(id);
    assert.equal(status.mission.status, 'COMPLETED');
    assert.equal(status.artifacts.length, 1);
    assert.equal(status.artifacts[0].path, 'out.txt');
    assert.equal(status.artifacts[0].sha256.length, 64);
    assert.equal(readFileSync(path.join(root, id, 'out.txt'), 'utf8'), 'hello');
    const review = status.tasks.find(t => t.kind === 'review');
    assert.equal(review.verdict, 'verified: out.txt contains hello');

    const reset = rt.retry(id, ['t1']);
    assert.deepEqual(reset.reset.sort(), ['t1', 't2']);
    const after = rt.status(id);
    assert.equal(after.mission.status, 'PLANNED');
    assert.ok(after.tasks.every(t => t.status === 'PENDING' && t.verdict === null));
  } finally {
    rmSync(root, {recursive: true, force: true});
  }
});

test('step limit ends truncated with a finish-only summary call', {skip: !reachable && 'local PG on 5544 not reachable'}, async () => {
  const root = mkdtempSync(path.join(tmpdir(), 'awe-live-'));
  const transport = scripted([
    {content: JSON.stringify({title: 't', tasks: [
      {task_id: 't1', title: 'loop', role: 'worker', kind: 'work', instruction: 'do work', depends_on: []},
      {task_id: 't2', title: 'review', role: 'reviewer', kind: 'review', instruction: 'check', depends_on: ['t1']}
    ]})},
    // 25 work steps that never finish. The first writes a file long enough
    // that every later read_file reply exceeds the compaction threshold.
    () => ({toolCalls: [{id: 'w', name: 'write_file', arguments: JSON.stringify({path: 'big.txt', content: 'x'.repeat(1000)})}]}),
    ...Array.from({length: 24}, () => () => ({toolCalls: [{id: 'r', name: 'read_file', arguments: JSON.stringify({path: 'big.txt'})}]})),
    ({tools}) => {
      assert.deepEqual(tools.map(s => s.function.name), ['finish']);
      return finish('partial: nothing written');
    },
    finish('review of a truncated task')
  ]);
  try {
    const rt = await createLiveRuntime({socketDir: SOCKET, port: Number(PORT), database: 'awe_live', workspaceRoot: root, transport});
    const id = rt.submit('truncation fixture');
    const status = await rt.run(id);
    const work = status.tasks.find(t => t.task_id === 't1');
    assert.equal(work.status, 'FAILED');
    const events = rt.eventsSince(id);
    assert.ok(events.some(e => e.kind === 'task.truncated'));
    // The final summary call must have seen compacted history, not 25 full errors.
    const summaryCall = transport.calls.at(-2);
    const toolReplies = summaryCall.messages.filter(m => m.role === 'tool').map(m => m.content);
    assert.ok(toolReplies.filter(c => c.startsWith('[compacted]')).length >= 10);
    assert.equal(status.mission.status, 'INCOMPLETE');
  } finally {
    rmSync(root, {recursive: true, force: true});
  }
});
