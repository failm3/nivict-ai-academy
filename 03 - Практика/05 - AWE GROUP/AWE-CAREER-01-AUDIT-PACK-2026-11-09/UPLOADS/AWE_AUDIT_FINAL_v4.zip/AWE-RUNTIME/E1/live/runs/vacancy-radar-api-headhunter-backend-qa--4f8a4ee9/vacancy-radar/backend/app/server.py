"""Loopback API; approval gate deliberately closed pending documented HH permission."""
import json
import re
import sqlite3
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from .core import ROOT, Error, require, parse_filters, ordered, analytics, validate_import

# Not an environment toggle: legal permission, registration and refresh/delete policy
# remain unconfirmed. Opening this gate requires a reviewed implementation change.
IMPORTS_ENABLED=False

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT/'frontend'),**kwargs)

    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    def json_response(self,status,payload,headers=None):
        raw=json.dumps(payload,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status)
        for k,v in (headers or {}).items(): self.send_header(k,v)
        for k,v in {'Content-Type':'application/json; charset=utf-8','Content-Length':str(len(raw)),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"}.items(): self.send_header(k,v)
        self.end_headers()
        self.wfile.write(raw)

    def secure(self):
        host=self.headers.get('Host','')
        expected=f'127.0.0.1:{self.server.server_port}'
        if host!=expected:
            raise Error(403,'ORIGIN_DENIED')
        origin=self.headers.get('Origin')
        if origin is not None and origin!='http://'+expected:
            raise Error(403,'ORIGIN_DENIED')
        if self.headers.get('Sec-Fetch-Site')=='cross-site':
            raise Error(403,'ORIGIN_DENIED')

    def dispatch(self):
        self.secure()
        parsed=urlsplit(self.path)
        try:
            params=parse_qs(parsed.query,keep_blank_values=True,max_num_fields=100,strict_parsing=True)
        except ValueError:
            raise Error(field='query') from None
        path=parsed.path
        prefix='/api/v1'
        route=path[len(prefix):] if path.startswith(prefix+'/') else None
        known=route in ('/health','/imports','/vacancies','/analytics/salaries') or bool(re.fullmatch(r'/(?:imports|vacancies)/[^/]+',route or ''))
        if self.command!='GET':
            if self.command=='POST' and route=='/imports':
                return self.post_import(params)
            raise Error(405 if known else 404,'METHOD_NOT_ALLOWED' if known else 'NOT_FOUND')
        store=self.server.store
        if route=='/health':
            require(not params,'query')
            with store.connection() as c: c.execute('SELECT 1')
            return self.json_response(200,dict(status='ok',stage='backend',database='ok',imports_enabled=IMPORTS_ENABLED))
        if route=='/imports':
            require(not(set(params)-{'page','per_page'}),'query')
            f=parse_filters(params)
            jobs=store.imports(); start=f['page']*f['per_page']
            return self.json_response(200,dict(items=jobs[start:start+f['per_page']],total=len(jobs),page=f['page'],per_page=f['per_page']))
        if route and route.startswith('/imports/'):
            require(not params,'query')
            return self.json_response(200,store.get_import(route.split('/')[-1]))
        if route in ('/vacancies','/analytics/salaries'):
            f=parse_filters(params,page=route=='/vacancies')
            vs,scope=store.select(f)
            if route=='/analytics/salaries':
                return self.json_response(200,analytics(vs,scope))
            vs=ordered(vs,f); start=f['page']*f['per_page']
            return self.json_response(200,dict(items=vs[start:start+f['per_page']],total=len(vs),page=f['page'],per_page=f['per_page'],scope=scope))
        if route and route.startswith('/vacancies/'):
            require(not(set(params)-{'import_id'}),'query')
            f=parse_filters({**params,'freshness':['all']},page=False)
            vs,_=store.select(f)
            ident=route.split('/')[-1]
            v=next((v for v in vs if str(v['id'])==ident),None)
            if v is None: raise Error(404,'NOT_FOUND')
            return self.json_response(200,v)
        if path in ('/','/index.html','/src/app.js','/src/style.css'):
            return super().do_GET()
        raise Error(404,'NOT_FOUND')

    def post_import(self,params):
        require(not params,'query')
        if self.headers.get_content_type()!='application/json': raise Error(415,'UNSUPPORTED_MEDIA_TYPE')
        if self.headers.get('Transfer-Encoding'): raise Error(400,'INVALID_JSON')
        length=self.headers.get('Content-Length','')
        if not re.fullmatch(r'\d{1,10}',length): raise Error(400,'INVALID_JSON')
        length=int(length)
        if length>16384: raise Error(413,'PAYLOAD_TOO_LARGE')
        try:
            def unique(pairs):
                result={}
                for k,v in pairs:
                    if k in result: raise ValueError('duplicate key')
                    result[k]=v
                return result
            body=json.loads(self.rfile.read(length),object_pairs_hook=unique,parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except (ValueError,UnicodeError,RecursionError):
            raise Error(400,'INVALID_JSON') from None
        validate_import(body)
        key=self.headers.get('Idempotency-Key','')
        require(bool(re.fullmatch(r'[A-Za-z0-9_.-]{1,128}',key)),'Idempotency-Key')
        # Never create a job that cannot legally be executed.
        raise Error(403,'IMPORT_DISABLED')

    def handle_request(self):
        try:
            self.dispatch()
        except Error as exc:
            headers={'Allow':'GET, POST' if urlsplit(self.path).path=='/api/v1/imports' else 'GET'} if exc.status==405 else None
            self.json_response(exc.status,{'error':exc.detail},headers)
        except sqlite3.OperationalError as exc:
            code='DATABASE_BUSY' if 'locked' in str(exc).lower() else 'INTERNAL_ERROR'
            err=Error(503 if code=='DATABASE_BUSY' else 500,code)
            self.json_response(err.status,{'error':err.detail})
        except (BrokenPipeError,ConnectionResetError,TimeoutError):
            pass
        except Exception:
            err=Error(500,'INTERNAL_ERROR')
            self.json_response(500,{'error':err.detail})
        finally:
            self.close_connection=True

    do_GET=handle_request
    do_POST=handle_request
    do_PUT=handle_request
    do_PATCH=handle_request
    do_DELETE=handle_request
    do_OPTIONS=handle_request
    do_HEAD=handle_request


def make_server(store,port=8000):
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.store=store
    return server
