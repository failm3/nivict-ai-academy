// Live mission runner: natural-language mission -> head plan -> per-task agent
// tool loops -> independent review -> durable state with checkpoint/resume.
import {randomUUID} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createDb, sqlJson, sqlLiteral} from './db.mjs';
import {ROLE_MODELS, createRouterCheap} from './models.mjs';
import {createTools} from './tools.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MIGRATION = path.join(HERE, 'migrations', '0001-live.sql');

const MAX_STEPS = {work: 25, review: 25, repair: 15};
const LOOP_DETECT_WINDOW = 4;
// History compaction: the newest tool replies stay verbatim, older ones are
// clipped so a long research loop does not resend megabytes every step.
const KEEP_TOOL_REPLIES = 6;
const COMPACT_CHARS = 400;
const TOOL_REPLY_CHARS = 6000;

function slug(text) {
  const base = text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  return base || 'mission';
}

// Shrinks old tool replies in place. Full replies are counted from the end,
// so the model always sees its latest observations intact.
function compactHistory(messages) {
  const toolIdx = [];
  messages.forEach((m, i) => { if (m.role === 'tool') toolIdx.push(i); });
  for (const i of toolIdx.slice(0, -KEEP_TOOL_REPLIES)) {
    const content = messages[i].content;
    if (typeof content === 'string' && !content.startsWith('[compacted]') && content.length > COMPACT_CHARS) {
      messages[i] = {...messages[i], content: `[compacted] ${content.slice(0, COMPACT_CHARS)}`};
    }
  }
}

function extractJson(text) {
  const fenced = text.match(/```json\s*([\s\S]*?)```/);
  const raw = fenced ? fenced[1] : text;
  const start = raw.indexOf('{'), end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('no JSON object in model output');
  return JSON.parse(raw.slice(start, end + 1));
}

export async function createLiveRuntime({socketDir, port, user, database, workspaceRoot, budgetUsd = 15, transport, log = () => {}} = {}) {
  const db = createDb({socketDir, port, user, database});
  const router = transport || createRouterCheap();
  const root = workspaceRoot || path.join(HERE, 'runs');
  fs.mkdirSync(root, {recursive: true});
  const migration = fs.readFileSync(MIGRATION, 'utf8');
  db.exec(migration);
  db.exec(`insert into live.schema_migrations (filename) values ('0001-live.sql') on conflict do nothing;`);

  function emit(missionId, kind, data = {}, taskId = null) {
    db.exec(`insert into live.events (mission_id, task_id, kind, data) values (${sqlLiteral(missionId)}, ${sqlLiteral(taskId)}, ${sqlLiteral(kind)}, ${sqlJson(data)});`);
    log({mission_id: missionId, task_id: taskId, kind, ...data});
  }
  function spent(missionId) {
    return Number(db.query(`select coalesce(sum(cost_usd),0) as v from live.model_calls where mission_id = ${sqlLiteral(missionId)}`)[0].v);
  }
  function recordCall(missionId, taskId, purpose, model, result, ok, error) {
    db.exec(`insert into live.model_calls (mission_id, task_id, purpose, model, prompt_tokens, completion_tokens, cost_usd, ok, error) values (${sqlLiteral(missionId)}, ${sqlLiteral(taskId)}, ${sqlLiteral(purpose)}, ${sqlLiteral(model)}, ${result?.usage?.prompt_tokens || 0}, ${result?.usage?.completion_tokens || 0}, ${ok ? result.costUsd : 0}, ${ok}, ${sqlLiteral(error)});`);
    if (ok) db.exec(`update live.missions set spent_usd = (select coalesce(sum(cost_usd),0) from live.model_calls where mission_id = ${sqlLiteral(missionId)}), updated_at = now() where mission_id = ${sqlLiteral(missionId)};`);
  }

  async function callModel(missionId, taskId, purpose, model, messages, tools) {
    const total = spent(missionId);
    const mission = db.query(`select budget_usd from live.missions where mission_id = ${sqlLiteral(missionId)}`)[0];
    if (total >= Number(mission.budget_usd) * 0.9) {
      emit(missionId, 'budget.near_cap', {spent_usd: total, budget_usd: Number(mission.budget_usd)});
      throw new Error('BUDGET_NEAR_CAP');
    }
    emit(missionId, 'model.call', {purpose, model}, taskId);
    try {
      const result = await router.complete({model, messages, tools});
      recordCall(missionId, taskId, purpose, model, result, true, null);
      emit(missionId, 'model.result', {purpose, model, cost_usd: result.costUsd, prompt_tokens: result.usage?.prompt_tokens || 0, completion_tokens: result.usage?.completion_tokens || 0, tool_calls: result.toolCalls.map(c => c.name)}, taskId);
      return result;
    } catch (error) {
      recordCall(missionId, taskId, purpose, model, null, false, String(error.message || error).slice(0, 500));
      emit(missionId, 'model.error', {purpose, model, error: String(error.message || error).slice(0, 300)}, taskId);
      throw error;
    }
  }

  // One agent tool loop. Returns {finished, truncated, summary}.
  async function agentLoop(missionId, task, tools) {
    const model = task.model || ROLE_MODELS[task.kind === 'review' ? 'reviewer' : 'worker'];
    const limit = MAX_STEPS[task.kind] || MAX_STEPS.work;
    const messages = [
      {role: 'system', content: 'You are an agent in the AWE live runtime. Use the provided tools to accomplish the task. Work only inside the workspace. Never invent sources, facts, or file contents you have not read. When done, call finish with a factual summary of what you actually did and what remains unverified. Older tool outputs may be marked [compacted]; re-read a file if you need its full contents again.'},
      {role: 'user', content: `Task ${task.task_id} (${task.role}): ${task.title}\n\n${task.instruction}`}
    ];
    const signatures = [];
    for (let step = 1; step <= limit; step++) {
      if (step === limit - 1) {
        messages.push({role: 'user', content: `Only 2 steps remain out of ${limit}. Stop exploring and converge: write the required artifacts now, then call finish with an honest summary of what is done and what is missing.`});
      }
      compactHistory(messages);
      const result = await callModel(missionId, task.task_id, `step-${step}`, model, messages, tools.schemas);
      messages.push({role: 'assistant', content: result.content || '', tool_calls: result.toolCalls.map(c => ({id: c.id, type: 'function', function: {name: c.name, arguments: c.arguments}}))});
      if (!result.toolCalls.length) {
        messages.push({role: 'user', content: 'No tool call was made. Continue with a tool call, or call finish when the task is complete.'});
        continue;
      }
      let finished = null;
      for (const call of result.toolCalls) {
        let args = {};
        try { args = JSON.parse(call.arguments || '{}'); } catch { args = {}; }
        if (call.name === 'finish') {
          finished = String(args.summary || result.content || '').slice(0, 4000);
          messages.push({role: 'tool', tool_call_id: call.id, content: 'recorded'});
          continue;
        }
        const handler = tools.handlers[call.name];
        const started = Date.now();
        let output, ok = true;
        if (!handler) { output = `unknown tool ${call.name}`; ok = false; }
        else {
          try { output = await handler(args); }
          catch (error) { output = `ERROR: ${String(error.message || error).slice(0, 500)}`; ok = false; }
        }
        db.exec(`insert into live.tool_calls (mission_id, task_id, tool, args, ok, result_preview, ms) values (${sqlLiteral(missionId)}, ${sqlLiteral(task.task_id)}, ${sqlLiteral(call.name)}, ${sqlJson(args)}, ${ok}, ${sqlLiteral(String(output).slice(0, 1000))}, ${Date.now() - started});`);
        if (ok && (call.name === 'write_file' || call.name === 'edit_file')) recordArtifact(missionId, task.task_id, output);
        emit(missionId, 'tool.call', {tool: call.name, ok, step}, task.task_id);
        messages.push({role: 'tool', tool_call_id: call.id, content: String(output).slice(0, TOOL_REPLY_CHARS)});
        signatures.push(`${call.name}:${JSON.stringify(args).slice(0, 200)}`);
      }
      if (finished !== null) return {finished: true, truncated: false, summary: finished};
      const recent = signatures.slice(-LOOP_DETECT_WINDOW);
      if (recent.length === LOOP_DETECT_WINDOW && new Set(recent).size === 1) {
        messages.push({role: 'user', content: 'You are repeating the identical tool call. Change approach or call finish with what is blocked.'});
      }
    }
    // The step budget is exhausted. One extra call, with only `finish`
    // available, forces an honest summary instead of a silent stop.
    compactHistory(messages);
    messages.push({role: 'user', content: `Step limit of ${limit} reached. Do not call any tool except finish. Summarize exactly what you completed, which files you wrote, and what remains undone.`});
    const finishOnly = tools.schemas.filter(s => s.function.name === 'finish');
    try {
      const last = await callModel(missionId, task.task_id, 'step-limit-finish', model, messages, finishOnly);
      const finishCall = last.toolCalls.find(c => c.name === 'finish');
      let summary = last.content || '';
      if (finishCall) {
        try { summary = JSON.parse(finishCall.arguments || '{}').summary || summary; } catch { /* keep content */ }
      }
      summary = `truncated after ${limit} steps: ${String(summary).slice(0, 3500)}`;
      return {finished: false, truncated: true, summary};
    } catch (error) {
      return {finished: false, truncated: true, summary: `truncated after ${limit} steps; final summary failed: ${String(error.message || error).slice(0, 300)}`};
    }
  }

  function recordArtifact(missionId, taskId, output) {
    let info;
    try { info = JSON.parse(output); } catch { return; }
    const rel = info.wrote || info.edited;
    if (!rel || !info.sha256) return;
    db.exec(`insert into live.artifacts (mission_id, task_id, path, bytes, sha256) values (${sqlLiteral(missionId)}, ${sqlLiteral(taskId)}, ${sqlLiteral(String(rel))}, ${Number(info.bytes) || 0}, ${sqlLiteral(String(info.sha256))});`);
    emit(missionId, 'artifact.write', {path: rel, bytes: Number(info.bytes) || 0, sha256: info.sha256}, taskId);
  }

  async function plan(mission) {
    const model = ROLE_MODELS.head;
    const messages = [
      {role: 'system', content: 'You are the head orchestrator. Decompose the mission into a small DAG of tasks executed by tool-using agents. Reply with ONE JSON object and nothing else: {"title": string, "goal": string, "constraints": [string], "acceptance": [string], "artifacts": [string], "tasks": [{"task_id": "t1", "title": string, "role": string, "kind": "work"|"review", "instruction": string, "depends_on": [task_id]}]}. Rules: at most 6 tasks; exactly one task has kind "review" and depends on all work tasks; the review task must tell the reviewer to independently re-check the artifacts (re-read files, re-run tests) and not trust the worker summary; task instructions must be self-contained; never include tasks that send messages, spend money, or take irreversible external actions.'},
      {role: 'user', content: mission.goal}
    ];
    const result = await callModel(mission.mission_id, null, 'plan', model, messages);
    const planJson = extractJson(result.content);
    if (!Array.isArray(planJson.tasks) || !planJson.tasks.length) throw new Error('PLAN_HAS_NO_TASKS');
    const ids = new Set(planJson.tasks.map(t => t.task_id));
    for (const task of planJson.tasks) {
      if (!ids.has(task.task_id) || typeof task.instruction !== 'string') throw new Error('PLAN_TASK_MALFORMED');
      for (const dep of task.depends_on || []) if (!ids.has(dep)) throw new Error(`PLAN_BAD_DEPENDENCY ${dep}`);
    }
    if (planJson.tasks.filter(t => t.kind === 'review').length !== 1) throw new Error('PLAN_NEEDS_ONE_REVIEW');
    return planJson;
  }

  function savePlan(mission, planJson) {
    db.exec(`update live.missions set title = ${sqlLiteral(planJson.title || mission.title)}, goal = ${sqlLiteral(planJson.goal || mission.goal)}, constraints_json = ${sqlJson(planJson.constraints || [])}, acceptance_json = ${sqlJson(planJson.acceptance || [])}, artifacts_json = ${sqlJson(planJson.artifacts || [])}, plan_json = ${sqlJson(planJson)}, head_model = ${sqlLiteral(ROLE_MODELS.head)}, reviewer_model = ${sqlLiteral(ROLE_MODELS.reviewer)}, status = 'PLANNED', updated_at = now() where mission_id = ${sqlLiteral(mission.mission_id)};`);
    for (const task of planJson.tasks) {
      const model = task.kind === 'review' ? ROLE_MODELS.reviewer : ROLE_MODELS.worker;
      db.exec(`insert into live.tasks (mission_id, task_id, title, role, kind, instruction, depends_on, model) values (${sqlLiteral(mission.mission_id)}, ${sqlLiteral(task.task_id)}, ${sqlLiteral(task.title || task.task_id)}, ${sqlLiteral(task.role || 'agent')}, ${sqlLiteral(task.kind || 'work')}, ${sqlLiteral(task.instruction)}, ${sqlJson(task.depends_on || [])}, ${sqlLiteral(model)}) on conflict (mission_id, task_id) do nothing;`);
    }
    emit(mission.mission_id, 'plan.saved', {tasks: planJson.tasks.map(t => ({id: t.task_id, kind: t.kind, role: t.role}))});
  }

  async function execute(missionId) {
    const mission = db.query(`select * from live.missions where mission_id = ${sqlLiteral(missionId)}`)[0];
    if (!mission) throw new Error(`no mission ${missionId}`);
    const tools = createTools({workspace: mission.workspace});
    db.exec(`update live.missions set status = 'RUNNING', updated_at = now() where mission_id = ${sqlLiteral(missionId)};`);
    const tasks = db.query(`select * from live.tasks where mission_id = ${sqlLiteral(missionId)} order by task_id`);
    const done = new Set(tasks.filter(t => ['DONE', 'FAILED'].includes(t.status)).map(t => t.task_id));
    let guard = tasks.length + 2;
    while (guard-- > 0) {
      const pending = tasks.filter(t => !done.has(t.task_id));
      if (!pending.length) break;
      const ready = pending.filter(t => (t.depends_on || []).every(dep => done.has(dep)));
      if (!ready.length) { emit(missionId, 'run.blocked', {pending: pending.map(t => t.task_id)}); break; }
      const task = ready[0];
      db.exec(`update live.tasks set status = 'RUNNING', attempts = attempts + 1, updated_at = now() where mission_id = ${sqlLiteral(missionId)} and task_id = ${sqlLiteral(task.task_id)};`);
      emit(missionId, 'task.start', {title: task.title, role: task.role, kind: task.kind, model: task.model}, task.task_id);
      db.exec(`insert into live.checkpoints (mission_id, state) values (${sqlLiteral(missionId)}, ${sqlJson({running: task.task_id, done: [...done]})}) on conflict (mission_id) do update set state = excluded.state, at = now();`);
      let outcome;
      try {
        outcome = await agentLoop(missionId, task, tools);
      } catch (error) {
        if (String(error.message || error).includes('BUDGET_NEAR_CAP')) {
          db.exec(`update live.missions set status = 'PAUSED_BUDGET', stop_reason = 'budget near cap', updated_at = now() where mission_id = ${sqlLiteral(missionId)};`);
          emit(missionId, 'run.paused', {reason: 'budget near cap'});
          return;
        }
        outcome = {finished: false, summary: `error: ${String(error.message || error).slice(0, 500)}`};
      }
      const status = outcome.finished ? 'DONE' : 'FAILED';
      const verdictSql = task.kind === 'review' ? `, verdict = ${sqlLiteral(outcome.summary)}` : '';
      db.exec(`update live.tasks set status = ${sqlLiteral(status)}, result = ${sqlLiteral(outcome.summary)}${verdictSql}, updated_at = now() where mission_id = ${sqlLiteral(missionId)} and task_id = ${sqlLiteral(task.task_id)};`);
      if (outcome.truncated) emit(missionId, 'task.truncated', {steps: MAX_STEPS[task.kind] || MAX_STEPS.work, summary: outcome.summary.slice(0, 500)}, task.task_id);
      emit(missionId, 'task.end', {status, truncated: Boolean(outcome.truncated), summary: outcome.summary.slice(0, 500)}, task.task_id);
      done.add(task.task_id);
    }
    const finalTasks = db.query(`select task_id, kind, status, verdict from live.tasks where mission_id = ${sqlLiteral(missionId)}`);
    const review = finalTasks.find(t => t.kind === 'review');
    const allDone = finalTasks.every(t => t.status === 'DONE');
    const status = allDone ? 'COMPLETED' : 'INCOMPLETE';
    db.exec(`update live.missions set status = ${sqlLiteral(status)}, stop_reason = ${sqlLiteral(allDone ? 'all tasks finished' : 'tasks failed or blocked')}, summary = ${sqlLiteral(review ? `review task ${review.task_id}: ${review.status}` : 'no review task')}, updated_at = now() where mission_id = ${sqlLiteral(missionId)};`);
    emit(missionId, 'run.end', {status});
  }

  return {
    db,
    submit(text, {budgetUsd: budget = budgetUsd} = {}) {
      const missionId = `${slug(text)}-${randomUUID().slice(0, 8)}`;
      const workspace = path.join(root, missionId);
      fs.mkdirSync(workspace, {recursive: false});
      db.exec(`insert into live.missions (mission_id, title, goal, workspace, budget_usd) values (${sqlLiteral(missionId)}, ${sqlLiteral(text.slice(0, 80))}, ${sqlLiteral(text)}, ${sqlLiteral(workspace)}, ${budget});`);
      emit(missionId, 'mission.submit', {budget_usd: budget, workspace});
      return missionId;
    },
    async run(missionId) {
      const mission = db.query(`select * from live.missions where mission_id = ${sqlLiteral(missionId)}`)[0];
      if (!mission) throw new Error(`no mission ${missionId}`);
      if (!mission.plan_json) {
        const planJson = await plan(mission);
        savePlan(mission, planJson);
      }
      await execute(missionId);
      return this.status(missionId);
    },
    async resume(missionId) { return this.run(missionId); },
    // Resets the named tasks to PENDING and cascades to every task that
    // depends on a reset one, so a retried task is never shadowed by stale
    // downstream results. Verdict and result are cleared.
    retry(missionId, taskIds) {
      const tasks = db.query(`select task_id, depends_on, status from live.tasks where mission_id = ${sqlLiteral(missionId)}`);
      if (!tasks.length) throw new Error(`no tasks for mission ${missionId}`);
      const known = new Set(tasks.map(t => t.task_id));
      const reset = new Set(taskIds.filter(id => known.has(id)));
      if (!reset.size) throw new Error(`none of [${taskIds.join(', ')}] are tasks of ${missionId}`);
      let grew = true;
      while (grew) {
        grew = false;
        for (const task of tasks) {
          if (!reset.has(task.task_id) && (task.depends_on || []).some(dep => reset.has(dep))) {
            reset.add(task.task_id);
            grew = true;
          }
        }
      }
      for (const taskId of reset) {
        db.exec(`update live.tasks set status = 'PENDING', result = null, verdict = null, updated_at = now() where mission_id = ${sqlLiteral(missionId)} and task_id = ${sqlLiteral(taskId)};`);
      }
      db.exec(`update live.missions set status = 'PLANNED', stop_reason = null, summary = null, updated_at = now() where mission_id = ${sqlLiteral(missionId)};`);
      emit(missionId, 'tasks.retry', {requested: [...taskIds], reset: [...reset]});
      return {requested: [...taskIds], reset: [...reset]};
    },
    status(missionId) {
      const mission = db.query(`select mission_id, title, status, stop_reason, spent_usd, budget_usd, summary from live.missions where mission_id = ${sqlLiteral(missionId)}`);
      const tasks = db.query(`select task_id, title, role, kind, model, status, attempts, verdict from live.tasks where mission_id = ${sqlLiteral(missionId)} order by task_id`);
      const calls = db.query(`select model, count(*) as calls, coalesce(sum(cost_usd),0) as cost_usd from live.model_calls where mission_id = ${sqlLiteral(missionId)} group by model order by model`);
      const artifacts = db.query(`select task_id, path, bytes, sha256, at from live.artifacts where mission_id = ${sqlLiteral(missionId)} order by id`);
      return {mission: mission[0] || null, tasks, calls, artifacts};
    },
    eventsSince(missionId, afterId = 0) {
      return db.query(`select id, kind, task_id, data, at from live.events where mission_id = ${sqlLiteral(missionId)} and id > ${Number(afterId)} order by id`);
    }
  };
}
