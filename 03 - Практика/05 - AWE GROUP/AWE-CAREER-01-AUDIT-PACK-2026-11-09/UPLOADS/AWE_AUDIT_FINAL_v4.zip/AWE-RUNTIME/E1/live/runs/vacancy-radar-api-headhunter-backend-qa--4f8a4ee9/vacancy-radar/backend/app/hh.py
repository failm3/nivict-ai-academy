"""Fixed-host official read-only adapter. No OAuth, redirects, CAPTCHA bypass or arbitrary URLs."""
import json
import socket
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPRedirectHandler
from .core import Error, validate_import

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

class HHClient:
    def __init__(self, user_agent, *, opener=None, sleep=time.sleep, timeout=10, retries=2):
        if not isinstance(user_agent,str) or len(user_agent)<10 or '@' not in user_agent or any(c in user_agent for c in '\r\n'):
            raise Error(503,'CLIENT_NOT_CONFIGURED')
        self.user_agent=user_agent
        self.opener=opener or build_opener(NoRedirect())
        self.sleep=sleep
        self.timeout=min(30,max(1,timeout))
        self.retries=min(2,max(0,retries))

    def search(self, body, page):
        body=validate_import(body)
        if type(page) is not int or not 0<=page<body['max_pages']:
            raise Error(field='page')
        q=body['query']
        params={'text':q['text'],'area':q['area_ids'],'experience':q['experience_ids'], 'only_with_salary':str(q['only_with_salary']).lower(), 'per_page':100,'page':page,'order_by':'publication_time'}
        for local,remote in (('published_from','date_from'),('published_to','date_to')):
            if q[local] is not None: params[remote]=q[local]
        req=Request('https://api.hh.ru/vacancies?'+urlencode(params,doseq=True),headers={'HH-User-Agent':self.user_agent,'User-Agent':self.user_agent,'Accept':'application/json'},method='GET')
        for attempt in range(self.retries+1):
            try:
                with self.opener.open(req,timeout=self.timeout) as response:
                    raw=response.read(2_000_001)
                    if len(raw)>2_000_000:
                        raise Error(code='INVALID_UPSTREAM_DATA')
                    data=json.loads(raw)
                    if not isinstance(data,dict) or not isinstance(data.get('items'),list) or len(data['items'])>100 or any(type(data.get(k)) is not int or data[k]<0 for k in ('found','pages','page')) or data['page']!=page:
                        raise Error(code='INVALID_UPSTREAM_DATA')
                    if data.get('errors'):
                        raise Error(code='HH_CAPTCHA_REQUIRED')
                    return data
            except HTTPError as exc:
                status=exc.code
                retry=exc.headers.get('Retry-After','') if exc.headers else ''
                exc.close()
                if status in (401,403):
                    raise Error(code='HH_AUTH_REQUIRED' if status==401 else 'HH_FORBIDDEN') from None
                code='HH_RATE_LIMIT' if status==429 else 'HH_UNAVAILABLE' if status>=500 else 'INVALID_UPSTREAM_DATA'
                if status!=429 and status<500 or attempt==self.retries:
                    raise Error(code=code) from None
                # Never retry earlier than a long/unparseable server delay; stop instead.
                if status==429 and retry:
                    if not retry.isdigit() or int(retry)>30:
                        raise Error(code=code) from None
                    delay=max(1,int(retry))
                else:
                    delay=2**attempt
            except (socket.timeout, TimeoutError):
                if attempt==self.retries: raise Error(code='HH_TIMEOUT') from None
                delay=2**attempt
            except (URLError,OSError):
                if attempt==self.retries: raise Error(code='HH_UNAVAILABLE') from None
                delay=2**attempt
            except (ValueError,UnicodeError):
                raise Error(code='INVALID_UPSTREAM_DATA') from None
            self.sleep(delay)


def run_import(store,ident,client,sleep=time.sleep):
    """Invoked by the single local worker only after compliance approval."""
    try:
        job=store.get_import(ident)
        for page in range(job['max_pages']):
            data=client.search({k:job[k] for k in ('source','query','max_pages')},page)
            # Validate the whole envelope before committing even an empty page.
            # Keep this boundary safe for injected/future clients as well.
            if (not isinstance(data, dict) or not isinstance(data.get('items'), list)
                    or len(data['items']) > 100
                    or any(type(data.get(k)) is not int or data[k] < 0 for k in ('found', 'pages', 'page'))
                    or data['page'] != page):
                raise Error(code='INVALID_UPSTREAM_DATA')
            store.page(ident,data['items'],data['found'])
            if page+1>=min(data['pages'],20): break
            sleep(1)
        store.finish_import(ident)
    except Error as exc:
        store.finish_import(ident,exc.detail)
    except Exception:
        store.finish_import(ident,Error(code='INTERNAL_ERROR').detail)
