#!/usr/bin/env node
// Live mission CLI: submit | run | resume | status | watch | events
import {createLiveRuntime} from './runner.mjs';

const SOCKET = process.env.AWE_LIVE_SOCKET || '/home/nox/.awe-live-pg';
const DATABASE = process.env.AWE_LIVE_DB || 'awe_live';
const PORT = Number(process.env.AWE_LIVE_PORT || 5544);

const [command, ...rest] = process.argv.slice(2);

function print(line) { process.stdout.write(`${line}\n`); }

const runtime = await createLiveRuntime({socketDir: SOCKET, port: PORT, database: DATABASE, log: event => print(`[${event.kind}] ${event.task_id || '-'} ${JSON.stringify(event).slice(0, 400)}`)});

if (command === 'submit') {
  const text = rest.join(' ').trim();
  if (!text) { print('usage: submit "<mission>"'); process.exit(2); }
  const id = runtime.submit(text);
  print(`mission_id=${id}`);
} else if (command === 'run' || command === 'resume') {
  const id = rest[0];
  if (!id) { print(`usage: ${command} <mission_id>`); process.exit(2); }
  const status = await runtime.run(id);
  print(JSON.stringify(status, null, 2));
} else if (command === 'retry') {
  const [id, ...taskIds] = rest;
  if (!id || !taskIds.length) { print('usage: retry <mission_id> <task_id...>'); process.exit(2); }
  print(JSON.stringify(runtime.retry(id, taskIds), null, 2));
} else if (command === 'status') {
  print(JSON.stringify(runtime.status(rest[0]), null, 2));
} else if (command === 'events') {
  for (const event of runtime.eventsSince(rest[0], Number(rest[1] || 0))) print(`${event.id} ${event.kind} ${event.task_id || '-'} ${JSON.stringify(event.data).slice(0, 300)}`);
} else if (command === 'watch') {
  let cursor = 0;
  const id = rest[0];
  for (;;) {
    const events = runtime.eventsSince(id, cursor);
    for (const event of events) { cursor = event.id; print(`${event.at} ${event.kind} ${event.task_id || '-'} ${JSON.stringify(event.data).slice(0, 300)}`); }
    const mission = runtime.status(id).mission;
    if (mission && ['COMPLETED', 'INCOMPLETE', 'PAUSED_BUDGET'].includes(mission.status)) break;
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
} else {
  print('commands: submit "<mission>" | run <id> | resume <id> | retry <id> <task_id...> | status <id> | events <id> [after] | watch <id>');
  process.exit(command ? 2 : 0);
}
