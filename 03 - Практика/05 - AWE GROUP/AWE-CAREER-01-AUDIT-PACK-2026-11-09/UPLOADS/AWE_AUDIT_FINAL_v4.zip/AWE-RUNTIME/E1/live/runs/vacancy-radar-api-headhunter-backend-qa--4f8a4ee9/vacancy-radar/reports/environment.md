# Обследование среды и реальные проверки

Дата: 2026-11-09 UTC по системным часам (первый probe 11:42:18Z). Все созданные артефакты находятся в `vacancy-radar/`, runtime и посторонние файлы не редактировались. Установок пакетов, обращений к секретам, внешних записей и запросов реальных вакансий не было.

## Факты

Источник: `logs/environment.txt` — command -v и --version, uname, importlib probes.

|Категория|Наблюдение|
|---|---|
|ОС|Linux x86_64 WSL2, ядро 6.18.54.1-microsoft-standard-WSL2|
|Языки|Python 3.14.4, Node 22.23.3|
|Менеджеры|npm 10.9.9, pnpm 11.25.0 (путь на смонтированном Windows-диске); pip/pip3/yarn/bun/deno не найдены в PATH|
|Другие toolchains|go/rustc/cargo/java не найдены в PATH|
|SQLite|CLI sqlite3 нет; модуль sqlite3 Python работает, engine 3.46.1|
|Другие БД|psql 18.6 есть; postgres/mysql/mongod/redis-server и docker не найдены в PATH|
|Python frameworks|fastapi, uvicorn, httpx, pytest, playwright, selenium не обнаружены через importlib|
|Браузеры|chromium/chromium-browser/google-chrome/firefox не найдены в PATH; проверенные типовые пути и ~/.cache/ms-playwright отсутствуют|
|Прочее|curl 8.18.0, git 2.53.0|

Это ограниченные probes, а не доказательство отсутствия любого языка/браузера на всех дисках. Никакой браузер не запущен, E2E визуальная проверка не выполнялась.

`logs/probes.txt`: локальная SQLite успешно создала таблицу, записала тестовую строку, закрылась и прочла ее после открытия; временный файл удален. Loopback bind успешен. TCP 127.0.0.1:5432 принимает соединение; это **не подтверждает** версию, протокол, учетные данные или доступность БД для приложения. 3306/6379 отказали. SQL к существующей сторонней БД не выполнялся.

## Сеть

curl HTTPS GET официальных HH-источников и HEAD npm/PyPI успешны (HTTP 200; redirects сохранены). Подробные URL/ограничения — `../docs/hh-compliance.md`. `api.hh.ru/` перенаправляет на dev.hh.ru. OpenAPI получен в **YAML**, не JSON. Попытка json.loads не удалась, после чего изучались исходные текстовые разделы — полноценный YAML-парсинг/валидация всей схемы не выполнены. Доступ к документации не равен проверке авторизованного API, OAuth, лимитов или работоспособности импорта. npm install/pip install не выполнялись, воспроизводимость установки сторонних пакетов не проверялась.

## Проверка каркаса

- `logs/checks.txt`: Python compileall и `npm run check` (node --check) завершились успешно.
- `logs/server.txt`, `logs/smoke.txt`: настоящий процесс backend на 127.0.0.1:18765; GET health 200, HTML и JS 200, бизнес-маршрут 501, неизвестный API 404, попытка получить SQL через traversal 404. SQLite schema version=1, vacancies=0. Процесс остановлен, временная smoke БД удалена.
- Frontend не исполнялся настоящим браузером; JS синтаксически проверен, HTTP-отдача проверена.
- Полный REST, импорт, расчеты аналитики и compliance-gate только спроектированы, не протестированы и не реализованы.

## Карта журналов

- `environment.txt`, `probes.txt`: вывод инструментов и команд обследования.
- `openapi.*`, `spec.*`, `docs.*`, `terms.*`, `site-terms.*`: исходные HTTP headers/body и curl status/effective URL; тела официальных источников не подменялись.
- `terms-visible.txt`, `terms.txt`, `docs.txt`, `vacancies-spec.txt`: производные текстовые выдержки; HTML/YAML оригиналы приоритетны. `terms.txt` — неполная HTMLParser-выжимка с гидратацией, поэтому для анализа правовых пунктов использован terms-visible.txt.
- `checks.txt`, `server.txt`, `smoke.txt`: реальные локальные проверки.

Выбор стека: stdlib Python + browser ES modules + локальная SQLite; ноль внешних runtime-зависимостей и сборки. Это минимальный воспроизводимый каркас, не масштабируемый production backend. Минимальный Python 3.12 заявлен в манифесте, но фактически проверен только 3.14.4.
