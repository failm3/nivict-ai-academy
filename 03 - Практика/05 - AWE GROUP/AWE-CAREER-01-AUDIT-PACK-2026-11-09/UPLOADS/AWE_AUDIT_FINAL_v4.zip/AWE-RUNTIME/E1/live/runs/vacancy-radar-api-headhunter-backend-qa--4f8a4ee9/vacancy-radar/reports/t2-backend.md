# t2 — backend и хранение

## Реализовано
- Версионированные транзакционные SQL migrations 001/002; upgrade существующего bootstrap user_version=1, отказ при неизвестной новой версии. SQLite WAL, FK cascade, busy timeout. Сохраняются вакансии, import snapshots, counters и idempotency keys. UNIQUE(source,external_id), один active job на уровне SQLite.
- Repository: canonical idempotency, page-atomic upsert, сохранение first_seen, обновление last_seen, immutable membership snapshot, recovery interrupted jobs. Отсутствие в поиске ничего не удаляет. Отдельный purge только после явного подтверждения архива (удаляет и snapshots).
- Локальные GET health/imports/list/detail/analytics; shared filters, literal Unicode search, deterministic sorting/paging, Decimal groups без конвертации. Default freshness=current: результаты поиска сами по себе не являются проверкой актуальности; новые записи unknown, доступны явно с freshness=all/unknown.
- Read-only fixed-host GET /vacancies HH adapter: application headers, timeout, <=2 retries, 429 Retry-After (при длинном/неразбираемом ожидании остановка), no redirects, <=20 pages/2000 depth, no tokens/URL from input. Errors stored as partial/failed, fetched pages retained.
- Loopback Host/Origin checks, bounded input, reject unknown/duplicate JSON fields, no raw upstream body/errors to browser. Description HTML не хранится/не отдается; строки DTO — только JSON, frontend обязан использовать textContent. Статическая выдача только разрешенных файлов. Контакты/raw upstream payload не сохраняются.

## Намеренно закрытая граница
`POST /imports` валидирует запрос и возвращает 403 IMPORT_DISABLED. Не создает задания и не делает сетевых запросов. `VR_IMPORTS_ENABLED=true` НЕ снимает gate. Repository и worker доступны для изолированных тестов, но не подключены к HTTP, пока нет допуска. Никакие реальные вакансии в этой задаче не загружались. Это не заявление о юридическом соответствии.

Блокеры из docs/hh-compliance.md остаются: зарегистрированное приложение/реальная идентификация, разрешение на локальное хранение и производную аналитику, согласованный TTL и механизм проверки/удаления архивных данных. Автоматический refresh/TTL scheduler не реализован. После решения блокеров нужны reviewed gate + single worker wiring, live smoke test, обработка нового salary_range и сверка актуальной схемы. Legacy salary сохраняется с period=null, месячный период не выдумывается. CAPTCHA не обходится, 403 останавливает импорт (может быть запретом или CAPTCHA).

## Проверки
Команды из корня vacancy-radar:
- `python3 -m unittest discover -s backend/tests -v`
- `python3 -m compileall -q backend`

Реальные stdout/stderr и exit status сохранены в reports/logs/t2-*.txt. Тестовые SQLite создаются во временных каталогах backend/tests и удаляются. Fixtures помечены SYNTHETIC TEST ONLY, приложение их не загружает. Проверены миграции, unique/FK, rollback страницы, дедуп/upsert/snapshots, idempotency/restart, отсутствие удаления по отсутствию, фильтры, аналитика, 429/network/timeout/403/malformed response, partial import, HTTP validation/Origin/disabled gate.

Ограничения: single-user stdlib server, фильтрация по DTO в памяти (не для большой БД), нет browser/XSS E2E или нагрузочного теста; минимум Python 3.12 отдельно не проверен. Наличие JSON с символами HTML безопасно только при текстовом отображении; сторонние потребители не должны использовать innerHTML. Legacy bootstrap imports без dto_json читаются как legacy и могут не иметь всех новых счетчиков.
