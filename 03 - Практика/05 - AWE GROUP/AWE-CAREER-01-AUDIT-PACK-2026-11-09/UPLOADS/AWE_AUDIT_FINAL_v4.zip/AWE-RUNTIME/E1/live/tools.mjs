// Tools the live agents may call. Everything is confined to the mission
// workspace; shell commands additionally refuse a small denylist of destructive
// patterns. This is a guardrail, not a sandbox.
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {promises as fs} from 'node:fs';
import path from 'node:path';

const DENY = [/rm\s+-rf\s+\/(?!\w)/, /\bmkfs\b/, /\bshutdown\b/, /\breboot\b/, /dd\s+if=/, />\s*\/dev\/sd/];
const MAX_OUTPUT = 20000;

export const TOOL_SCHEMAS = [
  {type: 'function', function: {name: 'list_dir', description: 'List files under a directory inside the workspace.', parameters: {type: 'object', properties: {dir: {type: 'string', description: 'Relative directory, default "."'}}, required: []}}},
  {type: 'function', function: {name: 'read_file', description: 'Read a UTF-8 text file inside the workspace.', parameters: {type: 'object', properties: {path: {type: 'string'}, offset: {type: 'integer'}, limit: {type: 'integer'}}, required: ['path']}}},
  {type: 'function', function: {name: 'write_file', description: 'Create or overwrite a UTF-8 text file inside the workspace.', parameters: {type: 'object', properties: {path: {type: 'string'}, content: {type: 'string'}}, required: ['path', 'content']}}},
  {type: 'function', function: {name: 'edit_file', description: 'Replace one exact occurrence of text in a file inside the workspace.', parameters: {type: 'object', properties: {path: {type: 'string'}, find: {type: 'string'}, replace: {type: 'string'}}, required: ['path', 'find', 'replace']}}},
  {type: 'function', function: {name: 'run_command', description: 'Run a shell command with the workspace as cwd. stdout+stderr are capped.', parameters: {type: 'object', properties: {command: {type: 'string'}, timeout_s: {type: 'integer'}}, required: ['command']}}},
  {type: 'function', function: {name: 'web_fetch', description: 'Fetch a public http(s) URL and return text (capped).', parameters: {type: 'object', properties: {url: {type: 'string'}}, required: ['url']}}},
  {type: 'function', function: {name: 'finish', description: 'Declare the task done with a short result summary.', parameters: {type: 'object', properties: {summary: {type: 'string'}}, required: ['summary']}}}
];

function clip(text, max = MAX_OUTPUT) {
  const value = String(text ?? '');
  return value.length > max ? `${value.slice(0, max)}\n…[truncated ${value.length - max} chars]` : value;
}

export function createTools({workspace, fetchImpl = globalThis.fetch, commandTimeoutS = 120}) {
  function resolveSafe(rel) {
    const target = path.resolve(workspace, rel || '.');
    if (target !== workspace && !target.startsWith(workspace + path.sep)) throw new Error(`path escapes workspace: ${rel}`);
    return target;
  }
  const handlers = {
    async list_dir({dir = '.'} = {}) {
      const target = resolveSafe(dir);
      const entries = await fs.readdir(target, {withFileTypes: true});
      return clip(entries.slice(0, 500).map(e => `${e.isDirectory() ? 'd' : 'f'} ${e.name}`).join('\n') || '(empty)');
    },
    async read_file({path: rel, offset = 1, limit = 400} = {}) {
      const text = await fs.readFile(resolveSafe(rel), 'utf8');
      const lines = text.split('\n');
      const start = Math.max(1, offset) - 1;
      return clip(lines.slice(start, start + Math.min(limit, 800)).map((l, i) => `${start + i + 1}: ${l}`).join('\n'));
    },
    async write_file({path: rel, content} = {}) {
      if (typeof content !== 'string') throw new Error('content must be a string');
      const target = resolveSafe(rel);
      await fs.mkdir(path.dirname(target), {recursive: true});
      await fs.writeFile(target, content);
      const sha = createHash('sha256').update(content).digest('hex');
      return JSON.stringify({wrote: rel, bytes: Buffer.byteLength(content), sha256: sha});
    },
    async edit_file({path: rel, find, replace} = {}) {
      const target = resolveSafe(rel);
      const text = await fs.readFile(target, 'utf8');
      const count = text.split(find).length - 1;
      if (count !== 1) throw new Error(`find text matched ${count} times, expected exactly 1`);
      const next = text.replace(find, replace);
      await fs.writeFile(target, next);
      const sha = createHash('sha256').update(next).digest('hex');
      return JSON.stringify({edited: rel, bytes: Buffer.byteLength(next), sha256: sha});
    },
    run_command({command, timeout_s} = {}) {
      if (typeof command !== 'string' || !command.trim()) throw new Error('command required');
      if (DENY.some(re => re.test(command))) throw new Error('command rejected by denylist');
      const seconds = Math.min(Math.max(timeout_s || commandTimeoutS, 1), 600);
      return new Promise((resolve, reject) => {
        const child = spawn('bash', ['-lc', command], {cwd: workspace, timeout: seconds * 1000});
        let out = '';
        child.stdout.on('data', chunk => { out += chunk; if (out.length > MAX_OUTPUT * 2) child.kill(); });
        child.stderr.on('data', chunk => { out += chunk; });
        child.on('error', reject);
        child.on('close', code => resolve(clip(`exit=${code ?? 'null'}\n${out}`)));
      });
    },
    async web_fetch({url} = {}) {
      if (!/^https?:\/\//.test(url || '')) throw new Error('only http(s) URLs');
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 30000);
      try {
        const response = await fetchImpl(url, {signal: controller.signal, headers: {'User-Agent': 'awe-live/1'}});
        const text = await response.text();
        return clip(`status=${response.status}\n${text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ')}`);
      } finally {
        clearTimeout(timer);
      }
    }
  };
  return {handlers, schemas: TOOL_SCHEMAS};
}
