"""HTTP and persistent storage bootstrap; business API is not implemented."""
