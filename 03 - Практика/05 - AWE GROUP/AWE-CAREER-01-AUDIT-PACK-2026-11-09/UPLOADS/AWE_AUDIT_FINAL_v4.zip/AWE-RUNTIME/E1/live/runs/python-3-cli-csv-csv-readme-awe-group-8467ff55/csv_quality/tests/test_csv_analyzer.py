"""Contract tests with hand-calculated oracles; run from csv_quality.

All CLI calls use this interpreter. No expected report is computed by the
implementation under test. Fixtures are snapshotted as bytes before/after calls.
"""
import csv
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / 'tests' / 'fixtures'
CLI = ROOT / 'csv_analyzer.py'


def column(name, missing, fraction, filled, unique, stats=None):
    return dict(name=name, missing_count=missing, missing_fraction=fraction,
                filled_count=filled, unique_count=unique, numeric_statistics=stats)


def stats(low, high, mean, median):
    return dict(min=low, max=high, mean=mean, median=median)


def report(rows, columns, missing=0, fraction=0.0, repeats=0, groups=None):
    return dict(schema_version=1, row_count=rows, column_count=len(columns),
                missing_count=missing, missing_fraction=fraction,
                duplicate_count=repeats, duplicate_groups=groups or [], columns=columns)


def reject_constant(value):
    raise ValueError('Non-standard JSON constant: ' + value)


class CSVAnalyzerCLITests(unittest.TestCase):
    maxDiff = None

    def invoke(self, *args):
        before = {p: p.read_bytes() for p in FIXTURES.iterdir() if p.is_file()}
        children = set(ROOT.iterdir())
        result = subprocess.run([sys.executable, str(CLI), *map(str, args)],
                                cwd=str(ROOT), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=15)
        self.assertEqual(set(ROOT.iterdir()), children, 'CLI created side files')
        self.assertEqual({p: p.read_bytes() for p in FIXTURES.iterdir() if p.is_file()},
                         before, 'input fixtures changed')
        self.assertNotIn(b'Traceback', result.stderr)
        return result

    def success(self, name, *options, output_format='json'):
        result = self.invoke(FIXTURES / name, '--format', output_format, *options)
        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8'))
        self.assertEqual(result.stderr, b'')
        self.assertTrue(result.stdout.endswith(b'\n'))
        return result.stdout.decode('ascii')

    def json_report(self, name, *options):
        text = self.success(name, *options)
        value = json.loads(text, parse_constant=reject_constant)
        self.assertEqual(text, json.dumps(value, ensure_ascii=True, allow_nan=False,
                                         indent=2) + '\n')
        return value

    def error(self, args, code=1, contains=None):
        result = self.invoke(*args)
        self.assertEqual(result.returncode, code, result.stderr)
        self.assertEqual(result.stdout, b'')
        self.assertTrue(result.stderr)
        if code == 1:
            self.assertTrue(result.stderr.startswith(b'error: '), result.stderr)
        else:
            self.assertIn(b'usage:', result.stderr)
            self.assertIn(b'error:', result.stderr)
        if contains:
            self.assertIn(contains.encode(), result.stderr)

    def test_quality_complete_report(self):
        # 5*4=20 cells; missing counts 0+1+5+0=6. Numeric sum=4.5.
        expected = report(5, [
            column('number', 0, 0.0, 5, 3, stats(-2, 5.5, 0.9, 1.5)),
            column('mixed', 1, 1/5, 4, 2),
            column('empty', 5, 1.0, 0, 0),
            column('label', 0, 0.0, 5, 2),
        ], 6, 6/20, 2, [dict(records=[1, 3], repeats=1),
                         dict(records=[2, 5], repeats=1)])
        self.assertEqual(self.json_report('quality.csv'), expected)

    def test_exact_uniqueness_and_duplicate_repeats(self):
        self.assertEqual(self.json_report('exact_values.csv'), report(5, [
            column('value', 0, 0.0, 5, 3, stats(1, 1, 1, 1)),
            column('blank', 5, 1.0, 0, 0),
        ], 5, 0.5, 1, [dict(records=[1, 4], repeats=1)]))

    def test_multiple_repeats_and_group_order(self):
        self.assertEqual(self.json_report('repeated.csv'), report(6, [
            column('a', 0, 0.0, 6, 2),
            column('b', 0, 0.0, 6, 2, stats(1, 2, 4/3, 1)),
        ], repeats=4, groups=[dict(records=[1, 3, 4, 6], repeats=3),
                             dict(records=[2, 5], repeats=1)]))

    def test_even_and_odd_median(self):
        self.assertEqual(self.json_report('numeric.csv'), report(4, [
            column('even', 0, 0.0, 4, 4, stats(-3, 10, 2, 0.5)),
            column('odd', 1, 0.25, 3, 3, stats(-4, 8, 2, 2)),
        ], 1, 1/8))

    def test_no_data_rows(self):
        self.assertEqual(self.json_report('header_only.csv'), report(0, [
            column('a', 0, 0.0, 0, 0), column('b', 0, 0.0, 0, 0)]))

    def test_unicode_whitespace(self):
        self.assertEqual(self.json_report('unicode_spaces.csv'), report(2, [
            column('a', 2, 1.0, 0, 0), column('b', 2, 1.0, 0, 0)], 4, 1.0))

    def test_bom_and_cyrillic(self):
        self.assertEqual(self.json_report('bom_cyrillic.csv'), report(2, [
            column('имя', 0, 0.0, 2, 2),
            column('число', 0, 0.0, 2, 2, stats(-1, 3, 1, 1))]))

    def test_delimiter_quotes_multiline_logical_record_numbers(self):
        self.assertEqual(self.json_report('quoted_semicolon.csv', '--delimiter', ';'),
                         report(3, [column('имя', 0, 0.0, 3, 2),
                                    column('текст', 0, 0.0, 3, 2),
                                    column('число', 0, 0.0, 3, 2,
                                           stats(-2.5, 3.5, -0.5, -2.5))],
                                repeats=1, groups=[dict(records=[1, 3], repeats=1)]))

    def test_alternate_encoding(self):
        self.assertEqual(self.json_report('cp1251.csv', '--delimiter', ';',
                                          '--encoding', 'cp1251'), report(2, [
            column('имя', 0, 0.0, 2, 2),
            column('число', 0, 0.0, 2, 2, stats(2, 4, 3, 3))]))

    def test_tab_delimiter(self):
        self.assertEqual(self.json_report('tab.csv', '--delimiter', '\t'), report(1, [
            column('a', 0, 0.0, 1, 1, stats(1, 1, 1, 1)),
            column('b', 0, 0.0, 1, 1, stats(2, 2, 2, 2))]))

    def test_header_names_not_normalized(self):
        self.assertEqual(self.json_report('header_distinct.csv'), report(1, [
            column('a', 0, 0.0, 1, 1, stats(1, 1, 1, 1)),
            column(' a ', 0, 0.0, 1, 1, stats(2, 2, 2, 2))]))

    def test_unquoted_quote_is_literal_per_csv_dialect(self):
        self.assertEqual(self.json_report('unquoted_quote.csv'),
                         report(1, [column('a', 0, 0.0, 1, 1)]))

    def test_nonfinite_and_overflow_are_nonnumeric(self):
        self.assertEqual(self.json_report('nonfinite.csv'), report(2, [
            column(name, 0, 0.0, 2, 2) for name in
            ('nan', 'inf', 'minus_inf', 'overflow', 'huge_integer')]))
        text = self.success('nonfinite.csv', output_format='text')
        self.assertEqual(text.count('numeric_statistics: null'), 5)

    def test_large_finite_no_intermediate_overflow(self):
        expected = report(2, [
            column('positive', 0, 0.0, 2, 1, stats(1.7e308, 1.7e308, 1.7e308, 1.7e308)),
            column('negative', 0, 0.0, 2, 1, stats(-1.7e308, -1.7e308, -1.7e308, -1.7e308)),
            column('balanced', 0, 0.0, 2, 2, stats(-1.7e308, 1.7e308, 0, 0))])
        self.assertEqual(self.json_report('large_finite.csv'), expected)
        text = self.success('large_finite.csv', output_format='text')
        self.assertNotIn('Infinity', text)
        for c in expected['columns']:
            self.assertTrue(all(math.isfinite(v) for v in c['numeric_statistics'].values()))

    def test_float_syntax(self):
        self.assertEqual(self.json_report('float_syntax.csv'), report(3, [
            column('number', 0, 0.0, 3, 3, stats(-25, 100, 75.5/3, 0.5))]))

    def test_invalid_input_files(self):
        cases = {
            'empty.csv': 'empty', 'bom_only.csv': 'empty',
            'header_zero.csv': 'header', 'header_empty.csv': 'empty',
            'header_spaces.csv': 'whitespace', 'header_duplicate.csv': 'duplicate',
            'short_row.csv': 'data record 2: expected 2 fields, got 1',
            'long_row.csv': 'data record 1: expected 2 fields, got 3',
            'blank_row.csv': 'data record 1: expected 1 fields, got 0',
            'unclosed_quote.csv': None, 'quote_suffix.csv': None,
            'invalid_utf8.csv': None,
        }
        for name, message in cases.items():
            for fmt in ('text', 'json'):
                with self.subTest(file=name, format=fmt):
                    self.error([FIXTURES / name, '--format', fmt], contains=message)

    def test_missing_path(self):
        path = FIXTURES / 'does-not-exist.csv'
        self.assertFalse(path.exists())
        self.error([path])

    def test_unknown_encoding(self):
        self.error([FIXTURES / 'quality.csv', '--encoding', 'no-such-encoding'])

    def test_invalid_cli_arguments(self):
        path = FIXTURES / 'quality.csv'
        cases = [[], [path, '--format', 'xml'], [path, '--unknown'],
                 [path, '--encoding'], [path, '--delimiter'], [path, 'extra']]
        cases.extend([path, '--delimiter', value] for value in ('', 'xx', '\n', '\r'))
        # NUL cannot be passed in an OS argv; do not mistake subprocess's
        # ValueError for a CLI response.
        for args in cases:
            with self.subTest(args=args):
                self.error(args, code=2)

    def test_help(self):
        result = self.invoke('--help')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, b'')
        for word in (b'usage:', b'path', b'--delimiter', b'--encoding', b'--format'):
            self.assertIn(word, result.stdout)

    def test_text_default_and_explicit_exact_output(self):
        expected = ('Rows: 0\nColumns: 2\nMissing cells: 0 (fraction: 0.0)\n'
                    'Duplicate records beyond first: 0\nDuplicate groups: []\n'
                    'Column "a":\n  missing_count: 0\n  missing_fraction: 0.0\n'
                    '  filled_count: 0\n  unique_count: 0\n  numeric_statistics: null\n'
                    'Column "b":\n  missing_count: 0\n  missing_fraction: 0.0\n'
                    '  filled_count: 0\n  unique_count: 0\n  numeric_statistics: null\n')
        result = self.invoke(FIXTURES / 'header_only.csv')
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, b'')
        self.assertEqual(result.stdout.decode('ascii'), expected)
        self.assertEqual(self.success('header_only.csv', output_format='text'), expected)

    def test_text_contains_actual_numeric_metrics_and_duplicates(self):
        text = self.success('quality.csv', output_format='text')
        for line in ('Rows: 5', 'Columns: 4', 'Missing cells: 6 (fraction: 0.3)',
                     'Duplicate records beyond first: 2',
                     'Duplicate groups: [{"records": [1, 3], "repeats": 1}, '
                     '{"records": [2, 5], "repeats": 1}]',
                     '  numeric_statistics: {"min": -2.0, "max": 5.5, '
                     '"mean": 0.9, "median": 1.5}'):
            self.assertIn(line + '\n', text)

    def test_non_text_encoding(self):
        self.error([FIXTURES / 'numeric.csv', '--encoding', 'base64_codec'])

    def test_directory_input(self):
        self.error([FIXTURES])

    def test_field_size_limit(self):
        # The CLI intentionally retains the interpreter's default CSV limit.
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            path = Path(directory) / 'oversized.csv'
            path.write_bytes(b'a\n' + b'x' * (csv.field_size_limit() + 1) + b'\n')
            before = path.read_bytes()
            self.error([path], contains='field larger than field limit')
            self.assertEqual(path.read_bytes(), before)

    def test_extreme_cancellation_and_crlf(self):
        self.assertEqual(self.json_report('extreme_crlf.csv'), report(4, [
            column('value', 0, 0.0, 4, 4,
                   stats(-1.7e308, 1.7e308, 0, 0))]))

    def test_json_deterministic(self):
        self.assertEqual(self.success('quality.csv'), self.success('quality.csv'))


if __name__ == '__main__':
    unittest.main()
