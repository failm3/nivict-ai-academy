ALTER TABLE imports ADD COLUMN dto_json TEXT;
CREATE UNIQUE INDEX one_active_import ON imports((1)) WHERE status IN ('queued','running');
CREATE INDEX membership_vacancy ON import_items(vacancy_id);
CREATE INDEX imports_created ON imports(created_at DESC,id DESC);
PRAGMA user_version=2;
