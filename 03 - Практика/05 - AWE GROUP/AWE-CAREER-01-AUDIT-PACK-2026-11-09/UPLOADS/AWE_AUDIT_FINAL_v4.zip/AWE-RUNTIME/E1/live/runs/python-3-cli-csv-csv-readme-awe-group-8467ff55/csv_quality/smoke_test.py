"""Local CLI smoke checks; fixtures exist only in a temporary subdirectory."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
CLI = ROOT / "csv_analyzer.py"


def main():
    checks = 0
    with tempfile.TemporaryDirectory(prefix="smoke_", dir=str(ROOT)) as directory:
        fixture = Path(directory) / "input.csv"

        def invoke(data, *options, valid=True):
            nonlocal checks
            fixture.write_bytes(data)
            before = hashlib.sha256(fixture.read_bytes()).digest()
            result = subprocess.run(
                [sys.executable, str(CLI), str(fixture), *options],
                capture_output=True, text=True,
            )
            assert hashlib.sha256(fixture.read_bytes()).digest() == before
            if valid:
                assert result.returncode == 0, result.stderr
                assert not result.stderr
            else:
                assert result.returncode != 0
                assert result.stderr and "Traceback" not in result.stderr
                assert not result.stdout
            checks += 1
            return result

        result = invoke(
            b'\xef\xbb\xbfa,b,c\n1,hello,\n2,hello, \n1,hello,\n', '--format', 'json'
        )
        report = json.loads(result.stdout)
        assert report['row_count'] == 3 and report['column_count'] == 3
        assert report['missing_count'] == 3
        assert report['missing_fraction'] == 1 / 3
        assert report['duplicate_groups'] == [{'records': [1, 3], 'repeats': 1}]
        assert report['duplicate_count'] == 1
        assert report['columns'][0]['numeric_statistics'] == {
            'min': 1.0, 'max': 2.0, 'mean': 4 / 3, 'median': 1.0
        }
        assert report['columns'][1]['unique_count'] == 1
        assert report['columns'][1]['numeric_statistics'] is None
        assert report['columns'][2]['numeric_statistics'] is None
        assert result.stdout == invoke(fixture.read_bytes(), '--format', 'json').stdout

        report = json.loads(invoke(b'a,b\n', '--format', 'json').stdout)
        assert report['row_count'] == report['missing_count'] == report['duplicate_count'] == 0
        assert report['missing_fraction'] == 0.0
        assert all(c['filled_count'] == c['unique_count'] == c['missing_count'] == 0
                   and c['missing_fraction'] == 0.0 and c['numeric_statistics'] is None
                   for c in report['columns'])

        for data in (b'', b'\xef\xbb\xbf', b'\n', b'a, \n', b'a,a\n',
                     b'a,b\n1\n', b'a\n\n', b'a\n"unfinished\n',
                     b'a\n"value"oops\n', b'a\n\xff\n'):
            invoke(data, valid=False)
        invoke(b'a\n1\n', '--delimiter', 'xx', valid=False)
        invoke(b'a\n1\n', '--encoding', 'no-such-encoding', valid=False)
        invoke(b'a\n1\n', '--format', 'xml', valid=False)
        missing = subprocess.run([sys.executable, str(CLI), str(fixture) + '.absent'],
                                 capture_output=True, text=True)
        assert missing.returncode == 1 and 'Traceback' not in missing.stderr
        checks += 1

        multiline = b'a,b\n"line\nbreak",1\n"line\nbreak",1\n'
        report = json.loads(invoke(multiline, '--format', 'json').stdout)
        assert report['duplicate_groups'][0]['records'] == [1, 2]
        report = json.loads(invoke(b'a\n1.7e308\n1.7e308\n', '--format', 'json').stdout)
        assert report['columns'][0]['numeric_statistics']['mean'] == 1.7e308
        assert report['columns'][0]['numeric_statistics']['median'] == 1.7e308
        for value in (b'NaN', b'Infinity', b'1e999', b'no'):
            report = json.loads(invoke(b'a\n1\n' + value + b'\n', '--format', 'json').stdout)
            assert report['columns'][0]['numeric_statistics'] is None
        report = json.loads(invoke(b'a\n 1 \n1\n', '--format', 'json').stdout)
        assert report['columns'][0]['unique_count'] == 2
        assert report['duplicate_count'] == 0
        assert report['columns'][0]['numeric_statistics']['median'] == 1.0
        report = json.loads(invoke('имя;число\nда;2\n'.encode('cp1251'),
                                   '--delimiter', ';', '--encoding', 'cp1251',
                                   '--format', 'json').stdout)
        assert report['columns'][0]['name'] == 'имя'
        assert 'Rows: 1' in invoke(b'a\n1\n').stdout
        help_result = subprocess.run([sys.executable, str(CLI), '--help'],
                                     capture_output=True, text=True)
        assert help_result.returncode == 0 and '--encoding' in help_result.stdout
        checks += 1
    print('PASS: {} CLI smoke checks; input hashes unchanged'.format(checks))


if __name__ == '__main__':
    main()
