-- Bootstrap only; expand with versioned migrations before business implementation.
CREATE TABLE IF NOT EXISTS imports (
 id TEXT PRIMARY KEY,
 source TEXT NOT NULL CHECK(source='hh'),
 query_json TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('queued','running','succeeded','partial','failed')),
 created_at TEXT NOT NULL,
 metadata_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS vacancies (
 id INTEGER PRIMARY KEY,
 source TEXT NOT NULL CHECK(source='hh'),
 external_id TEXT NOT NULL,
 first_seen_at TEXT NOT NULL,
 last_seen_at TEXT NOT NULL,
 dto_json TEXT NOT NULL,
 UNIQUE(source, external_id)
);
CREATE TABLE IF NOT EXISTS import_items (
 import_id TEXT NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
 vacancy_id INTEGER NOT NULL REFERENCES vacancies(id) ON DELETE CASCADE,
 snapshot_json TEXT NOT NULL,
 PRIMARY KEY(import_id,vacancy_id)
);
CREATE TABLE IF NOT EXISTS idempotency_keys (
 key TEXT PRIMARY KEY,
 request_hash TEXT NOT NULL,
 import_id TEXT NOT NULL REFERENCES imports(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL
);
PRAGMA user_version = 1;
