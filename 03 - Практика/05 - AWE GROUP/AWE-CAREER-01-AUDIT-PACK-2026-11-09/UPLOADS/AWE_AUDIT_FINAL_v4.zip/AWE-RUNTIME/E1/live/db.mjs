// Minimal PostgreSQL session for the live runtime. Uses the server's psql
// binary over a local trust socket so no driver dependency is needed.
import {spawnSync} from 'node:child_process';

const PSQL = process.env.AWE_LIVE_PSQL || '/usr/lib/postgresql/18/bin/psql';

export function createDb({socketDir, port = 5544, user = 'awe_live', database = 'awe_live'} = {}) {
  if (!socketDir) throw new Error('LIVE_DB_SOCKET_REQUIRED');
  function run(sql, {tx = false} = {}) {
    const script = tx ? `begin;\n${sql}\ncommit;\n` : sql;
    const result = spawnSync(PSQL, ['-h', socketDir, '-p', String(port), '-U', user, '-d', database, '-X', '-q', '-v', 'ON_ERROR_STOP=1', '-f', '-'], {
      input: script, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024
    });
    if (result.status !== 0) {
      const detail = `${result.stderr || ''}\n${result.stdout || ''}`.trim().slice(-2000);
      throw new Error(`LIVE_SQL_FAILED: ${detail}`);
    }
    return result.stdout;
  }
  // Returns parsed JSON rows. The query must be a single statement.
  function query(sql) {
    const wrapped = `select coalesce(json_agg(row_to_json(q)), '[]'::json) from (${sql}) q;`;
    const out = run(wrapped);
    const line = out.split('\n').map(s => s.trim()).find(s => s.startsWith('['));
    if (!line) throw new Error(`LIVE_SQL_NO_JSON: ${out.slice(-500)}`);
    return JSON.parse(line);
  }
  function exec(sql) { run(sql, {tx: true}); }
  return {query, exec, run};
}

export function sqlLiteral(value) {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'number') { if (!Number.isFinite(value)) throw new Error('LIVE_SQL_BAD_NUMBER'); return String(value); }
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  return `'${String(value).replaceAll("'", "''")}'`;
}

export function sqlJson(value) {
  return `${sqlLiteral(JSON.stringify(value))}::jsonb`;
}
