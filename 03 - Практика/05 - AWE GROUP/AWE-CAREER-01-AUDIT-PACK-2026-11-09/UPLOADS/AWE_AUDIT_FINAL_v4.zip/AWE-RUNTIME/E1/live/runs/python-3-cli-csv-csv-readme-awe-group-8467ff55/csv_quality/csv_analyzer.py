#!/usr/bin/env python3
"""Read-only CSV quality analysis. See README.md for the public contract."""

import argparse
import csv
import json
import math
import statistics
import sys


class AnalysisError(Exception):
    """Invalid input data."""


def delimiter_value(value):
    if len(value) != 1 or value in "\r\n\0":
        raise argparse.ArgumentTypeError(
            "delimiter must be one character other than CR, LF or NUL"
        )
    return value


def numeric_statistics(values):
    numbers = []
    for value in values:
        try:
            number = float(value.strip())
        except (ValueError, OverflowError):
            return None
        if not math.isfinite(number):
            return None
        numbers.append(number)
    if not numbers:
        return None
    numbers.sort()
    middle = len(numbers) // 2
    # statistics.mean uses exact intermediate arithmetic for floats, avoiding
    # overflow even for two values close to the largest finite binary64 value.
    median = (numbers[middle] if len(numbers) % 2 else
              statistics.mean(numbers[middle - 1:middle + 1]))
    return {
        "min": numbers[0],
        "max": numbers[-1],
        "mean": statistics.mean(numbers),
        "median": median,
    }


def analyze(path, delimiter=",", encoding="utf-8-sig"):
    with open(path, "r", encoding=encoding, errors="strict", newline="") as source:
        reader = csv.reader(source, delimiter=delimiter, strict=True)
        try:
            header = next(reader)
        except StopIteration:
            raise AnalysisError("CSV file is empty: no header record") from None
        if not header:
            raise AnalysisError("header has no columns")
        if any(not name.strip() for name in header):
            raise AnalysisError("header contains an empty or whitespace-only column name")
        if len(set(header)) != len(header):
            raise AnalysisError("header contains duplicate column names")

        columns = [[] for _ in header]
        missing = [0] * len(header)
        groups = {}
        row_count = 0
        for record_number, row in enumerate(reader, start=1):
            if len(row) != len(header):
                raise AnalysisError(
                    "data record {}: expected {} fields, got {}".format(
                        record_number, len(header), len(row)
                    )
                )
            row_count += 1
            groups.setdefault(tuple(row), []).append(record_number)
            for index, value in enumerate(row):
                if not value.strip():
                    missing[index] += 1
                else:
                    columns[index].append(value)

    duplicates = [
        {"records": records, "repeats": len(records) - 1}
        for records in groups.values() if len(records) > 1
    ]
    column_results = []
    for index, name in enumerate(header):
        values = columns[index]
        column_results.append({
            "name": name,
            "missing_count": missing[index],
            "missing_fraction": missing[index] / row_count if row_count else 0.0,
            "filled_count": len(values),
            "unique_count": len(set(values)),
            "numeric_statistics": numeric_statistics(values),
        })
    total_cells = row_count * len(header)
    missing_count = sum(missing)
    return {
        "schema_version": 1,
        "row_count": row_count,
        "column_count": len(header),
        "missing_count": missing_count,
        "missing_fraction": missing_count / total_cells if total_cells else 0.0,
        "duplicate_count": sum(group["repeats"] for group in duplicates),
        "duplicate_groups": duplicates,
        "columns": column_results,
    }


def render_text(result):
    lines = [
        "Rows: {}".format(result["row_count"]),
        "Columns: {}".format(result["column_count"]),
        "Missing cells: {} (fraction: {})".format(
            result["missing_count"], result["missing_fraction"]
        ),
        "Duplicate records beyond first: {}".format(result["duplicate_count"]),
        "Duplicate groups: " + json.dumps(result["duplicate_groups"], ensure_ascii=True),
    ]
    for column in result["columns"]:
        lines.append("Column " + json.dumps(column["name"], ensure_ascii=True) + ":")
        for key in ("missing_count", "missing_fraction", "filled_count", "unique_count"):
            lines.append("  {}: {}".format(key, column[key]))
        lines.append("  numeric_statistics: " + json.dumps(
            column["numeric_statistics"], ensure_ascii=True, allow_nan=False
        ))
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Analyze CSV quality without modifying input.")
    parser.add_argument("path", help="path to CSV file")
    parser.add_argument("--delimiter", default=",", type=delimiter_value,
                        help="single field separator (default: comma)")
    parser.add_argument("--encoding", default="utf-8-sig",
                        help="input encoding (default: utf-8-sig)")
    parser.add_argument("--format", choices=("text", "json"), default="text",
                        help="output format (default: text)")
    args = parser.parse_args(argv)
    try:
        result = analyze(args.path, args.delimiter, args.encoding)
        output = (json.dumps(result, ensure_ascii=True, allow_nan=False, indent=2)
                  if args.format == "json" else render_text(result))
        print(output)
    except (AnalysisError, csv.Error, UnicodeError, LookupError, OSError, ValueError) as error:
        print("error: {}".format(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
