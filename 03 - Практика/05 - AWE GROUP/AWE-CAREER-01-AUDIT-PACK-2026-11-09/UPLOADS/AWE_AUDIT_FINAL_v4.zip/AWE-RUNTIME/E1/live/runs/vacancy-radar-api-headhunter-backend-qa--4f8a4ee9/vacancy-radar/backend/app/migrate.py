"""Apply versioned SQLite migrations without starting the server."""
import os
from pathlib import Path
from .core import ROOT, Store

def main():
    path=(ROOT/Path(os.environ.get('VR_DB_PATH','data/vacancy-radar.sqlite3'))).resolve()
    if not path.is_relative_to(ROOT): raise SystemExit('Database must be inside vacancy-radar')
    store=Store(path)
    with store.connection() as c:
        print(f'{path}: schema_version={c.execute("PRAGMA user_version").fetchone()[0]}')

if __name__=='__main__': main()
